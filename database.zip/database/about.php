<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>من نحن؟</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,PHP">
        <meta name="description" content="this page contaion definition about our website">
        <meta name="author" content="Sara">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body> <div class="body">
            <header>
                <?php
                include 'header.php';
                ?>
            </header>
            <br><hr><br>
            <center>
                <img src="https://www.colourbox.com/preview/2650444-3d-small-person-the-leader-of-a-team-allocated-with-red-colour.jpg"
                     alt="img" style="width:100px;height:80px;">

                <h1> من نحن؟</h1>
                <p id="rcorners">لقد اصبحت الحاجة للكتب الدراسية وصعوبة الحصول عليها هاجساً لكثير من الطلاب، ومن هنا جاء(كتابي) كمشروع يتيح لك بيع وشراء الكتب والعديد من المزايا بكل اريحية ويسر وبدون رسوم. تم تأسيسه من قبل مجموعة من طالبات كلية علوم الحاسب الآلي ونظم المعلومات بجامعة ام القرى، خصيصاً لإعانة الطلاب وتوفير اوقاتهم</p>
                <h1> who are we!</h1>
                <p id="rcorners1">The need for textbooks and the difficulty of obtaining them became an obsession for many students. Hence, (my book) came as a project that allows you to buy and sell books and many advantages in easily way and without fees.Was founded by a group of students in Computer Science and Information Systems at Umm Al-Qura University, specifically to help students and save their time.</p>
            </center>
            <br><br><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>
