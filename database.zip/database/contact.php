<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">    
    <head>
        <title>اتصل بنا </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="this page for allow the user to contact with us">
        <meta name="author" content="Hadeel">         
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
    </head>
    <body>    <div class="body">

            <header>
                <?php
                include 'header.php';
                include'createConnection.php';
                ?>
            </header>
            <br><hr><br>
           
            <h1>اتصل بنا</h1>
            <br>
            <!-- form to get the information from user
            -->
            <form enctype="multipart/form-data" action="" onsubmit="return validateConatct();" method="post" name="contactForm">
                <table class="contactTable">
                    <tr><td>                <h4>هل لديك أي استفسارات أو اقتراحات؟ نسعد بكم </h4>
                        </td><td></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="name" class="text" id="contactname" placeholder="الاسم" /></td><td><p id="contactName"></p></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="email" class="text" id="contactemail" placeholder="البريد الإلكتروني" /></td><td><p id="contactEmail"></p></td>
                    </tr>

                    <tr>
                        <td><select name="select" class="contact" id="selectcontact">
                                <option value="-1">اختر مجال الرسالة من القائمة</option>
                                <option value="1">اقتراح</option>
                                <option value="2">شكوى</option>
                                <option value="3">مشكلة تقنية</option>
                                <option value="4">أخرى</option>                                 
                            </select></td><td><p id="selectContact"></p></td>

                    </tr>
                    <tr>
                        <td><textarea cols="30" rows="10" class="contactUs" name="msg" id="contactmsg" placeholder="اكتب رسالتك هنا"></textarea></td><td><p id="contactMsg"></p></td>
                    </tr>

                </table>

                <br>
                <input id="submit" class="submitContact" type="submit" value="إرسال"  name="submitContact" />
            </form>
            <br><br>

            <?php
            if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                if (isset($_POST["submitContact"])) {
                    // get info from form when submit
                    $name = htmlspecialchars($_REQUEST['name']);
                    $email = htmlspecialchars($_REQUEST['email']);
                    $msg = htmlspecialchars($_REQUEST['msg']);
                    $topic = $_POST['select'];
                    if ($topic == '1') {
                        $topic = "اقتراح";
                    } else if ($topic == '2') {
                        $topic = "شكوى";
                    } else if ($topic == '3') {
                        $topic = "مشكلة تقنية";
                    } else if ($topic == '4') {
                        $topic = "أخرى";
                    }

                    //insert the info into DB
                    $sql = "INSERT INTO feedback (id,name, email, topic, msg) "
                            . "VALUES (null,'$name','$email', '$topic','$msg')";
                    if ($connection->query($sql) === TRUE) {
                        echo "<script> window.location.href ='ThankYou.php'; </script>";// go to thankyou page  
                        die();
                    } else {
                        echo "<script type='text/javascript'> alert('هناك مشكلة ما الرجاء المحاولة مرة أخرى')</script> ";
                    }
                }
            }
            ?>

            <h4 align="center">أو على مواقع التواصل الإجتماعي</h4>
            <table align="center">
                <tr>
                    <th>
                        <img src="images/twitter.png" width="50" height="50">
                        <br>
                        <a href="">ketabi</a>
                    </th>
                    <th>
                        <img src="images/instagram.png" width="50" height="50">
                        <br>
                        <a href="">ketabi</a>
                    </th>
                    <th>
                        <img src="images/facebook.png" width="50" height="50">
                        <br>
                        <a href="">ketabi</a>
                    </th>
                </tr>
            </table>
            <br><br><br>
            <footer>

                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>
