<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="Mybook page contain the book of the user and alloe editing and delete book">
        <meta name="author" content="Haya">        
        <title>مكتبتي</title>
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
    </head>
    <body>  <div class="body">
            <header>
                <?php
                include 'header.php';
                ?>
            </header> <br><hr><br>
            <?php
            // get url to select specific part (id)
            $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $parts = Explode('?', $url);
            $idUser = $parts[count($parts) - 1];

            //get book of user from DB
            $sql = "SELECT * FROM mybooks WHERE userid='$idUser'";
            $result = mysqli_query($connection, "$sql");
            if ((mysqli_num_rows($result) == 0)) {
                echo '<h2 class="myBooks">قم بإضافة كتب أو ملخصات أو مذكرات لتتمكن من معاينتهم </h2>';
            } else {

                echo'<h1>مكتبتي</h1><br><table class="myBook">';
                while ($row = mysqli_fetch_array($result)) {


                    $id = $row['bookid'];
                    //get book info
                    $sql2 = "SELECT * FROM books WHERE bookid='$id'";
                    $result2 = mysqli_query($connection, "$sql2");
                    while ($row2 = mysqli_fetch_array($result2)) {
                        ?><form enctype="multipart/form-data" method="post">
                            <?php
                            echo '<tr class="myBook"><td class="myBook">'
                            . '<input name="row_id" type="hidden" value="' . $row2['bookid'] . '" />'
                            . '<input type="submit" id="delete" name="delete" value="حذف الكتاب"/></td>'
                            . ' <td class="myBook">'
                            . '<img src="data:image/jpeg;base64,' . base64_encode($row2['cover']) . '" height="200" width="150"/>'
                            . '</td><td class="myBook">اسم الكتاب : ' . $row2['bookname'] . '</td>'
                            . '<td class="myBook"><a class="editBook" href="editMyBook.php?' . $id . '"> تعديل</a></td></tr>'
                            ;
                            ?></form><?php
                    }
                }
                echo '</table>';
            }
// to delete book fromm data base
            if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                if (isset($_POST['delete'])) {
                    $idbook = $_POST['row_id'];
                    $sql3 = mysqli_query($connection, "DELETE FROM mybooks WHERE bookid='" . $idbook . "'");
                    $sql4 = mysqli_query($connection, "DELETE FROM favorite WHERE bookid='" . $idbook . "'");
                    $sql5 = mysqli_query($connection, "DELETE FROM books WHERE bookid='" . $idbook . "'");

                    echo "<script> window.location.href ='MyBooks.php?$idUser'; </script>";
                }
            }
            ?>

            <br><br>
            <footer>
                <?php
                include ('footer.php'); // footer
                ?>
            </footer></div>
    </body>
</html>
