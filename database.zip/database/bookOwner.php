<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html dir="rtl" lang="ar">    
    <head>
        <title> مالك الكتاب  </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="register New user">
        <meta name="author" content="Sara">        
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body> 
        <div class="body">
            <header>
                <?php
                // to include the header of all pages , and the page of the connection to sql
                include 'header.php';
                include'createConnection.php';
                ?>
            </header>
            <?php
            //getting the user id that is sent to the link ..
            $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $parts = Explode('?', $url);
            $id = $parts[count($parts) - 1];


// fetching informtaion from the user table in the database to display it in the form ..
            $sql = "SELECT * FROM user WHERE userid=" . $id;
            $result = mysqli_query($connection, $sql);
            while ($row = mysqli_fetch_array($result)) {
                $username = $row['username'];
                $idForUser = $row['userid'];
                $userEmail = $row['email'];
                $userInsta = $row['insta'];
                $userFace = $row['facebook'];
                $userWebsite = $row['website'];
                $userPhone = $row['phone'];
                $userTwitt = $row['twitter'];
            }
            ?>

            <!-- displaying information fetched from database-->
            <div class="body" >
                <br><hr><br>
                <h1>استعراض الملف الشخصي لعضو</h1>
                <br><br>
                <fieldset id="owener2">
                    <legend>معلومات العضو</legend>
                    <div style='float:right' >
                        <br><br> <h3><br><?php echo $username ?></h3>
                        <div>
                            <table>
                                <tr>
                                    <td><h3>  معلومات التواصل : </h3></td>

                                </tr>
                                <tr>
                                    <td><img src="images/facebook.png" class="contactinginfo" width="50px" height="50px"></td>

                                    <td><label><?php echo $userFace ?></label></td> 
                                </tr>
                                <tr>
                                    <td><img src="images/instagram.png" class="contactinginfo" width="50px" height="50px"></td>
                                    <td><label><?php echo $userInsta ?></label></td>
                                </tr>
                                <tr>         <td><img src="images/twitter.png" class="contactinginfo"width="50px" height="50px"></td>
                                    <td><label><?php echo $userTwitt ?></label></td>
                                </tr>
                                <tr>
                                    <td><img src="images/Gmail-Icon.png" class="contactinginfo"width="50px" height="50px"></td>
                                    <td><label><?php echo $userEmail ?></label></td>
                                </tr>
                                <tr>
                                    <td><img src="images/website.jpg" class="contactinginfo"width="50px" height="50px"></td>
                                    <td><label><?php echo $userWebsite ?></label></td>
                                </tr>
                                <td><img src="images/phonenumber.png" class="contactinginfo"width="50px" height="50px"></td>
                                <td><label><?php echo $userPhone ?></label></td>
                            </table>
                        </div>
                </fieldset><br><br><br>

                <?php
                // fetching information of the books that the user own .. 

                $sql = "SELECT * FROM mybooks WHERE userid='$idForUser'";
                $result = mysqli_query($connection, "$sql");
                if ((mysqli_num_rows($result) == 0)) {//checking if there is result if not print that there is no books 
                    echo '<h2 class="myBooks">لا توجد كتب في مفضلتك </h2>';
                } else {
// if there is books the following code will select it and output in a table ..

                    echo'<fieldset><legend>قائمة الكتب</legend><br><table class="myBook">';
                    while ($row = mysqli_fetch_array($result)) {
                        $id = $row['bookid'];
                        $sql2 = "SELECT * FROM books WHERE bookid='$id'";
                        $result2 = mysqli_query($connection, "$sql2");
                        while ($row2 = mysqli_fetch_array($result2)) {
                            ?><form enctype="multipart/form-data" method="post">
                                <?php
                                echo '<tr class="myBook">'
                                . ' <td class="myBook">'
                                . '<img src="data:image/jpeg;base64,' . base64_encode($row2['cover']) . '" height="200" width="150"/>'
                                . '</td><td class="myBook">اسم الكتاب : ' . $row2['bookname'] . '</td>'
                                ?></form><?php
                        }
                    }
                    echo '</table></div></fieldset>';
                }
                ?>
                <br>
                <footer>
                    <?php
                    include ('footer.php');
                    ?>
                </footer><br><br>
            </div>
    </body>
</html>




