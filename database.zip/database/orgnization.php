<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head html dir="rtl" lang="ar">
        <meta charset="UTF-8">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
        <title>المنظمات</title>
    </head>
    <body><div class="body" align="center">
            <header>
                <?php
                require 'header.php';
                require_once 'header.php';
                ?>
            </header>
            <br><hr><br>
            <table>
                <tr>
                    <td><img src="images/cal.jpg" width="500" height="500"><hr></td>
                </tr>
                <tr>
                    <td><img src="images/calendar1438.png" width="500" height="500"><hr></td>
                </tr>
                <tr>
                    <td><img src="images/call.jpg" width="500" height="500"><hr></td>
                </tr>
                
            </table>
        <br><br>
                <footer>
                    <?php
                    include ('footer.php');
                    ?>
            </footer><br></div>
    </body>
</html>
