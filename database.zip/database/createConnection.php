<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $host = "localhost";
        $user="root";//غيرته عشان اشيك اذا يشتغل 
        $pass="";
        $dbName = "ketabidb";

        $connection = new mysqli($host, $user, $pass, $dbName);
        if ($connection->connect_error) {
            die("DB is not connected " . $connection->connect_error);
        }
        
        $connection->query("SETS NAMES utf8");
        $connection->query("SET CHARACTER SET utf8");
        ?>
    </body>
</html>
