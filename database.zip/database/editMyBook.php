<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">    
    <head>
        <title>تعديل كتابي </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="this page allow user to edit his book">
        <meta name="author" content="Nouf">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <div class="body">
            <header>
                <?php
                   // to include the header of all pages , and the page of the connection to sql
                include 'header.php';
                include'createConnection.php';
                ?>
            </header>
            <br><hr><br>
            <h1>تعديل كتابي</h1>
            <br><br>
            <?php 
            
             //getting the user id that is sent to the link ..
             $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $parts = Explode('?', $url);
            $id = $parts[count($parts) - 1];
            
            // fetching informtaion from the book table in the database 
            $sql = "SELECT * FROM books WHERE bookid='$id'";
            $result = mysqli_query($connection, "$sql");
            while ($row = mysqli_fetch_array($result)) {
            $bookname =$row['bookname'] ;
            $author = $row['author'];
            $description=$row['description'];
            $college = $row['college'];
            $price=$row['price'];
            }
            ?>
            <form enctype="multipart/form-data" method="post" onsubmit="valthisform();">
                <fieldset>
                    <legend>معلومات الكتاب</legend>
                    <table> <tr>
                            <td><label>اسم الكتاب</label></td>
                            <td><input type="text" name="bookname" value="<?php echo $bookname;?>" class="text" pattern="[A-Z a-zأ -ي]{1,30}" required/></td>
                        </tr>
                        <tr>
                            <td><label>المؤلف </label></td>
                            <td><input type="text" name="authorname" value="<?php echo $author;?>" class="text" pattern="[A-Z a-z أ-ي]{1,30}" required /></td>
                        </tr>
                        <tr>
                            <td><label>وصف حالة الكتاب</label></td>
                            <td><textarea name="comments"cols="30" rows="10" class="descBook" pattern="[A-Z a-z 0-9 أ-ي]{1,60}"required><?php echo $description;?></textarea></td>
                        </tr>
                        <tr>
                            <td><label>الكلية</label></td>
                            <td><select name="$college" class="bookcollege" id="check" >
                                    <option value="كلية الشريعة والدراسات الإسلامية">كلية الشريعة والدراسات الإسلامية</option>ش
                                    <option value="كلية الدعوة وأصول الدين">كلية الدعوة وأصول الدين</option>
                                    <option value="كلية إدارة الأعمال">كلية إدارة الأعمال</option>
                                    <option value="كلية الدراسات القضائية والأنظمة">كلية الدراسات القضائية والأنظمة</option>
                                    <option value="كلية العلوم الإقتصادية والمالية الإسلامية">كلية العلوم الإقتصادية والمالية الإسلامية</option>
                                    <option value="كلية العلوم التطبيقية">كلية العلوم التطبيقية</option>
                                    <option value="كلية الهندسة والعمارة الإسلامية">كلية الهندسة والعمارة الإسلامية</option>
                                    <option value="كلية الحاسب الآلي ونظم المعلومات">كلية الحاسب الآلي ونظم المعلومات</option>
                                    <option value="كلية الطب">كلية الطب</option>
                                    <option value="كلية العلوم الطبية التطبيقية">كلية العلوم الطبية التطبيقية</option>
                                    <option value="كلية طب الأسنان">كلية طب الأسنان</option>
                                    <option value="كلية الصحة العامة والمعلوماتية الصحية">كلية الصحة العامة والمعلوماتية الصحية</option>
                                    <option value="كلية الصيدلة">كلية الصيدلة</option>
                                    <option value="كلية التمريض">كلية التمريض</option>
                                    <option value="كلية التصاميم">كلية التصاميم</option>
                                    <option value="كلية خدمة المجتمع والتعليم المستمر">كلية خدمة المجتمع والتعليم المستمر</option>

                                </select></td>

                        </tr>
                        <tr>
                            <td><label>السعر </label></td>
                            <td><input type="number" name="price" value="<?php echo  $price;?>" class="text" min="0" class="image"pattern="[0-9]{1,3}" required /></td>
                        </tr>
                        <tr>
                            <td><label>صورة الغلاف </label></td>
                            <td><input type="file" name="cover"/></td>
                        </tr>
                    </table>
                    <br>
                
                </fieldset>
                <br><br>

                <br>

                <input id="submit" type="submit" value="تعديل" class="editBook"onclick="valthisform();" />
                <input id="button" type="reset" value="مسح" class="clear" />
                <input id="button" type="button" value="إلغاء" class="cancel" />
            </form>
            <br><br><br>

            <?php
            
             //getting the book id that is sent to the link ..
            
            $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $parts = Explode('?', $url);
            $bookid = $parts[count($parts) - 1];
            
            //select the book id from books table to use it
                        $sql = "SELECT * FROM books WHERE bookid=" . $bookid;
                        $result = mysqli_query($connection, $sql);
                        while ($row = mysqli_fetch_array($result)) {
                            $idForBook=$row['bookid'];
                            
                        }
                        
                        //updating the tables 
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['bookname'])){
                $update = "UPDATE books SET bookname='" . $_POST['bookname'] . "' WHERE bookid='" . $idForBook . "'";
                if ($connection->query($update) === TRUE) {
                   // echo "bookname updated successfully";
              
                } else {
                 //   echo "Error updating bookname: " . $conn->error;
            }}

                if (isset($_POST['authorname'])) {
                    $update = "UPDATE books SET author='" . $_POST['authorname'] . "' WHERE bookid='" . $idForBook . "'";
                    if ($connection->query($update) === TRUE) {
                        //show an alert that the book has been edited succesfuly ..
                        echo "<script type='text/javascript'> alert('تم تعديل معلومات الكتاب بنجاح')</script> ";
                        //     echo "author updated successfully";
                    } else {
                     //   echo "Error updating author: " . $conn->error;
                }}

                    if (isset($_POST['comments'])) {
                        $update = "UPDATE books SET description='" . $_POST['comments'] . "' WHERE bookid='" . $idForBook . "'";
                        if ($connection->query($update) === TRUE) {
                       //     echo "description updated successfully";
                        } else {
                          //  echo "Error updating description: " . $conn->error;
                    }}

                        if (isset($_POST['price'])) {
                            $update = "UPDATE books SET price=" . $_POST['price'] . " WHERE bookid='" . $idForBook . "'";
                            if ($connection->query($update) === TRUE) {
                         //       echo "price updated successfully";
                            } else {
                            //    echo "Error updating price: " . $conn->error;
                        }}
                        
                                                if (isset($_POST['college'])) {
                            $update = "UPDATE books SET college=" . $_POST['college'] . " WHERE bookid='" . $idForBook . "'";
                            if ($connection->query($update) === TRUE) {
                           //     echo "college updated successfully";
                            } else {
                              //  echo "Error updating college: " . $conn->error;
                        }}
                        
                                                if (isset($_POST['cover'])) {
                            $update = "UPDATE books SET cover=" . $_POST['cover'] . " WHERE bookid='" . $idForBook . "'";
                            if ($connection->query($update) === TRUE) {
                           //     echo "cover updated successfully";
                         
                                
                            } else {
                             //   echo "Error updating cover: " . $conn->error;
                        }}
                        
                        
                            }
                            ?>
                     

                            <footer>
                                <?php
                                include ('footer.php');
                                ?>
            </footer><br>
        </div>
    </body>
</html>

