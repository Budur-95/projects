<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">    
    <head>
        <title>إضافة ملخص </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="add new book by user">
        <meta name="author" content="Haya">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
    </head>
    <body>    <div class="body">

            <header>
                <?php
                include 'header.php';
                include'createConnection.php';
                ?>
            </header>
            <br><hr><br>
            <!--
            add new book to get from user the info about book 
            then insert it to DB.
            -->
            <h1>إضافة كتاب</h1>
            <br><br>
            <!-- form to get the information of book 
            like: name,author ,description,college and price
            -->
            <form enctype="multipart/form-data" action="" onsubmit="return validationBook()" method="post" name="newBook">
                <fieldset>
                    <legend>معلومات الملخص</legend>
                    <table><tr>
                            <td><label>اسم الملخص</label></td>
                            <td><input type="text" name="bookname" class="text" id="bookname" /></td><td><p id="bookName"></p></td>
                        </tr>
                        <tr>
                            <td><label>المؤلف </label></td>
                            <td><input type="text" name="bookauthor" class="text" id="bookauthor" /></td><td><p id="bookAuthor"></p></td>
                        </tr>
                        <tr>
                            <td><label>وصف حالة الملخص</label></td>
                            <td><textarea cols="30" rows="10" class="descBook" name="bookdesc" id="bookdesc"></textarea></td><td><p id="bookDesc"></p></td>
                        </tr>
                        <tr>
                            <td><label>الكلية</label></td>
                            <td><select name="collegeBook" class="bookcollege" id="bookcollege">
                                    <option value="-1">اختر الكلية من القائمة</option>
                                    <option value="1">كلية الشريعة والدراسات الإسلامية</option>
                                    <option value="2">كلية الدعوة وأصول الدين</option>
                                    <option value="3">كلية إدارة الأعمال</option>
                                    <option value="4">كلية الدراسات القضائية والأنظمة</option>
                                    <option value="5">كلية العلوم الإقتصادية والمالية الإسلامية</option>
                                    <option value="6">كلية العلوم التطبيقية</option>
                                    <option value="7">كلية الهندسة والعمارة الإسلامية</option>
                                    <option value="8">كلية الحاسب الآلي ونظم المعلومات</option>
                                    <option value="9">كلية الطب</option>
                                    <option value="10">كلية العلوم الطبية التطبيقية</option>
                                    <option value="11">كلية طب الأسنان</option>
                                    <option value="12">كلية الصحة العامة والمعلوماتية الصحية</option>
                                    <option value="13">كلية الصيدلة</option>
                                    <option value="14">كلية التمريض</option>
                                    <option value="15">كلية التصاميم</option>
                                    <option value="16">كلية خدمة المجتمع والتعليم المستمر</option>

                                </select></td><td><p id="bookCollege"></p></td>

                        </tr>
                        <tr>
                            <td><label>السعر </label></td>
                            <td><input type="number" name="bookprice" class="text" min="0" class="image" id="bookprice" /></td><td><p id="bookPrice"></p></td>
                        </tr>
                        <tr>
                            <td><label>صورة الغلاف </label></td>
                            <td><input type="file" accept="image/*" name="bookCover" id="bookcover" /></td><td><p id="bookCover"></p></td>
                        </tr>
                    </table>
                </fieldset>

                <br>
                <input id="submit" type="submit" value="إضافة" class="addBook" name="submitBook" />
                <input id="button" type="reset" value="مسح" class="clear" />
                <a href="books.php"><input id="button" type="button" value="إلغاء" class="cancel"/></a></form>
            <br><br><br>

            <footer>
                <?php
                if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                    if (isset($_POST["submitBook"])) {
                        // get info from form when submit
                        $name = htmlspecialchars($_REQUEST['bookname']);
                        $author = htmlspecialchars($_REQUEST['bookauthor']);
                        $des = htmlspecialchars($_REQUEST['bookdesc']);
                        $college = $_POST['collegeBook'];
                        if ($college == '1') {
                            $college = "كلية الشريعة والدراسات الإسلامية";
                        } else if ($college == '2') {
                            $college = "كلية الدعوة وأصول الدين";
                        } else if ($college == '3') {
                            $college = "كلية إدارة الأعمال";
                        } else if ($college == '4') {
                            $college = "كلية الدراسات القضائية والأنظمة";
                        } else if ($college == '5') {
                            $college = "كلية العلوم الإقتصادية والمالية الإسلامية";
                        } else if ($college == '6') {
                            $college = "كلية العلوم التطبيقية";
                        } else if ($college == '7') {
                            $college = "كلية الهندسة والعمارة الإسلامية";
                        } else if ($college == '8') {
                            $college = "كلية الحاسب الآلي ونظم المعلومات";
                        } else if ($college == '9') {
                            $college = "كلية الطب";
                        } else if ($college == '10') {
                            $college = "كلية العلوم الطبية التطبيقية";
                        } else if ($college == '11') {
                            $college = "كلية طب الأسنان";
                        } else if ($college == '12') {
                            $college = "كلية الصحة العامة والمعلوماتية الصحية";
                        } else if ($college == '13') {
                            $college = "كلية الصيدلة";
                        } else if ($college == '14') {
                            $college = "كلية التمريض";
                        } else if ($college == '15') {
                            $college = "كلية التصاميم";
                        } else if ($college == '16') {
                            $college = "كلية خدمة المجتمع والتعليم المستمر";
                        }
                        $price = htmlspecialchars($_REQUEST['bookprice']);
                        // for get image file
                        // reference : http://forum.codecall.net/topic/40286-tutorial-storing-images-in-mysql-with-php/
                        if (isset($_FILES['bookCover']) && $_FILES['bookCover']['size'] > 0) {
                            $imCover = $_FILES['bookCover']['tmp_name'];
                            $fp = fopen($imCover, 'r');
                            $cover = fread($fp, filesize($imCover));
                            $cover = addslashes($cover);
                            fclose($fp);
                        }
                        //insert the info into DB
                        $query1 = mysqli_query($connection, "INSERT INTO books VALUES (NULL,'$name','$author','$des','$college',$price,'$cover','summary')");

                        echo "<script type='text/javascript'> alert('تم إضافةالملخص بنجاح')</script> ";
                        $sql = "SELECT * FROM books WHERE bookname='$name' AND description='$des'";
                        $result = mysqli_query($connection, "$sql");
                        $row = mysqli_fetch_array($result);
                        $idB = $row['bookid'];
                        echo "<script> window.location.href ='bookInfo.php?$idB'; </script>";
                        // get url of page
                        $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $parts = Explode('?', $url); // spilt url using Explole function
                        $idU = $parts[count($parts) - 1]; // get Id from url
                        //insert into mybook table
                        $query2 = mysqli_query($connection, "INSERT INTO mybooks VALUES ('$idU','$idB','summary')");
                    }
                }
                ?>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>
