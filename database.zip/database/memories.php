<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="book page contain the book in DB with allow search & filter and adding & editing book">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
        <title>المذكرات</title>
    </head>
    <body>  <!--
            this page for view book in database 
            and the user can add new book & edit his book
            also the user can do search about the book by name
            and can apply filter by specific college
        -->

        <div class="body">
            <header>
                <?php
                include 'header.php';
                ?>
            </header>
            <br><hr>
            <form method="post" name="newBook">
                <table>
                    <tr>
                        <td rowspan="2"><img src="images/agenda.png" width="150" height="150"></td>
                    </tr>
                    <tr>
                        <td> <h1>المذكرات</h1></td>
                        <td> <table>
                                <!--
                                form for search and filter
                                -->
                                <tr> <td class="booksView"> <span>البحث باسم الكتاب :</span> </td>
                                    <td><input type="text" name="bookSearch" class="text"></td>
                                    <td><input type="submit" name="search" value="بحث" id="bookViewSubmit" /></td> </tr>
                                <tr><td class="booksView"><span>تصفية حسب الكلية :</span></td>
                                    <td><select name="collegeFilter" class="bookcollege">
                                            <option value="-1">اختر الكلية من القائمة</option>
                                            <option value="1">كلية الشريعة والدراسات الإسلامية</option>
                                            <option value="2">كلية الدعوة وأصول الدين</option>
                                            <option value="3">كلية إدارة الأعمال</option>
                                            <option value="4">كلية الدراسات القضائية والأنظمة</option>
                                            <option value="5">كلية العلوم الإقتصادية والمالية الإسلامية</option>
                                            <option value="6">كلية العلوم التطبيقية</option>
                                            <option value="7">كلية الهندسة والعمارة الإسلامية</option>
                                            <option value="8">كلية الحاسب الآلي ونظم المعلومات</option>
                                            <option value="9">كلية الطب</option>
                                            <option value="10">كلية العلوم الطبية التطبيقية</option>
                                            <option value="11">كلية طب الأسنان</option>
                                            <option value="12">كلية الصحة العامة والمعلوماتية الصحية</option>
                                            <option value="13">كلية الصيدلة</option>
                                            <option value="14">كلية التمريض</option>
                                            <option value="15">كلية التصاميم</option>
                                            <option value="16">كلية خدمة المجتمع والتعليم المستمر</option>
                                        </select></td>
                                    <td><input type="submit" name="filter" value="تصفية" id="bookViewSubmit" /></td></tr>

                            </table></td>
                    </tr>
                </table></form>
            <hr>

            <?php
            // add new book and edit it's allow for user who register 
            if (isset($_SESSION['email'])) {
                $emailU = $_SESSION['email'];
                $sqluser = "SELECT * FROM user WHERE email='$emailU'";
                $resultu = mysqli_query($connection, $sqluser);
                while ($rowu = mysqli_fetch_array($resultu)) {
                    $userId = $rowu['userid'];
                    echo ' <table id="AddBook"><tr>
                <td rowspan="2">&nbsp;&nbsp;&nbsp; 
                <a href="addNewMemory.php?' . $userId . '" >
                        <img src="images/memoryAdd.png" width="70" height="70"></a>
                </td>
                    <td>  <a href="addNewMemory.php?' . $userId . '" ><h2>إضافة مذكرة</h2></a></td> 
                <td rowspan="2" class="editMyBooks">&nbsp;&nbsp;&nbsp; 
                            <a href="MyBooks.php?' . $userId . '"><img src="images/book_edit.png" width="70" height="70"></a>
                        </td>
                        <td><a href="MyBooks.php?' . $userId . '"><h2>تعديل مذكراتي</h2></a></td>
                </tr>
            </table>';
                }
            } else {// this when user don't register
                ?>
                <table id="AddBook"><tr>
                        <td rowspan="2">&nbsp;&nbsp;&nbsp; 
                            <a><img src="images/memoryAdd.png" width="70" height="70" onclick="condAdd();"></a>
                        </td>

                        <td> <a><h2 onclick="condAdd();">إضافة مذكرة</h2></a></td> 

                        <td rowspan="2" class="editMyBooks">&nbsp;&nbsp;&nbsp; 

                            <a><img src="images/book_edit.png" width="70" height="70" onclick="condEdit();"></a>
                        </td>
                        <td><a><h2 onclick="condEdit();">تعديل  مذكراتي</h2></a></td>
                    </tr>  </table>
            <?php } ?>
            <br>

            <div class="book">
                <h1>قائمة المذكرات </h1>
                <br>
                <?php
                // to get info from form
                include'createConnection.php';
                if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                    $sBook = htmlspecialchars($_REQUEST['bookSearch']);
                    $college = $_POST['collegeFilter'];
                    if ($college == '1') {
                        $college = "كلية الشريعة والدراسات الإسلامية";
                    } else if ($college == '2') {
                        $college = "كلية الدعوة وأصول الدين";
                    } else if ($college == '3') {
                        $college = "كلية إدارة الأعمال";
                    } else if ($college == '4') {
                        $college = "كلية الدراسات القضائية والأنظمة";
                    } else if ($college == '5') {
                        $college = "كلية العلوم الإقتصادية والمالية الإسلامية";
                    } else if ($college == '6') {
                        $college = "كلية العلوم التطبيقية";
                    } else if ($college == '7') {
                        $college = "كلية الهندسة والعمارة الإسلامية";
                    } else if ($college == '8') {
                        $college = "كلية الحاسب الآلي ونظم المعلومات";
                    } else if ($college == '9') {
                        $college = "كلية الطب";
                    } else if ($college == '10') {
                        $college = "كلية العلوم الطبية التطبيقية";
                    } else if ($college == '11') {
                        $college = "كلية طب الأسنان";
                    } else if ($college == '12') {
                        $college = "كلية الصحة العامة والمعلوماتية الصحية";
                    } else if ($college == '13') {
                        $college = "كلية الصيدلة";
                    } else if ($college == '14') {
                        $college = "كلية التمريض";
                    } else if ($college == '15') {
                        $college = "كلية التصاميم";
                    } else if ($college == '16') {
                        $college = "كلية خدمة المجتمع والتعليم المستمر";
                    }
                    if (isset($_POST["filter"])) {
                        // select data when apply filter
                        $sql = "SELECT * FROM books WHERE college='$college' AND type=''";
                        $result = mysqli_query($connection, "$sql");
                        if ($college == '-1') {
                            echo 'الرجاء اختيار الكلية من القائمة <br>';
                        } else if (mysqli_num_rows($result) == 0) {
                            echo 'لا توجد كتب للكلية المختارة<br>';
                        }
                    }
                    if (isset($_POST["search"])) {
                        // select data when search
                        $sql = "SELECT * FROM books WHERE bookname LIKE '%".$sBook."%' AND hide='NO'";
                        $result = mysqli_query($connection, "$sql");
                        if ($sBook == "") {
                            echo'الرجاء كتابة اسم الكتاب <br>';
                        } else if (mysqli_num_rows($result) == 0) {
                            echo 'لا توجد كتب بهذا الاسم<br>';
                        }
                    }
                    while ($row = mysqli_fetch_array($result)) {
                        // print result
                        $id = $row['bookid'];
                        echo'<table><tr><td>  <td rowspan="3">
                            &nbsp;&nbsp;&nbsp; <a href="bookInfo.php?' . $id . '" >
                            <img src="data:image/jpeg;base64,' . base64_encode($row['cover']) . '" height="200" width="150"/></a>
                        </td>
                        <td>
                            <table><tr><th>اسم الكتاب : ' . $row['bookname'] . '</th>'
                        . '</tr>
                                <tr>
                                    <th>اسم المؤلف : ' . $row['author'] . '</th> 
                                </tr>
                                <tr>
                                    <th>  
                                    <a href="bookInfo.php?' . $id . '"><h4>للمزيد إضغط هنا</h4></a>
                                        <img src="images/Favorites1.png" width="30"height="30">
                                    </th>
                                </tr>
                            </table></td></td> 
                    </tr>  
                    <br> <br>       
                </table>';
                    }
                } else {
                    $sql = "SELECT * FROM books WHERE type like 'memory'";
                    $result = mysqli_query($connection, "$sql");
                    while ($row = mysqli_fetch_array($result)) {
                        $id = $row['bookid'];
                        echo'<table><tr><td>  <td rowspan="3">
                            &nbsp;&nbsp;&nbsp; <a href="bookInfo.php?' . $id . '" >
                            <img src="data:image/jpeg;base64,' . base64_encode($row['cover']) . '" height="200" width="150"/></a>
                        </td>
                        <td>
                            <table><tr><th>اسم الكتاب :' . $row['bookname'] . '</th>'
                        . '</tr>
                                <tr>
                                    <th>اسم المؤلف :' . $row['author'] . '</th> 
                                </tr>
                                <tr>
                                    <th> <a href="bookInfo.php?' . $id . '"><h4>للمزيد إضغط هنا</h4></a></th>
                                </tr>
                            </table></td></td> 
                    </tr>  
                    <br><br>       
                </table>';
                    }
                }
                mysqli_close($connection);
                ?>
                <br>           </div>
            <br><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>
