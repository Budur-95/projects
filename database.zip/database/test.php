<html dir="rtl">
<?php
$con = mysql_connect("localhost", "root", "");
$sel = mysql_select_db("ketabidb");

$sql = mysql_query("SELECT college, COUNT(*) as total, AVG(price) as avgPrice  FROM books group by college");
while ($data = mysql_fetch_array($sql)) {
	echo $data['college'] . " - " . $data['total'] . " - " . round($data['avgPrice'], 2) . "<br />";
}
?>
</html>