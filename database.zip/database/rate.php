<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>تقييم الكتب</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="style.css" type="text/css" rel="stylesheet" />
       
    </head>
    <body>  <div class="body">
        <header>
            <?php
            include 'header.php';
            ?>
        </header>
        
<br><hr><br>
<h1>التقييم</h1>
   <br><br>


  <fieldset>
    <legend align="right">الآراء</legend>
     <br>
  <textarea rows="3" cols="100"> &#9733; &#9733; &#9733; &#9733; &#9733;                                                                 ..بعض التعليقات</textarea>
<br>
  <textarea rows="3" cols="100"> &#9733; &#9733; &#9733; &#9733; &#9734;                                                                 ..بعض التعليقات</textarea>
<br>
  <textarea rows="3" cols="100"> &#9733; &#9733; &#9733; &#9734; &#9734;                                                             some comments..</textarea>
<br>
  <textarea rows="3" cols="100"> &#9733; &#9733; &#9734; &#9734; &#9734;                                                             some comments..</textarea>
<br>
    <input type="submit" id="submit" value="عرض المزيد">
  </fieldset>

  <br>
  <br>

   <fieldset >
    <legend align="right">  تقييمك الشخصي</legend>
    <textarea rows="5" cols="100">    &#9734; &#9734; &#9734; &#9734; &#9734;</textarea>
     <br>
    <input type="submit" id="submit" value="ارسال">
  </fieldset>

 

        <br><br><br>
        <footer>
           <?php
              include ('footer.php');
           ?>
        </footer><br></div>
</body>
</html>
