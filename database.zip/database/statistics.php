<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="book page contain the book in DB with allow search & filter and adding & editing book">
        <meta name="author" content="Haya">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="js.js"></script>
        <title>الإحصائيات</title>
    </head>
    <body>  <!--
            this page for view book in database
            and the user can add new book & edit his book
            also the user can do search about the book by name
            and can apply filter by specific college
        -->

        <div class="body">
            <header>
                <?php
                include 'header.php';
                ?>
            </header>
            <br><hr>


            <div class="book">
                <?php
                // to get info from form
                include'createConnection.php';
                ?>
                <br>
                <h1>إحصائية الكتب</h1>

                <table border="1" width="100%">
                    <tr>
                        <th>اسم الكلية</th>
                        <th>عدد الكتب</th>
                        <th>متوسط السعر</th>
                    </tr>
                    <?php
                    $sqlStatisticsBooks = "SELECT college, COUNT(*) as total, AVG(price) as avgPrice FROM books group by college";
                    $resultStatisticsBooks = mysqli_query($connection, $sqlStatisticsBooks);
                    while ($data = mysqli_fetch_array($resultStatisticsBooks)) {
                        echo "
                            <tr>
        						<td>".$data['college']."</td>
        						<td>".$data['total']."</td>
        						<td>".round($data['avgPrice'], 2)."</td>
        					</tr>
                        ";
                    }

                    ?>

                </table>

                <br>
                <h1>إحصائية الأعضاء المسجلين</h1>

                <table border="1" width="100%">
                    <tr>
                        <th>عدد الأعضاء المسجلين</th>
                    </tr>
                    <?php
                    $sqlStatisticsUsers = "SELECT COUNT(*) as total FROM user";
                    $resultStatisticsUsers = mysqli_query($connection, $sqlStatisticsUsers);
                    while ($data = mysqli_fetch_array($resultStatisticsUsers)) {
                        echo "
                            <tr>
        						<td>".$data['total']."</td>
        					</tr>
                        ";
                    }
                    ?>

                </table>
                <br>
                     <h1>احصائية الاعضاء المسجلين من كل جامعة </h1>
                  <table border="1" width="100%">
                    <tr>
                        <th>الجامعة</th>
                        <th>عدد الطلاب</th>

                    </tr>
                                          <?php


                        $sqlStatisticsStudent="SELECT university, COUNT(*)as userid FROM user GROUP BY university";
                         $resultStatisticsStudent = mysqli_query($connection, $sqlStatisticsStudent);
                         while ($data = mysqli_fetch_array($resultStatisticsStudent)) {
                        echo "
                            <tr>   <td>".$data['university']."</td>
        						<td>".$data['userid']."</td>


        					</tr>
                        ";


                    }
                    ?></table>

                    <br>
                <h1>احصائية الاعضاء المسجلين من كل كلية</h1>

                <table border="1" width="100%">
                    <tr>
                        <th>الكلية</th>
                        <th>العدد</th>
                    </tr>
                    <?php
                     $sqlStatisticsStudent2=" SELECT collage , COUNT(*) as total from user group by collage";

                         $resultStatisticsStudent2 = mysqli_query($connection, $sqlStatisticsStudent2);
                         while ($data = mysqli_fetch_array($resultStatisticsStudent2)) {
                        echo "
                   <tr>    <td> ".$data['collage']."</td>
                           <td> ".$data['total']." </td>";
                    }
                    ?>

                </table>

                <br>
                <h1>معلومات كل عضو</h1>

                <table border="1" width="100%">
                    <tr>
                        <th>اسم العضو</th>
                        <th>الكلية</th>
                        <th>الجامعة</th>
                    </tr>
                    <?php
                     $sqlStatisticsStudent1=" SELECT username , collage , university from user order by university";

                         $resultStatisticsStudent1 = mysqli_query($connection, $sqlStatisticsStudent1);
                         while ($data = mysqli_fetch_array($resultStatisticsStudent1)) {
                        echo "
                   <tr>    <td> ".$data['username']."</td>
                           <td> ".$data['collage']." </td>
                           <td> ".$data['university']."</td>";
                    }
                    ?>

                </table>

                <?php


                mysqli_close($connection);
                ?>
                <br>           </div>
            <br><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>
