/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



        function validationBook() {
//FOR add new book page
            var name = document.getElementById("bookname").value;
            var author = document.getElementById("bookauthor").value;
            var des = document.getElementById("bookdesc").value;
            var college = document.getElementById("bookcollege").value;
            var price = document.getElementById("bookprice").value;
            var cover = document.getElementById("bookcover").value;
            document.getElementById("bookName").innerHTML = "";
            document.getElementById("bookAuthor").innerHTML = "";
            document.getElementById("bookDesc").innerHTML = "";
            document.getElementById("bookCollege").innerHTML = "";
            document.getElementById("bookPrice").innerHTML = "";
            document.getElementById("bookCover").innerHTML = "";

            if (name == "" || author == "" || des == "" || college == "-1" || price == "" || cover == "") {
                    if (name == "") {
                            document.getElementById("bookName").innerHTML = "لا يمكنك ترك هذا الحقل فارغاً";
                    }
                    if (author == "") {
                            document.getElementById("bookAuthor").innerHTML = "لا يمكنك ترك هذا الحقل فارغاً";
                    }
                    if (des == "") {
                            document.getElementById("bookDesc").innerHTML = "لا يمكنك ترك هذا الحقل فارغاً";
                    }
                    if (college == "-1") {
                            document.getElementById("bookCollege").innerHTML = "الرجاء اختيار الكلية من القائمة";
                    }
                    if (price == "") {
                            document.getElementById("bookPrice").innerHTML = "لا يمكن ترك هذا الحقل فارغاً ، وإذا كنت لا تريد بيعه بمقابل بإمكانك وضع 0 ";
                    }
                    if (cover == "") {
                            document.getElementById("bookCover").innerHTML = "الرجاء تحميل صورة الغلاف";
                    }
                    return false;
            }

                    return true;
        }
// For contact page
function validateConatct() {

    var name = document.getElementById("contactname").value;
    var email = document.getElementById("contactemail").value;
    var select = document.getElementById("selectcontact").value;
    var msg = document.getElementById("contactmsg").value;
    var atpos = email.indexOf("@");
    var dotpos = email.lastIndexOf(".");
    var letters = /^[a-zA-Z\s]*$/;
    document.getElementById("contactName").innerHTML = "";
    document.getElementById("contactEmail").innerHTML = "";
    document.getElementById("selectContact").innerHTML = ""
    document.getElementById("contactMsg").innerHTML = ""
    if (name == "" || email == "" || select == "-1" || msg == "" ||
            atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length || !name.match(letters)) {
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length) {
            document.getElementById("contactEmail").innerHTML = "الرجاء إدخال إيميل صحيح";
        }
        if (name == "") {
                 document.getElementById("contactName").innerHTML = "لا يمكنك ترك هذا الحقل فارغاً";
        }
            if (email == "") {
                 document.getElementById("contactEmail").innerHTML = "لا يمكنك ترك هذا الحقل فارغاً";
            }

            if (select == "-1") {
                    document.getElementById("selectContact").innerHTML = "الرجاء الاختيار من القائمة";
            }
            if (msg == "") {
                    document.getElementById("contactMsg").innerHTML = "لا يمكن ترك هذا الحقل فارغاً ";
            }
         if (!name.match(letters)) {
                    document.getElementById("contactName").innerHTML = "الرجاء إدخال اسم صحيح - أحرف فقط";
        }
        return false;
    }
    return true;
}

function condAdd() {
    alert("عذراً ، لا يمكنك إضافة كتاب إلا عند تسجيل دخولك");
}
function condEdit() {
    alert("عذراً ، لا يمكنك تعديل كتبك إلا عند تسجيل دخولك");
}
function conditionLogin() {
    alert("عذراً ، لا يمكنك مشاهدة مفضلتك إلا عند تسجيل دخولك");
}
// for add to favorite
function favLogin() {
    alert("عذراً ، لا يمكنك إضافة كتاب إلى مفضلتك إلا عند تسجيل دخولك :(")
}
// for add to favorite
function confirmFav() {
    var c = confirm("هل أنت متأكد من إضافة الكتاب إلى مفضلتك ؟");
    if (c === false) {
        return false;
    } else {
        alert("تم إضافة الكتاب إلى مفضلتك :)");
        return true;
    }
}

