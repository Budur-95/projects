<?php
    session_start();
include_once 'createConnection.php';
mysqli_query($connection, "UPDATE views SET 'counter' = '20'  WHERE id='1'");

?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <title> كتابي</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="home page contain all the basic pages">
        <meta name="author" content="Hadeel">
        <link href="style.css" type="text/css" rel="stylesheet" />

        <script type="text/javascript">
            <!--
            var img1 = new Image();
            img1.src = "images/bookcover.jpg";

            var img2 = new Image();
            img2.src = "images/book2.jpg";

            var img3 = new Image();
            img3.src = "images/book3.jpg";
            //-->
    </script>
</head>
<body>
        <div class="body">
    <header>
        <?php
        include ('header.php');
        ?>
    </header><br>
    <hr><br>
    <div name="slideShow_code" id="slideShow">
        <!--This code taken from youtube, and we modified to be fit with our project
        url: https://www.youtube.com/watch?v=iOXHFvFpimg//-->
        <img src="flower.jpg" name="slide" width="940" height="400" class="home_image">
        <script type="text/javascript">
            <!--
            var step = 1;
            function slideit() {
                document.images.slide.src = eval("img" + step + ".src");
                if (step < 3) {
                    step++;
                } else {
                    step = 1;
                }
                setTimeout("slideit()", 2500);
            }
            slideit();
            //-->
            </script>
        </div><br>
                <section><!--  هذا الأربع أقسام في الصفحة الرئيسية//-->
                        <table id="index_table" align="center">
                <!--            <col width="240" style="background-color: #e08e79">
                            <col width="240" style="background-color: #f1d3af">
                            <col width="240" style="background-color: #e08e79">
                            <col width="240" style="background-color: #f1d3af">
                 -->
                            <col width="235">
                            <col width="235">
                            <col width="235">
                            <col width="235">
                            <tr >
                                <th class="home1" valign="top">
                              
                                    <br><img src="images/book.png" width="100" height="100">
                                    <br>
                                    <h2>الكتب</h2>
                                    <p>قم الآن بتصفح الكتب المتوفرة، يمكنك شراء أو استعارة الكتب، وأيضا يمكن رفع الكتب.<br><br></p>
                                    <button class="indexButton" name="goBookPageButton" onclick="window.location = 'books.php';">اذهب</button>
                                    <br> <br>
									عدد الكتب المتوفرة: 
									<?php
									$sqlCountBooks = "SELECT COUNT(bookid) as total FROM books where type='book'";
									$result = mysqli_query($connection, $sqlCountBooks);
									$totalBook = mysqli_fetch_array($result);
									echo $totalBook['total'];
									?>
                                    <br> <br>
									</th>
                                <th class="home2" valign="top">
                                    
                                    <br><img src="images/agenda.png" width="100" height="100">
                                    <br>
                                    <h2>المذكرات</h2>
                                    <p>يتوفر في هذا القسم المذكرات الخاصة بالمواد، وعروض البوربوينت<br><br></p>
                                    <button class="indexButton" name="goNotesPageButton" onclick="window.location = 'memories.php';">اذهب</button>
                                    <br> <br>
                                    عدد المذكرات المتوفرة:
									<?php
									$sqlCountBooks = "SELECT COUNT(bookid) as total FROM books where type='memory'";
									$result = mysqli_query($connection, $sqlCountBooks);
									$totalBook = mysqli_fetch_array($result);
									echo $totalBook['total'];
									?>
                                    <br> <br>
									</th>
                                <th class="home3" valign="top">
                                    
                                    <br><img src="images/Mind-Map-Paper-icon.png" width="100" height="100">
                                    <br>
                                    <h2>الملخصات</h2>
                                    <p>ملخصات المواد، جداول، خرائط ذهنية، وغيرها.<br><br></p>
                                    <button class="indexButton" name="goSummriesPageButton" onclick="window.location = 'summaries.php';">اذهب</button>
                                    <br><br>
                                عدد الملخصات المتوفرة: 
									<?php
									$sqlCountBooks = "SELECT COUNT(bookid) as total FROM books where type='summary'";
									$result = mysqli_query($connection, $sqlCountBooks);
									$totalBook = mysqli_fetch_array($result);
									echo $totalBook['total'];
									?>
                                    <br> <br>
                                </th>
                            </tr>
                        </table>
                    </section>
    <br><br><br>
                    <footer>
                            <?php
                        include ('footer.php');
                        include 'visitorsCounter.php';
                        ?>
                    </footer><br>
                        </div>

                    </body>
                    </html>