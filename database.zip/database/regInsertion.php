<?php
include_once ('createConnection.php');

$userEmail = mysqli_real_escape_string($_POST["email"]);
$userPassword = mysqli_real_escape_string($_POST["pass"]);

$insertSql = "INSERT INTO user (email ,pass ,gender ,twitter ,insta ,facebook ,website ,phone ,university )"
        . "VALUES($userEmail ,$userPassword, '','','','','','')";
//$data = $connection->query($insertSql);
if( ($connection -> query($insertSql)) === TRUE){
    echo 'OK';
} else {
   echo "ERROR".$insertSql."<br>".$connection->error;
}
$connection->close();
?>