
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>شكرا لتواصلكم معنا</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body> <div class="body">
        <header>
                <?php
                include 'header.php';
                ?>
            </header>
            <br><hr><br>
            <center>
        <h1>شكرا لتواصلكم معنا</h1>
        <p id="rcorners">سوف نقوم بمراجعة رسالتك ، نشكر لك تعاونك 
            <br>
            مع تحيات : فريق كتابي
        </p>
        
        <a href="index.php">العودة إلى الصفحة الرئيسية</a>
         </center>
            <br><br><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
        
    </body>
</html>
