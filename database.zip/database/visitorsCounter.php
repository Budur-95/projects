<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="keyword" content="HTML,PHP">
        <meta name="description" content="this page to count the visitor of index page">
        <meta name="author" content="Hadeel">
        <title></title>
    </head>
    <body>
        <!--This code taken from youtube, and we modified to be fit with our project
        url: https://www.youtube.com/pH_8hpSel-A//-->
        <?php
        include_once 'createConnection.php';

        $query = "UPDATE `views` SET `counter`=`counter`+1 WHERE 1";
        mysqli_query($connection, $query);

        $sql = "SELECT counter FROM views WHERE id='1'";
        $result = mysqli_query($connection, $sql);
        $row = mysqli_fetch_assoc($result);
        $counter = $row['counter'];

        echo"THIS PAGE HAS BEEN VIEWD  " . $counter . "  TIMES";
        ?>    
    </body>
</html>