<?php include_once 'createConnection.php'; ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="register New user">
        <meta name="author" content="Hadeel">
        <link href="style.css" type="text/css" rel="stylesheet" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
     <!--   <script src="JQuery.js"></script> -->
        <title>تسجيل عضو جديد</title>
    </head>
    <body>
        <div class="body">
            <header>
                <?php
                include 'header.php';
                ?>
            </header>
            <br><hr><br>
            <h1>تسجيل عضو جديد</h1>
            <?php
            // Validation of information in the form
            $name = $email = $conEmail = $phone = $password = $conPassword = $gender = $website = $twiiter = $instagram = $facebook = "";
            $nameEr = $emailEr = $phoneEr = $passwordEr = $genderEr = $websiteEr = $twiiterEr = $instagramEr = $facebookEr = "";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (empty($_POST["name"])) {
                    $nameEr = "name is required";
                } else {
                    $name = clear_input($_POST["name"]);
                    if (!preg_match("/^[a-zA-Z]*$/", $name)) {
                        $nameEr = "Only letters & whitespace";
                    }
                }
                if (empty($_POST["email"])) {
                    $emailEr = "email is required";
                } else {
                    $email = clear_input($_POST["email"]);
                    if (!FILTER_VAR($email, FILTER_VALIDATE_EMAIL)) {
                        $emailEr = "Invalid email format";
                    }
                }
                if (empty($_POST["conEmail"])) {
                    $emailEr = "email is required";
                } else {
                    $conEmail = clear_input($_POST["conEmail"]);
                    if (!FILTER_VAR($conEmail, FILTER_VALIDATE_EMAIL)) {
                        $emailEr = "Invalid email format";
                    }
                }
                if (empty($_POST["phone"])) {
                    $phone = "";
                } else {
                    $phone = clear_input($_POST["phone"]);
                    //write phone number validation here
                    if (!preg_match("/^[0-9]{10}$/", $phone)) {
                        $phoneEr = "Enter a correct number";
                    }
                }
                if (empty($_POST["password"])) {
                    $passwordEr = "Please enter a password";
                } else {
                    $password = clear_input(md5($_POST["password"]));
                    //write password validation here
                }
                if (empty($_POST["conPassword"])) {
                    $passwordEr = "please confirm the password";
                } else {
                    $conPassword = clear_input(md5($_POST["conPassword"]));
                    if ($conPassword != $password) {
                        $passwordEr = "Not are the same";
                    }
                }
                if (empty($_POST["website"])) {
                    $website = "";
                } else {
                    $website = clear_input($_POST["website"]);
                    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[a-z0-9+&@#\/%=~_|]/i", $website)) {
                        $websiteEr = "invalid URL";
                    }
                }
                if (empty($_POST["gender"])) {
                    $genderEr = "please choose";
                } else {
                    $gender = clear_input($_POST["gender"]);
                }
                if (empty($_POST["twitter"])) {
                    $twiiter = "";
                } else {
                    $twiiter = clear_input($_POST["twitter"]);
                }
                if (empty($_POST["instagram"])) {
                    $instagram = "";
                } else {
                    $instagram = clear_input($_POST["instagram"]);
                }
                if (empty($_POST["facebook"])) {
                    $facebook = "";
                } else {
                    $facebook = clear_input($_POST["facebook"]);
                }
                if (empty($_POST["collage"])) {
                    $collage1 = "";
                } else {
                    $collage1 = clear_input($_POST["collage"]);
                }

                if (empty($_POST["uni"])) {
                    $uni = "";
                } else {
                    $uni = clear_input($_POST["uni"]);
                }
            }

            function clear_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            ?>

            <form  action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
                <div class="conditionRegister">
                    <h3 class='condition'>شروط التسجيل</h3>
                    <p><ul>
                        <li>اختيار اسم مستخدم لا يخدش الحياء العام والعادات والتقاليد </li>
                        <li>إدخال بيانات صحيحة لسرعة التواصل معك في حال قمت برفع كتاب أو مذكرة</li>
                        <li>الموقع غير مسؤول عن ضياع ممتلكاتك أو تلفها من قبل الطرف الآخر</li>
                        <li>معلومات التواصل التي يتم تسجيلها سيتم عرضها للعامة</li>

                    </ul>
                    <input type="checkbox" name="registerCondition" value="أقر بموافقتي على الشروط" class='agreeCondition' />أقر بموافقتي على الشروط
                    </p>
                </div><br><br>

                <fieldset>
                    <legend>معلومات شخصية</legend>
                    <table>
                        <tr>
                            <td><label>الاسم</label></td>
                            <td><input type="text" name="name" value="<?php echo $name; ?>" class="text" required /></td>
                            <td><span class="error"></span><?php echo "*"; ?></td>
                            <td></td>
                        </tr>
                        <tr><td><label>البريد الإلكتروني</label></td>
                            <td><input type="email" name="email" class="text" value="<?php echo $email; ?>" required/></td>
                            <td><label>تأكيد البريد الإلكتروني</label></td>
                            <td><input type="email" name="conEmail" class="text" value="<?php echo $email; ?>" required/>
                                <span class="error"></span><?php echo "*"; ?><br></td>
                        </tr>
                        <tr>
                            <td><label>كلمة المرور</label></td>
                            <td><input type="password" name="password" class="text" required></td>
                            <td><label>تأكيد كلمة المرور</label></td>
                            <td><input type="password" name="conPassword" class="text" required />
                                <span class="error"></span><?php echo "*"; ?></td>
                        </tr>
                        <tr>
                            <td><label>الجنس :</label></td>
                            <td><input id="female" type="radio" name="gender" value="female"
                                       <?php if (isset($gender) && $gender == "fmale") echo"checked"; ?> /><label for="female">أنثى</label>
                                <input id="male" type="radio" name="gender" value="male"
                                       <?php if (isset($gender) && $gender == "fmale") echo"checked"; ?>/><label for="male">ذكر</label></td>

                            <td></td>
                           </tr>  <td></td>
                        <tr>
                        <td><label>الجامعة :</label></td>
                        <td>
<select name = "uni">


 <option value="جامعة ام القرى">جامعة ام القرى</option>
 <option value="جامعة الملك خالد">جامعة الملك خالد</option>
 <option value="جامعة الملك فهد للبترول والمعادن ">جامعة الملك فهد للبترول والمعادن </option>
 <option value="جامعة الاميرة نورة ">جامعة الاميرة نورة </option>
 <option value="جامعة القصيم">جامعة القصيم</option>
 <option value="جامعة الملك عبدالعزيز">جامعة الملك عبدالعزيز</option>

 </select></td>
                        </tr>

<tr>

<td><label>الكلية :</label></td>
<td>



<select name="collage" >
                                            <option value="-1">اختر الكلية من القائمة</option>
                                            <option value="كلية الشريعة والدراسات الإسلامية">كلية الشريعة والدراسات الإسلامية</option>
                                            <option value="كلية الدعوة وأصول الدين">كلية الدعوة وأصول الدين</option>
                                            <option value="كلية إدارة الأعمال">كلية إدارة الأعمال</option>
                                            <option value="كلية العلوم التطبيقية">كلية العلوم التطبيقية</option>
                                            <option value="كلية الهندسة والعمارة الإسلامية">كلية الهندسة والعمارة الإسلامية</option>
                                            <option value="كلية الحاسب الآلي ونظم المعلومات">كلية الحاسب الآلي ونظم المعلومات</option>
                                            <option value="كلية الطب">كلية الطب</option>
                                            <option value="كلية طب الأسنان">كلية طب الأسنان</option>
                                            <option value="كلية الصحة العامة والمعلوماتية الصحية">كلية الصحة العامة والمعلوماتية الصحية</option>
                                            <option value="كلية الصيدلة">كلية الصيدلة</option>
                                            <option value="كلية التمريض">كلية التمريض</option>
                                            <option value="كلية التصاميم">كلية التصاميم</option>


    </select>

</td>    </tr>

                    </table>
                </fieldset>
                <br><br>
                <fieldset>
                    <legend>معلومات التواصل</legend>
                    <table><tr>
                            <td><label>البريد الإلكتروني</label></td>
                            <td><input type="email" name="email" class="text" value="<?php echo $email; ?>" /></td>
                            <td><label>تويتر</label></td>
                            <td><input type="text" name="twitter" class="text" />
                                <span class="error"></span><?php echo "*"; ?></td>
                        </tr>
                        <tr>
                            <td><label>رقم الهاتف</label></td>
                            <td><input type="number" name="phone" class="text" value="<?php echo $phone; ?>">
                                <span class="error"></span><?php echo "*"; ?></td>
                            <td><label>انستقرام</label></td>
                            <td><input type="text" name="instagram" class="text" value="<?php echo $instagram; ?>">
                                <span class="error"></span><?php echo "*"; ?></td>
                        </tr>
                        <tr>
                            <td><label>موقع شخصي</label></td>
                            <td><input type="text" name="website" class="text" value="<?php echo $website; ?>">
                                <span class="error"></span><?php echo "*"; ?></td>
                            <td><label>فيس بوك</label></td>
                            <td><input type="text" name="facebook" class="text" value="<?php echo $facebook; ?>">
                                <span class="error"></span><?php echo "*"; ?></td>
                        </tr>
                    </table>
                </fieldset>
                <br>
                <p class="bulletin">هل تريد إرسال النشرة الدورية إلى بريدك الالكتروني؟<br>
                    <input type="checkbox" name="bulletin" value="نعم أرسل لي النشرة الدورية" />نعم أرسل لي النشرة الدورية
                </p><br>

                <input type="submit" name="submitBtn" value="تسجيل" class="register" id="submit" />
                <input id="button" type="reset" value="مسح" class="clear" />
                <a href="index.php"><input id="button" type="button" value="إلغاء" class="cancel" /></a>
                <br><br><br>
            </form>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
        <?php
        // to get info from form then insert it into database
        if (isset($_POST["submitBtn"])) {
            if (!empty($_POST["registerCondition"])) {
                if ($password == $conPassword) {
                    if ($email == $conEmail) {
                        $sql = "SELECT * FROM user WHERE email = '$email'";
                        $sqlRun = mysqli_query($connection, $sql);

                        if (mysqli_num_rows($sqlRun) > 0) {
                            echo "<script type='text/javascript'> alert('هذا البريد الإلكتروني مستخدم من قبل')</script> ";
                        } else {
                            $sql = "INSERT INTO user (userid,username,email,pass,gender,insta ,facebook ,website ,phone ,twitter,collage,university )"
                                    . "VALUES (NULL,'$name','$email','$password','$gender','$instagram','$facebook','$website','$phone','$twiiter','$collage1','$uni')";
                            if ($connection->query($sql) === TRUE) {
                                echo "<script type='text/javascript'> alert('تم التسجيل بنجاح')</script> ";// when registor ok
                                echo "<script> window.location.href ='index.php'; </script>";// go to home page
                            } else {
                                echo "<script type='text/javascript'> alert('هناك مشكلة في التسجيل')</script> ";
                            }
                        }
                    } else {
                        echo "<script type='text/javascript'> alert('فضلا قم بإعادة إدخال البريد الإلكتروني وتأكيده')</script> ";
                    }
                } else {
                    echo "<script type='text/javascript'> alert('كلمتي المرور غير متطابقة')</script> ";
                }
            } else {
                echo "<script type='text/javascript'> alert('عفوا يجب أن توافق على شروط الموقع أولا')</script> ";
            }
        }
        ?>
    </body>
</html>