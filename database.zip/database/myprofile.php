<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">
    <head>
        <title> ملفي الشخصي  </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="this page for allow the user to update his info">
        <meta name="author" content="Nouf">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <div class="body" >
            <header>
                <?php
                // to include the header of all pages , and the page of the connection to sql
                include 'header.php';
                include'createConnection.php';
                ?>
            </header>
            <br><hr><br>
            <h1>تعديل الملف الشخصي</h1>
            <br><br>
            <fieldset id="owener2">
                <legend>معلوماتي</legend>
                <div style='float:right' >
                    <br><br> <h2><br>
                        <?php
                        //getting the user id that is sent to the link ..
                        $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $parts = Explode('?', $url);
                        $id = $parts[count($parts) - 1];


// fetching informtaion from the user table in the database
                        $sql = "SELECT * FROM user WHERE userid=" . $id;
                        $result = mysqli_query($connection, $sql);
                        while ($row = mysqli_fetch_array($result)) {
                            echo $row['username'];
                            $idForUser = $row['userid'];
                            $userEmail = $row['email'];
                              $useruni = $row['uni'];
                            $userInsta = $row['insta'];
                            $userFace = $row['facebook'];
                            $userWebsite = $row['website'];
                            $userPhone = $row['phone'];
                            $userTwitt = $row['twitter'];
                        }
                        ?></h2>
                    <br><br>

                    <div>
                        <form enctype="multipart/form-data" method="post" onsubmit="return verification()" >
                            <table>
                                <tr>
                                <tr><td><h3>  المعلومات الاساسية:</h3></td></tr>


                                <div class="pass">

                                    <!-- form for changing the user information --->

                                    <tr><td><label for="pass1">كلمة المرور</label></td>
                                        <td><input type="password" name="pass1" id="pass1" class="text" required /></td>
                                    <tr><td><label for="pass2">تأكيد كلمة المرور</label></td>
                                        <td><input type="password" name="pass2" id="pass2" class="text"onkeyup="checkPass(); return false;" required/>
                                            <span id="confirmMessage" class="confirmMessage"></span></td>
                                </div>
                                </tr>
                                <tr>
                                <div class="email">
                                    <td><label for="email1">البريد الإلكتروني</label></td>
                                    <td><input type="email" name="email1" value="<?php echo $userEmail; ?>" id="email1" class="text" required/></td></tr>
                                    <tr>
                                        <td><label for="email2">تأكيد البريد الإلكتروني</label></td>
                                        <td><input type="email" name="email2"id="email2" value="<?php echo$userEmail; ?>" class="text"onkeyup="checkMail(); return false;" required/>
                                            <span id="confirmMessage2" class="confirmMessage2"></span></td>
                                </div>
                                </tr>

                                <tr>
                                    <td><label for="email1">الجامعة</label></td>
                                    <td>
<select name = "uni">


 <option value="جامعة ام القرى">جامعة ام القرى</option>
 <option value="جامعة الملك خالد">جامعة الملك خالد</option>
 <option value="جامعة الملك فهد للبترول والمعادن ">جامعة الملك فهد للبترول والمعادن </option>
 <option value="جامعة الاميرة نورة ">جامعة الاميرة نورة </option>
 <option value="جامعة القصيم">جامعة القصيم</option>
 <option value="جامعة الملك عبدالعزيز">جامعة الملك عبدالعزيز</option>

 </select>
                                    </td>    </tr>

<tr>
<td><label for="email1">الكلية</label></td>
<td>
<select name="collage" >

                                           <option value="-1">اختر الكلية من القائمة</option>
                                            <option value="كلية الشريعة والدراسات الإسلامية">كلية الشريعة والدراسات الإسلامية</option>
                                            <option value="كلية الدعوة وأصول الدين">كلية الدعوة وأصول الدين</option>
                                            <option value="كلية إدارة الأعمال">كلية إدارة الأعمال</option>
                                            <option value="كلية العلوم التطبيقية">كلية العلوم التطبيقية</option>
                                            <option value="كلية الهندسة والعمارة الإسلامية">كلية الهندسة والعمارة الإسلامية</option>
                                            <option value="كلية الحاسب الآلي ونظم المعلومات">كلية الحاسب الآلي ونظم المعلومات</option>
                                            <option value="كلية الطب">كلية الطب</option>
                                            <option value="كلية طب الأسنان">كلية طب الأسنان</option>
                                            <option value="كلية الصحة العامة والمعلوماتية الصحية">كلية الصحة العامة والمعلوماتية الصحية</option>
                                            <option value="كلية الصيدلة">كلية الصيدلة</option>
                                            <option value="كلية التمريض">كلية التمريض</option>
                                            <option value="كلية التصاميم">كلية التصاميم</option>
 </select>
                                    </td>    </tr>




                                <tr>          <td><h3>  معلومات التواصل : </h3></td>

                                </tr>
                                <tr>
                                    <td><img src="images/facebook.png" class="contactinginfo"></td>

                                    <td><input type="text" name="face" class="text"id="face" value="<?php echo$userFace; ?>" /></td>
                                </tr>
                                <tr>
                                    <td><img src="images/instagram.png" class="contactinginfo"></td>
                                    <td><input type="text" name="insta" class="text"id="insta" value="<?php echo$userInsta; ?>" /></td>
                                </tr>
                                <tr>         <td><img src="images/twitter.png" class="contactinginfo"></td>
                                    <td><input type="text" name="twitt" class="text"id="twitt" value="<?php echo$userTwitt; ?>" /></td>
                                </tr>
                                <tr>
                                    <td><img src="images/website.jpg" class="contactinginfo"></td>
                                    <td><input type="text" name="website" class="text" id="website" value="<?php echo$userWebsite; ?>"/></td>
                                </tr>
                                <tr>
                                    <td><img src="images/phonenumber.png" class="contactinginfo"></td>
                                    <td><input type="text" name="phonenumber" class="text" id="phonenumber" value="<?php echo$userPhone; ?>"/></td>
                                </tr>


                                <tr> <td> <input  type="submit" value="تعديل"/>
                                        <input type="reset"value="مسح"  /></td></tr></table>
                        </form>
                    </div>
            </fieldset>
            <?php
//checking if the post method activated ..
            if ($_SERVER["REQUEST_METHOD"] == "POST") {



                //fetching the information from the form and updating the tables in database ..
                if (isset($_POST["pass1"])) {
                    $pass = md5($_POST["pass1"]);
                    $update = "UPDATE user SET pass='" . $pass . "' WHERE userid='" . $idForUser . "'";

                    if ($connection->query($update) === TRUE) {

                    } else {
                        echo "Error updating password: " . $connection->error;
                    }
                }
                if (isset($_POST["email1"])) {
                    $update = 'UPDATE user SET email="' . $_POST['email1'] . '" WHERE userid="' . $idForUser . '"';


                    if ($connection->query($update) === TRUE) {
                        //alert to inform that the information updated succesfully..
                        echo "<script type='text/javascript'> alert('تم تعديل معلوماتك بنجاح')</script> ";
                    } else {
                        echo "Error updating email: " . $connection->error;
                    }
                }

                if (isset($_POST["collage"])) {
                    $update = 'UPDATE user SET collage="' . $_POST['collage'] . '" WHERE userid="' . $idForUser . '"';


                    if ($connection->query($update) === TRUE) {

                    }
                else {
                        echo "Error updating collage: " . $connection->error;
                    }
                 }

                 if (isset($_POST["uni"])) {
                    $update = 'UPDATE user SET universty="' . $_POST['uni'] . '" WHERE userid="' . $idForUser . '"';


                    if ($connection->query($update) === TRUE) {

                    }
                else {
                        echo "Error updating universty: " . $connection->error;
                    }
                 }



                if (isset($_POST["face"])) {

                    $update = 'UPDATE user SET facebook="' . $_POST['face'] . '" WHERE userid="' . $idForUser . '"';

                    if ($connection->query($update) === TRUE) {

                    } else {

                        echo "Error updating facebook: " . $connection->error;
                    }
                }

                if (isset($_POST["insta"])) {
                    $update = 'UPDATE user SET insta="' . $_POST['insta'] . '" WHERE userid="' . $idForUser . '"';

                    if ($connection->query($update) === TRUE) {

                    } else {
                        echo "Error updating insta: " . $connection->error;
                    }
                }

                if (isset($_POST["twitt"])) {
                    $update = 'UPDATE user SET twitter="' . $_POST['twitt'] . '" WHERE userid="' . $idForUser . '"';

                    if ($connection->query($update) === TRUE) {

                    } else {
                        echo "Error updating twitter: " . $connection->error;
                    }
                }

                if (isset($_POST["website"])) {
                    $update = 'UPDATE user SET website="' . $_POST['website'] . '" WHERE userid="' . $idForUser . '"';

                    if ($connection->query($update) === TRUE) {

                    } else {
                        echo "Error updating website: " . $connection->error;
                    }
                }
                if (isset($_POST["phonenumber"])) {
                    $update = 'UPDATE user SET phone="' . $_POST['phonenumber'] . '" WHERE userid="' . $idForUser . '"';

                    if ($connection->query($update) === TRUE) {

                    } else {
                        echo "Error updating phone number: " . $connection->error;
                    }
                }
            }
            ?>

            <script>


                function checkPass()
                {
                    //Store the password field objects into variables ...
                    var pass1 = document.getElementById('pass1');
                    var pass2 = document.getElementById('pass2');
                    //Store the Confimation Message Object ...
                    var message = document.getElementById('confirmMessage');
                    //Set the colors we will be using ...
                    var goodColor = "#66cccc";
                    var badColor = "#e08e79";
                    //Compare the values in the password field
                    //and the confirmation field
                    if (pass1.value == pass2.value) {
                        //The passwords match.
                        //Set the color to the good color and inform
                        //the user that they have entered the correct password
                        pass2.style.backgroundColor = goodColor;
                        message.style.color = goodColor;
                        message.innerHTML = ":) Passwords Match";
                        return true;
                    } else {
                        //The passwords do not match.
                        //Set the color to the bad color and
                        //notify the user.
                        pass2.style.backgroundColor = badColor;
                        message.style.color = badColor;
                        message.innerHTML = ":( Passwords Do Not Match";
                        return false;
                    }
                }


                function checkMail()
                {
                    //Store the email field objects into variables ...
                    var email1 = document.getElementById('email1');
                    var email2 = document.getElementById('email2');
                    //Store the Confimation Message Object ...
                    var message = document.getElementById('confirmMessage2');
                    //Set the colors we will be using ...
                    var goodColor = "#66cccc";
                    var badColor = "#e08e79";
                    //Compare the values in the email field
                    //and the confirmation field
                    if (email1.value == email2.value) {
                        //The email match.
                        //Set the color to the good color and inform
                        //the user that they have entered the correct email
                        email2.style.backgroundColor = goodColor;
                        message.style.color = goodColor;
                        message.innerHTML = ":) Email Match ";
                        return true;
                    } else {
                        //The email do not match.
                        //Set the color to the bad color and
                        //notify the user.
                        email2.style.backgroundColor = badColor;
                        message.style.color = badColor;
                        message.innerHTML = ":( Email Do Not Match ";
                        return false;
                    }
                }

                function verification()
                {
                    var email = document.getElementById('email1');
                    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

                    if (!filter.test(email.value)) {
                        alert('Please provide a valid email address');
                        email.focus;
                        return false;
                    }

                    var1 = document.getElementById("face").value;
                    var2 = document.getElementById("insta").value;
                    var3 = document.getElementById("twitt").value;
                    var4 = document.getElementById("website").value;
                    var5 = document.getElementById("phonenumber").value;
                    if ((var1 == "") && (var2 == "") && (var3 == "") && (var4 == "") && (var5 == ""))
                    {
                        alert("Please fill at least one field in social media");
                        return false;
                    }
                    if (checkMail()) {

                        return true;
                    } else {
                        alert("email not matched please check your email");
                        return false;

                    }
                    if (checkPass()) {

                        return true;
                    } else {
                        alert("password is not matched please check your password");
                        return true;
                    }
                }
            </script>

            <br><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer><br></div>
    </body>
</html>