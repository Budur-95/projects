<!DOCTYPE html>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <title>البحث في الموقع</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body>  <div class="body">
        <header>
            <?php
            include 'header.php';
            ?>
        </header>
        
            <br><hr><br>
            <h1>البحث في الموقع</h1>
            <br> 
            <form class="searchWeb">
                <input type="text" name="search" class="searchWeb" />
                <input id="submit" type="submit" value="بحث" />
            </form>
            
            <br><br><br>
        <footer>
                            <?php
                        include ('footer.php');
                        ?>
        </footer><br></div>
    </body>
</html>
