
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>المفضلة</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="this page for view the list of favorite book">
        <meta name="author" content="Sara">        
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body><div class="body">
            <header>
                <?php
                // to include the header of all pages , and the page of the connection to sql
                include 'header.php';
                include 'createConnection.php';
                ?>
            </header>
            <br><hr><br>


            <?php
            //getting the user id that is sent to the link ..
            $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $parts = Explode('?', $url);
            $id = $parts[count($parts) - 1];
            ?>
            <h1>المفضلة</h1>
            <br><br>
            <div class="scroll">

                <?php
                // fetching informtaion from the favorite table in the database 
                $sql = "SELECT * FROM favorite WHERE userid='$id'";
                $result = mysqli_query($connection, "$sql");
                if ((mysqli_num_rows($result) == 0)) { //checking if there is result if not print that there is no books 
                    echo '<h2 class="myBooks">لا توجد كتب في مفضلتك </h2>';
                } else {
// if there is books the following code will select it and output in a table ..
                    echo'<br> <table width="700"id="myTable" border=" 1px solid #774e38">';
                    while ($row = mysqli_fetch_array($result)) {
                        $idBook = $row['bookid'];
                        $sql2 = "SELECT * FROM books WHERE bookid='$idBook'";
                        $result2 = mysqli_query($connection, "$sql2");
                        while ($row2 = mysqli_fetch_array($result2)) {
                            ?><form enctype="multipart/form-data" method="post">
                                <?php
                                echo '<tr class="myBook">'
                                . ' <td class="myBook">'
                                . '<img src="data:image/jpeg;base64,' . base64_encode($row2['cover']) . '" height="200" width="150"/>'
                                . '</td><td class="myBook">اسم الكتاب : ' . $row2['bookname'] . ''
                                . '<br><br> المؤلف: ' . $row2['author']
                                . '<br><a href="bookInfo.php?' . $row2['bookid'] . '"><h4>للمزيد-اضغط هنا</h4></a></td>'
                                . '<td class="myBook">'
                                . '<input name="row_id" type="hidden" value="' . $row2['bookid'] . '" />'
                                . '<input type="submit" name= "deletebook" onclick="deleteRow(r)" value= "&#9829; ازالة من المفضلة"></td></tr>'
                                ;
                                ?></form><?php
                        }
                    }
                    echo '</table>';
                }

                //if the deleted from favorite is clicked then the following code will delete the book from favorite table ..
                if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                    if (isset($_POST['deletebook'])) {
                        $idbook = $_POST['row_id'];
                        $sql3 = mysqli_query($connection, "DELETE FROM favorite WHERE bookid='" . $idbook . "'");

                        echo "<script> window.location.href ='favorite.php?$id'; </script>";
                    }
                }
                ?>
                <script>
<!--the following code will delete the row where the button of deleting from favorite was clicked -->
                    function deleteRow(r) {
                        var i = r.parentNode.parentNode.rowIndex;
                        document.getElementById("myTable").deleteRow(i);
                </script>

                <br><br><br>
                <br></div><br>
            <footer>
                <?php
                include ('footer.php');
                ?>
            </footer>
        </div>
    </body>

</html>