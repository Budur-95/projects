<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html dir="rtl" lang="ar">
        <head>
                <title>معلومات الكتاب</title>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <meta name="keyword" content="HTML,CSS,Javascript,PHP">
                <meta name="description" content="this page for view information about spicific book">
                <meta name="author" content="Haya">
                <link href="style.css" type="text/css" rel="stylesheet" />
                    <script src="js.js"></script>

                    <link rel="stylesheet" href="rating.css">
                <script src="rating.js"></script>

                <script>
  /**
   * Demo in action!
   */
  (function() {
    'use strict';
    // SHOP ELEMENT
    var shop = document.querySelector('#shop');
    // DUMMY DATA
    var data = [
      {
        title: "Dope Hat",
        description: "Dope hat dolor sit amet, consectetur adipisicing elit. Commodi consectetur similique ullam natus ut debitis praesentium.",
        rating: 3
      },
      {
        title: "Hot Top",
        description: "Hot top dolor sit amet, consectetur adipisicing elit. Commodi consectetur similique ullam natus ut debitis praesentium.",
        rating: 2
      },
      {
        title: "Fresh Kicks",
        description: "Fresh kicks dolor sit amet, consectetur adipisicing elit. Commodi consectetur similique ullam natus ut debitis praesentium.",
        rating: null
      }
    ];
    // INITIALIZE
    (function init() {
      for (var i = 0; i < data.length; i++) {
        addRatingWidget(buildShopItem(data[i]), data[i]);
      }
    })();
    // BUILD SHOP ITEM
    function buildShopItem(data) {
      var shopItem = document.createElement('div');
      var html = '<div class="c-shop-item__img"></div>' +
        '<div class="c-shop-item__details">' +
          '<h3 class="c-shop-item__title">' + data.title + '</h3>' +
          '<p class="c-shop-item__description">' + data.description + '</p>' +
          '<ul class="c-rating"></ul>' +
        '</div>';
      shopItem.classList.add('c-shop-item');
      shopItem.innerHTML = html;
      shop.appendChild(shopItem);
      return shopItem;
    }
    // ADD RATING WIDGET
    function addRatingWidget(shopItem, data) {
      var ratingElement = shopItem.querySelector('.c-rating');
      var currentRating = data.rating;
      var maxRating = 5;
      var callback = function(rating) { alert(rating); };
      var r = rating(ratingElement, currentRating, maxRating, callback);
    }
  })();
</script>

        </head>
        <body>
                <div class="body">

                        <header>
                                <?php
                                include 'header.php';
                                include 'createConnection.php';
                                ?>
                        </header>
                        <br><hr><br>
                        <!--
                        in this page well view the information of book
                        -->
                        <?php
                        // get url to select specific part (id)
                        $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $parts = Explode('?', $url);
                        $id = $parts[count($parts) - 1];
                        ?>
                        <h1>معلومات الكتاب</h1>
                        <br><br>
                        <?php
                        // select the info from DB
                        echo "<fieldset><legend>معلومات الكتاب</legend><div style='float:left'  class='viewBookDiv'  id='left' >";
                        $sql = "SELECT * FROM books WHERE bookid='$id'";
                        $result = mysqli_query($connection, "$sql");
                        while ($row = mysqli_fetch_array($result)) {
                                // echo the inforamtion
                                echo'<img src="data:image/jpeg;base64,' . base64_encode($row['cover']) . '" height="300" width="200"/>
                                </div>
                                <div>

                                        <table class="bookInfo"><tr>
                                                        <td class="bookInfo"><label> اسم الكتاب:</label></td>

                                                        <td class="bookInfo"><label>' . $row['bookname'] . '</label></td>
                                                </tr>
                                                <tr></tr>
                                                <tr>
                                                        <td class="bookInfo"><label>  المؤلف: </label></td>
                                                        <td class="bookInfo"><label>' . $row['author'] . '</label></td>
                                                </tr>
                                                <tr></tr>
                                                <tr>
                                                        <td class="bookInfo"><label>  وصف حالة الكتاب :</label></td>

                                                        <td class="bookInfo"><label class="BookDes">' . $row['description'] . '</label></td>
                                                </tr>

                                                <tr></tr>
                                                <td class="bookInfo"><label> الكلية :</label></td>
                                                <td class="bookInfo"><label>' . $row['college'] . '</label></td>

                                                </tr>
                                                <tr></tr>
                                                <tr>
                                                        <td class="bookInfo"><label>  السعر : </label></td>
                                                        <td class="bookInfo"><label>' . $row['price'] . ' S.R</label></td>
                                                </tr>
                                                <tr><td class="bookInfo"><label> تقييم الكتاب : </label></td>
                                                <td> هناااااا سوي سيليكت للتقييييم حق
                                                </td></tr><tr><td></td><td>

                                                </td>
                                                </tr>
                                        </table>
                                </div>
                                </fieldset>';
                        }
                        // select the id of owner book to send to the ownerbook page
                        $sqlU = "SELECT * FROM mybooks WHERE bookid='$id'";
                        $resultU = mysqli_query($connection, "$sqlU");
                        $rowU = mysqli_fetch_array($resultU);
                        $idOwner = $rowU['userid'];
                        ?>
                        <br/>

                        <table align="center">
                                <tr>
                                        <td>
                                                <?php
                                                //for insert into favorite when the user is login
                                                if (!isset($_SESSION['email'])) { ?>
                                                        <input id="button" type="submit" value="إضافة إلى المفضلة &#9829;" onclick="favLogin()" />
                                                <?php } else { ?>
                                                        <form enctype="multipart/form-data" action="" onsubmit="return confirmFav()" method="post">
                                                                <input id="button" type="submit" value="إضافة إلى المفضلة &#9829;" name="favSubmit" /></form>
                                                        <?php } ?>
                                        </td>
                                        <td colspan="20"></td>
                                        <td>
                                                <?php
                                                // go to book owner info page when the user want to contact with the owner
                                                echo '<a href="bookOwner.php?' . $idOwner . '"> <input id="button" type="submit" value="التواصل مع مالك الكتاب" /> </a>';
                                                ?>
                                        </td>  </tr>
                        </table>

                        <br><br>

                        <?php
                        // to insert the book to favorite
                        if (htmlspecialchars($_SERVER["REQUEST_METHOD"]) == "POST") {
                                if (isset($_POST["favSubmit"])) {
                                        $emailuser = $_SESSION['email'];
                                        $sqlUser = "SELECT * FROM user WHERE email='$emailuser'";
                                        $result = mysqli_query($connection, $sqlUser);
                                        while ($rowu = mysqli_fetch_array($result)) {
                                                $userId = $rowu['userid'];
                                        }
                                        //insert
                                        $query1 = mysqli_query($connection, "INSERT INTO favorite VALUES ($userId,$id)");
                                }
                        }
                        ?>


                        <h3>قيم الكتاب</h3>
        <img src="images/star.png" style="height: 42px; width: 42px"id="star5" onclick="Change5()" />
        <img src="images/star.png" height="42" width="42" id="star4" onclick="change4()"/>
        <img src="images/star.png" height="42" width="42" id="star3" onclick="change3()"/>
        <img src="images/star.png" height="42" width="42" id="star2" onclick="change2()"/>
        <img src="images/star.png" height="42" width="42" id="star1" onclick="change1()"/>

                        <footer>
                                <?php
                                include ('footer.php');
                                ?>
                        </footer><br></div>
        </body>
</html>