<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <body> <div class="body">
        <header>
            <?php
            include 'header.php';
            ?>
        </header>
<br><hr><br>
<center>
<h1> هل نسيت كلمة المرور؟ </h1>
<h3> قم بإدخال البريد الالكتروني الذي قمت بإدخاله عند التسجيل في الموقع </h3>
<h3> سيتم ارسال رسالة إلى بريدك لاعادة تعيين كلمة المرور </h3>

<script>

function checkEmail() {

    var email = document.getElementById('txtEmail');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
    return false;
 }
}
</script>

<form class="searchWeb">
البريد الالكتروني<input type='email' id='txtEmail'class="searchWeb"/>
<br/>
<input type='submit' value='ارسال'id="submit" onclick='checkEmail();'/>
<br/>
</form>

<p><a href=''>اضغط هنا اذا لم تصلك رسالة اعادة تعيين كلمة المرور</a></p>
</center>
<br><br><br>
        <footer>
                        <?php
                        include ('footer.php');
                        ?><br>
        </footer><br></div>
</body>

</html>
