<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'createConnection.php';
date_default_timezone_set("Asia/Riyadh");
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keyword" content="HTML,CSS,Javascript,PHP">
        <meta name="description" content="header for all pages">
        <meta name="author" content="Hadeel">
        <script src="js.js"></script>
        <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
    <header>
        <table>
            <tr>
                <th rowspan="3">
                    <img name="logo" src="images/mybook logo.png" width="280" height="180" >
                </th>
            </tr>
            <tr>
                <th class="header"><br>
                    <a href="<?php echo 'index.php'; ?>"> <img name="homeIcon" src="images/home.png" width="60" height="55"><br>
                        الرئيسية</a>  
                </th>
                <th><br><?php if (!isset($_SESSION['email'])) { ?>
                        <a onclick="document.getElementById('logInId').style.display = 'block'">
                            <img name="userIcon" src="images/user.png" width="60" height="55"><br>
                            تسجيل الدخول  </a>

                        <?php
                        // change login to myProfile when user login
                    } else if (isset($_SESSION['email'])) {
                        $emailU = $_SESSION['email'];
                        $sqlUser = "SELECT * FROM user WHERE email='$emailU'";
                        $result = mysqli_query($connection, $sqlUser);
                        while ($rowu = mysqli_fetch_array($result)) {
                            $userId = $rowu['userid'];
                            echo ' <a href="myprofile.php?' . $userId . '"> <img name="homeIcon" src="images/user.png" width="60" height="55"><br>
                    الملف الشخصي</a>  ';
                        }
                    }
                    ?>
                </th>
                <th><br>
                    <a href="<?php echo 'search.php'; ?>"> 
                        <img name="searchIcon" src="images/search.png" width="60" height="55"><br>
                        البحث</a>  
                </th>
                <th><br>
                    <a href="<?php echo 'contact.php'; ?>"> <img name="contactIcon" src="images/phone.png" width="60" height="55"><br>
                        اتصل بنا</a>
                </th>
                <th><br>
                    <a href="<?php echo 'statistics.php'; ?>"> <img name="contactIcon" src="images/phone.png" width="60" height="55"><br>
                        الإحصائيات</a>
                </th>
                <th><br>
                    <a href="<?php echo 'about.php'; ?>"> 
                        <img name="aboutIcon" src="images/help-xxl.png" width="60" height="55"><br>
                        من نحن  </a>
                </th>
                <th><br><?php if (!isset($_SESSION['email'])) { ?>
                        <a onclick="conditionLogin();"> 
                            <img name="heartIcon" src="images/heart2.png" width="60" height="55"><br>
                            مفضلتي </a>

                        <?php
                        // to open favorite when user login
                    } else if (isset($_SESSION['email'])) {
                        $emailU = $_SESSION['email'];
                        $sqlUser = "SELECT * FROM user WHERE email='$emailU'";
                        $result = mysqli_query($connection, $sqlUser);
                        while ($rowu = mysqli_fetch_array($result)) {
                            $userId = $rowu['userid'];


                            echo ' <a href="favorite.php?' . $userId . '"> <img name="heartIcon" src="images/heart2.png" width="60" height="55"><br>
                    مفضلتي</a>  ';
                        }
                    }
                    ?>

                </th>
            </tr>

        </table>
        <?php
        // when user login print welcome
        if (isset($_SESSION['email'])) {
            $emailU = $_SESSION['email'];
            $sqlUser = "SELECT * FROM user WHERE email='$emailU'";
            $result = mysqli_query($connection, $sqlUser);
            $rowu = mysqli_fetch_array($result);
            $username = $rowu['username'];
            echo "<div style='text-align:center'><h4>مرحبا :" . $username . "<form method='post'></h4>
                            <input type='submit' id='submit' name='logout' class='logout' id='logouBtn' value='تسجيل الخروج' /> 
                    </form></div>";
        }
        ?>
    </header>
    <!-- LOG IN POP UP FORM -->
    <div id="logInId" class="logInClass">
        <!--
        for close sign on log in form 
        -->
        <span onclick="document.getElementById('logInId').style.display = 'none'" 
              class="close" title="Close Modal">&times;</span>

        <form class="logInForm" method="post" >
            <div id="login1">
                <br>
                <label><b>البريد الإلكتروني:</b></label><br>
                <input type="email" name="email" class="text" required><br>

                <label><b>كلمة المرور:</b></label><br>
                <input type="password" name="password" class="text" required><br><br>

                <input type="submit" id="button"  name="loginBtn" value="تسجيل الدخول">
                <br><input type="checkbox" checked="checked" id="rememberMeCheck"> تذكرني
                <br>
                <hr>
                <div class="sinupDivLoginForm">
                    <label><b>لا تملك حساب؟</b></label>
                    <input type="button" id="button" value="إنشاء حساب جديد" onclick="window.location = 'reg_form.php'"><br>
                </div>
                <div class="cancelButtonDiv"><br>
                    <input type="button" id="button" name="cancel" class="cancelButton" value="إلغاء"
                           onclick="document.getElementById('logInId').style.display = 'none'">
                    <a href="passReset.php">هل نسيت كلمة المرور؟</a>
                    <br></div><br>
            </div>
        </form>
    </div>
    <?php
    if (isset($_POST["loginBtn"])) {
        $email = $_POST["email"];
        $password = md5($_POST["password"]);

        $sql1 = "SELECT * FROM user WHERE email = '$email' AND  pass = '$password'";
        $sqlRun1 = mysqli_query($connection, $sql1);

        if (mysqli_num_rows($sqlRun1) > 0) {
            $_SESSION["email"] = $email;
            echo "<script> window.location.href ='index.php'; </script>";
        } else {
            echo "<script type='text/javascript'> alert('البريد الإلكتروني أو كلمة المرور خاطئة')</script> ";
        }
    }
    if (isset($_POST["logout"])) {
        session_destroy();
        echo "<script type='text/javascript'> alert('تم تسجيل الخروج')</script> ";
        echo "<script> window.location.href ='index.php'; </script>";
    }
    ?>
</html>