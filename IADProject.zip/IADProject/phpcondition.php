<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
        <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
<hr class="style5">
         <br><br><br>
         <h1 id="hwhatis">PHP-Condition?</h1><br><br>
         <p id="pwhatis"><b>Conditional statements are used to perform different actions based on different conditions.</b><br>
             <b> PHP Conditional Statements</b><br>
Very often when you write code, you want to perform different actions for different conditions. 
You can use conditional statements in your code to do this.<br>

In PHP we have the following conditional statements:<br>

1* <b>if statement -</b> executes some code if one condition is true<br>
2* <b>if...else statement -</b> executes some code if a condition is true and another code if that
condition is false<br>
3* <b>if...elseif....else statement -</b> executes different codes for more than two conditions<br>
4* <b>switch statement - </b>selects one of many blocks of code to be executed<br>
             
            
<b>Syntax</b>
The syntax for a basic if statement is as follows −<br>
        <p id="border">
            
            if (expression){<br>
            Statement(s) to be executed if expression is true<br>
            }</p>
        <br><p id="pwhatis">
   The initializer is used to set the start value for the counter of the number of loop iterations.
   A variable may be declared here 
   for this purpose and it is traditional to name it $i<br><br>
    <img src="images/if-else.jpg" width="220" height="280"><br>
    <b>2- If...else statement </b><br>
     
    The 'if...else' statement is the next form of control statement that allows PHP to execute
    statements in a more controlled way.<br>
    Syntax<br>

        <p id="border">if (expression){<br>
   Statement(s) to be executed if expression is true<br>
}<br><br>

else{<br>
   Statement(s) to be executed if expression is false<br>
   
}<br>
        </p>
        <p id="pwhatis">Here PHP expression is evaluated. If the resulting value is true,
            the given statement(s) in the ‘if’ block, are executed. If the expression is false,
            then the given statement(s) in the else block are executed.</p><br>
            
        <p id ="pwhatis">
            <b>3- Switch Case</b><br>
            you can use a switch statement which handles exactly this situation, and it does so more efficiently than repeated if...else if statements.<br>
            <b> Flow Chart:</b><br>
            The following flow chart explains a switch-case statement works<br>
            
            <img src="images/switch_case.jpg." width="220" height="280"><br>
            
            The objective of a switch statement is to give an expression to evaluate and several
            different statements to execute based on the value of the expression. The interpreter 
            checks each case against the value of the expression until a match is found. If nothing
            matches, a default condition will be used.<br>
        <p id="border">
            
            switch (expression)<br>
{<br>
   case condition 1: statement(s)<br>
   break;<br>
   
   case condition 2: statement(s)<br>
   break;<br>
   ...<br>
   
   case condition n: statement(s)<br>
   break;<br>
   
   default: statement(s)<br>
   }</p> 
         </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
