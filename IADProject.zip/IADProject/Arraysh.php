<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
         
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
         <br>
        <hr class="style5">
         <br><br><br>
        
        <h1>Array in C#</h1>
       
           <p>           
         Arrays are using for store similar data types grouping as a single unit. We can access Array elements by its numeric index. 
         The array indexes start at zero. The default value of numeric array elements are set to zero, and reference elements are set to null .
                     <p/>
                 <p id="m"><img src="images/Array.png"style="width:304px;height:228px;"></p >
      <h4>Integer Array</h4>   
      
      <p>Declaring and Initializing an Integer Array</p>
      
      <p>
        <code>
int[] array = new int[4]; <br><br>

array[0] = 10;<br>
array[1] = 20;<br>
array[2] = 30;<br>
array[3] = 40;<br>

         </code>
          </p> 
          <p>
              In the above code we declare an Integer Array of four elements and assign the value to array index .
              That means we assign values to array index 0 - 4.
          </p>
          <h4>We can retrieve these values from array by using a for loop.</h4>
           <p>
        <code>
            for (int i = 0; i < array.Length; i++)<br>
	{<br>
		MessageBox.Show (array[i]);<br>
	}

         </code>
          </p> 
        <?php
        // put your code here
        ?>
    </body>
</html>
