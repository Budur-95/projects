<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>  </title>
        <link rel="stylesheet"  href="css/stylle.css">
                 
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
     
    </head>
    
    <body id="ba">
        <br>
<div >
   <center>
 
    <a class="list" href="createNew.php" target="_blank" >SIGN UP</a>
     <a class="list" href="signIn.php" >SIGN IN</a>
   <a class="list" href="https://login.live.com/login.srf?wa" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="addcourse.php" ><strong>ADD COURSE</strong></a>
   </center>
    </div>
    
  



        <?php
       
        ?>
    </body>
</html>

