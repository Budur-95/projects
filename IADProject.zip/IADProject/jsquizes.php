<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Quiz c++</title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheetquize.css" />
         <script src=jc/js1.js">
        </script> 
    </head>
    <body>
         <center><h1>Quiz Questions</h1></center>
    <p>
    <form name="quiz">
    <p>
        <b>Question 1.
        <h4>Which of the following is a valid name for an identifier?
.</h4>
     
    <input type="radio" name="q1" value="foobar2">foobar2<br>
    <input type="radio" name="q1" value="2fast">2fast<br>
    <input type="radio" name="q1" value="interest rate
">interest rate
<br>


<p><b>
<hr>
Question 2.<br>
<h4>What data types can be used to store numeric values with a decimal 
point, such point, such as 3.14 ? </h4> 

<input type="radio" name="q2" value="float, double">float, double<br>
<input type="radio" name="q2" value="short, int">short, int<br>
<input type="radio" name="q2" value="long">long<br>

<p><b>
<hr>
Question 3.
<h4>	
What value is stored in variable x? </h4></b>

<p>int x;<br />
x = 2 * 3 + 4 * 5 -- 4 / 2;</p>

<input type="radio" name="q3" value="28">28<br>
<input type="radio" name="q3" value="14">14<br>
<input type="radio" name="q3" value="23">23<br>

<p><b>
<hr>
Question 4.
<h4>	
What value is stored in x after the following two statements are 
executed: </h4></b>
 
<p>int x;<br />
x = 2 / 4 * 4 / 2;
</p>

<input type="radio" name="q4" value="1">1<br>
<input type="radio" name="q4" value="0">0<br>
<input type="radio" name="q4" value="1.0">1.0<br>

<p><b>
<hr>
Question 5.
<h4>	
What will the following code output?  </h4></b>
 
<p>int oo, y;<br>
x=3;<br>
y=(++x)*2;<br>
cout << x << " " << y << endl;
</p>

<input type="radio" name="q5" value="38">38<br>
<input type="radio" name="q5" value="46">46<br>
<input type="radio" name="q5" value="48">48<br>

<p><b>
<hr>
Question 6.
<h4>	
What is the value of the bool?</h4></b>
<p>bool is_int(789.54)</p>

<input type="radio" name="q6" value="True">	
True<br>
<input type="radio" name="q6" value="False">False<br>
<input type="radio" name="q6" value="1">1<br>

<p><b>
<hr>
Question 7.
<h4>	
What happens when a null pointer is converted into bool?</h4></b>


<input type="radio" name="q7" value="An error is flagged">	
 An error is flagged<br>
<input type="radio" name="q7" value="bool value evaluates to true">bool value evaluates to true<br>
<input type="radio" name="q7" value="bool value evaluates to false">bool value evaluates to false<br>

<p><b>
<hr>
Question 8.
<h4>	
Which of the following statements are false?</h4></b>


<input type="radio" name="q8" value="bool can have two values and can be used to express logical expressions.">	
  bool can have two values and can be used to express logical expressions.<br>
<input type="radio" name="q8" value="bool cannot be used as the type of the result of the function.">bool cannot be used as the type of the result of the function.<br>
<input type="radio" name="q8" value="bool can be converted into integers implicitly"> bool can be converted into integers implicitly<br>

<p><b>
<hr>
Question 9.
<h4>	
 For what values of the expression is an if-statement block not executed?</h4></b>


<input type="radio" name="q9" value=" 0 and all negative values">	
  0 and all negative values<br>
<input type="radio" name="q9" value=" 0 and -1"> 0 and -1<br>
<input type="radio" name="q9" value="0"> 0<br>

<p><b>
<hr>

Question 10.
<h4>	
 Which of the two operators ++ and — work for the bool datatype in C++?</h4></b>


<input type="radio" name="q10" value="--">	
  --<br>
<input type="radio" name="q10" value="++"> ++<br>
<input type="radio" name="q10" value="Both"> Both<br>

<p><b>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
<p>

    <form method="post" name="Form" onsubmit="" action="">
</form>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
    answers[0] = "foobar2";
    answers[1] = "float, double";
    answers[2] = "28";
    answers[3] = "0";
    answers[4] = "48";
    answers[5] = "False";
    answers[6] = "bool value evaluates to false";
    answers[7] = "bool cannot be used as the type of the result of the function.";
    answers[8] = "0";
    answers[9] = "++";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>



        <?php
        // put your code here
        ?>
    </body>
</html>
