<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        
  
        <h1>perl loop:</h1><br>
        <p>
            A loop statement allows us to execute a statement or group of statements<br>
            multiple times and following is the general form of a loop statement in<br>
            most of the programming languages −<br><br>
            <b>1-while loop:</b><br>
            A while loop statement in Perl programming language repeatedly executes a <br>
            target statement as long as a given condition is true.<br><br>
            The syntax of a while loop in Perl programming language is −<br><br>

            while(condition)<br>
            {<br>
            statement(s);<br>
            }<br><br>
        
            <b>2-for loop:</b><br>
            A for loop is a repetition control structure that allows you to efficiently <br>
            write a loop that needs to execute a specific number of times.<br><br>
            The syntax of a for loop in Perl programming language is −<br><br>

            for ( init; condition; increment ){<br>
            statement(s);<br>
            }<br><br>
            <b>3-do while loop:</b><br>
            The syntax of a do...while loop in Perl is −<br><br>

            do<br>
            {<br>
            statement(s);<br>
            }while( condition );<br><br>
            <b>4-foreach loop:</b><br>
            The foreach loop iterates over a list value and sets the control variable <br>
            (var) to be each element of the list in turn −<br><br>
            The syntax of a foreach loop in Perl programming language is −<br><br>

            foreach var (list) {<br>
            ...<br>
            }<br><br>
            <b>5-until loop:</b><br>
            An until loop statement in Perl programming language repeatedly executes <br>
            a target statement as long as a given condition is false.<br><br>
            The syntax of an until loop in Perl programming language is −<br><br>

            until(condition)<br>
            {<br>
            statement(s);<br>
            }<br>

            
        </p>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
