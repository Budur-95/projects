<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
           <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="html.php">HTML - What Is ? </a></li>
            <li><a href="html1.php" >HTML - basics</a></li>
            <li><a href="html2.php">HTML - variables</a></li>
            <li><a href="html3.php">HTML - conditions</a></li>
            <li><a href="html4.php">HTML - Style Sheet</a></li>
            <li><a href="html6.php">HTML -  Quiz</a></li>

             
       </ul></div> 
    
    <p>
        The HTML tables allow web authors to arrange data like text, images, links, other tables, etc. into rows and columns of cells.<br>
        The HTML tables are created using the < table > tag<br>
        in which the < tr > tag is used to create table rows and < td > tag is used to create data cells.<br>
        <br>
        Example : </p>
    <div id="border">
< !DOCTYPE html >
< html ><br>
< head ><br>
< title > HTML Tables < /title ><br>
< /head ><br>
< body ><br>
< table border= "1" ><br>
< tr ><br>
< td>Row 1, Column 1< /td><br>
< td>Row 1, Column 2< /td><br>
< /tr><br>
< tr><br>
< td>Row 2, Column 1< /td><br>
< td>Row 2, Column 2< /td><br>
< /tr><br>
< /table><br>
< /body><br>
< /html><br>
    </div>
    <p>
        This will produce following result:</p>

   <div style="padding-left:11em;">
<table border="1">
<tr>
<td>Row 1, Column 1</td>
<td>Row 1, Column 2</td>
</tr>
<tr>
<td>Row 2, Column 1</td>
<td>Row 2, Column 2</td>
</tr>
</table></div>
    <br>
    <br>
    <p><b>Table Height and Width</b><br>
        You can set a table width and height using width and height attrubutes.<br>
        You can specify table width or height in terms of pixels or in terms of percentage of available screen area.<br>
        <br>
Example: </p>
    <div id="border">
    < html><br>
    < head><br>
    < title>HTML Table Width/Height< /title><br>
< /head><br>
< body><br>
 < table border="1" width="400" height="150"><br>
    < tr><br>
    < td>Row 1, Column 1< /td><br>
< td>Row 1, Column 2< /td><br>
< /tr><br>
< tr><br>
    < td>Row 2, Column 1 < /td><br>
< td>Row 2, Column 2< /td><br>
< /tr><br>
< /table><br>
    < /body><br>
< /html><br>
    </div>
<p>This will produce following result:</p>
<div style="padding-left:11em;">
<table border="1" width="400" height="150">
<tr>
<td>Row 1, Column 1</td>
<td>Row 1, Column 2</td>
</tr>
<tr>
<td>Row 2, Column 1</td>
<td>Row 2, Column 2</td>
</tr>
</table></div>
<br>
<br>
<p><b>Nested Tables</b><br>
You can use one table inside another table. Not only tables you can use almost all the tags inside table data tag < td>.
<br>
Example:<br>
Following is the example of using another table and other tags inside a table cell.<br>
<div id="border">
    < html><br>
    < head><br>
    < title>HTML Table< /title><br>
    < /head><br>
    < body><br>
    < table border="1" width="100%"><br>
    < tr><br>
    < td><br>
    < table border="1" width="100%"><br>
    < tr><br>
    < th>Name< /th><br>
    < th>Salary< /th><br>
    < /tr><br>
   < tr><br>
   < td>Ramesh Raman< /td><br>
   < td>5000< /td><br>
   < /tr><br>
   < tr><br>
   < td>Shabbir Hussein< /td><br>
< td>7000< /td><br>
< /tr><br>
   < /table><br>
   < /td><br>
 < /tr><br>
< /table><br>
< /body><br>
< /html><br>
    </div>
<p>
This will produce following result:</p>
<div style="padding-left:11em;">
<table border="1" width="100%">
<tr>
<td>
   <table border="1" width="100%">
   <tr>
   <th>Name</th>
   <th>Salary</th>
   </tr>
   <tr>
   <td>Ramesh Raman</td>
   <td>5000</td>
   </tr>
   <tr>
   <td>Shabbir Hussein</td>
   <td>7000</td>
   </tr>
   </table>
</td>
</tr>
</table></div>

</body>
</html>
