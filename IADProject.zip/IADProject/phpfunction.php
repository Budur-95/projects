<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <link rel="stylesheet" type="text/css" href="css/stylle.css">
         
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
        <br><br>
<hr class="style5">
         <br><br><br>
         <h1 id="hwhatis">PHP-Function?</h1><br><br>
         <p id="pwhatis">
             <b> Create a User Defined Function in PHP</b><br>
             A user defined function declaration starts with the word "function":<br>

             <b>Syntax</b><br>
         <p id="border">
             
             function functionName() {<br>
             code to be executed;<br>
             }<br>
             
         </p>
         <b>  <p id="pwhatis"> Note:</b> A function name can start with a letter or underscore (not a number).<br>

         <b>Tip:</b> Give the function a name that reflects what the function does!  Note: A function name can start with a letter or underscore (not a number).

         Tip: Give the function a name that reflects what the function does<br>
         In the example below, we create a function named "writeMsg()".
         The opening curly brace ( { ) indicates the beginning of the function code and the 
         closing curly brace ( } ) indicates the end of the function.
         The function outputs "Hello world!". <br>To call the function, just write its name:<br>
         <b>Example</b><br></p>
    <p id="border"><b>
             
             < ?php<br>
function writeMsg() {<br>
    echo "Hello world!";<br>
}<br><br>

writeMsg(); // call the function<br>
?><br>
             
</p></b>
          PHP Function Arguments
          Information can be passed to functions through arguments. An argument is just like a variable.<br>

Arguments are specified after the function name, inside the parentheses.
You can add as many arguments as you want, just separate them with a comma.<br>

The following example has a function with one argument ($fname). When the familyName() function 
is called, we also pass along a name (e.g. Jani), and the name is used inside the function,
which outputs several different first names, but an equal last name:  <br><br>
<b>Example:</b><br>

<p id="border">
    
    < ?php<br>
function familyName($fname) {<br>
    echo "$fname Refsnes."<br>"";<br>
}<br><br>

familyName("Jani");<br>
familyName("Hege");<br>
familyName("Stale");<br>
familyName("Kai Jim");<br>
familyName("Borge");<br>
?><br>
    
</p>
         </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
