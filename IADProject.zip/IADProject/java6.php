<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
 <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
</ul>
    
    <center><h1>Quiz Questions</h1></center>
          <div style="padding-left: 11em" >
    <p>
    <form name="quiz">
    <p>
        Question 1. </p>
        <h4>It defines the common variables and methods of a set of objects.
.</h4>
     
    <input type="radio" name="q1" value="Objects">Objects<br>
    <input type="radio" name="q1" value="Class">Class<br>
    <input type="radio" name="q1" value="Function">Function<br>
    
    
<br>


<p>
<hr>
Question 2.<br>
<h4>It is the length of the data type float.</h4> 

<input type="radio" name="q2" value="8 bits">8 bits<br>
<input type="radio" name="q2" value="16 bits">16 bits<br>
<input type="radio" name="q2" value="32 bits">32 bits<br>

<p>
<hr>
Question 3.
<h4> Which of the following is an invalid first character of an identifier? </h4>


<input type="radio" name="q3" value="4">4<br>
<input type="radio" name="q3" value="K">K<br>
<input type="radio" name="q3" value="_">_<br>

<p>
<hr>
Question 4.
<h4>Which of the following is not a primitive data type?</h4>
 

<input type="radio" name="q4" value="Long">Long<br>
<input type="radio" name="q4" value="Char">Char<br>
<input type="radio" name="q4" value="String">String<br>

<p>
<hr>
Question 5.
<h4>	Which of the following is an invalid variable declaration in Java?</h4>
 
<input type="radio" name="q5" value="Char CivilStatus =">Char CivilStatus =<br>
<input type="radio" name="q5" value="Double Salary =0.0;">Double Salary =0.0;<br>
<input type="radio" name="q5" value="Int NumberOfStudents = 250;">Int NumberOfStudents = 250;<br>

<p>
<hr>
Question 6.
<h4>Using the declaration below, what will be the final element of the array?<br> int [ ] grades = new int[35];</h4>

    <input type="radio" name="q6" value="Impossible to tell">Impossible to tell<br>
<input type="radio" name="q6" value="Grades[34]">Grades[34]<br>
<input type="radio" name="q6" value="Grades[35]">Grades[35]<br>

<p>
<hr>
Question 7.
<h4>	It is the rules of a programming language.</h4>


    <input type="radio" name="q7" value="Syntax">Syntax<br>
<input type="radio" name="q7" value="Logic">Logic<br>
<input type="radio" name="q7" value="Format">Format<br>
<p>
<hr>
Question 8.
<h4>It is the process of removing errors found in the program.</h4>


<input type="radio" name="q8" value="Editing">Editing<br>
<input type="radio" name="q8" value="Debugging">Debugging<br>
<input type="radio" name="q8" value="Compiling">Compiling<br>

<p>
<hr>
Question 9.
<h4>Which of the following is the data type used for a single character?</h4>


<input type="radio" name="q9" value="Byte">Byte<br>
<input type="radio" name="q9" value="Long">Long<br>
<input type="radio" name="q9" value="Char">Char<br>

<p>
<hr>

Question 10.
<h4>It terminates every line of code in Java.</h4>


<input type="radio" name="q10" value="}">}<br>
<input type="radio" name="q10" value=".">.<br>
<input type="radio" name="q10" value=";">;<br>

<p>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
          </div>
    
<p><form method="post" name="Form" onsubmit="" action=""></form> </p>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
    answers[0] = "Class";
    answers[1] = "32 bits";
    answers[2] = "4";
    answers[3] = "String";
    answers[4] = "Char CivilStatus =";
    answers[5] = "Grades[34]";
    answers[6] = "Syntax";
    answers[7] = "Debugging";
    answers[8] = "Char";
    answers[9] = ";";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>

    </body>
</html>
