<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
       <br><br>
<hr class="style5">
         <br><br><br>

        
         <h1>What are Variables</h1>
      
           <p><strong>
          Variable are used in C++, where we need storage for any value, which will change in program.
          Variable can be declared in multiple ways each with different memory requirements and functioning.
          Variable is the name of memory location allocated by the compiler depending upon the datatype of the variable.
            </strong> </p>
        
            <p id="m"><img src="images/v.png"style="width:304px;height:228px;"></p >
     
        
      <h4>  <b>Declaration and Initialization :</b></h4>
         <p>Variable must be declared before they are used. 
           Usually it is preferred to declare them at the starting of the program, but in C++ they can be declared in the middle of program too, but must be done before using them.</p>
         
         <p>
             Example :<br>
             <code>
                 int i;      // declared but not initialised<br>
                 char c; <br>
                int i, j, k;  // Multiple declaration
             </code>
              </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
