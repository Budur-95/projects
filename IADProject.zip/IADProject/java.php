<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
           <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
               <li><a href="java.php">Java - What Is ? </a></li>
<li><a href="java1.php" >Java - basics </a></li>
<li><a href="java2.php">Java - variables </a></li>
<li><a href="java3.php">Java - conditionals</a></li>
<li><a href="java4.php">Java - arrays</a></li>
<li><a href="java5.php">Java -  user input</a></li>
<li><a href="java6.php">Java -  Quiz </a></li>

             
            </ul></div> <br>

        
        <h1>What is Java ?</h1>
        <p>Java is a programming language used to develop software applications as well as applets that run on webpages. <br>
            <b>Java is a high level language</b> - Java's syntax allows for the use of words and commands instead of just symbols and numbers, <br>
it is closer to human languages and further from machine language. 
The advantage to Java being a high level language is that it is easier to read, write, and maintain. <br>
<b>Java is an object oriented language </b> - Define your own reusable data structures called objects as well as their attributes (properties) and things they can do (methods). 
You can also create relationships between various objects and data structures.<br>
<b>Java is a software development language AND a web language</b> - Create programs and applets (small programs that run on webpages).<br>
<b>Java is platform independent</b> - You can run the same Java programs on various operating systems without having to rewrite the code, unlike other programming languages such as C and C++.<br>
Java source code is not converted into machine language,
but into a special form of instruction known as Java byte code which is then interpreted by the Java run-time environment which instructs the operating system on what to do. <br> 
This allows Java programs to run the same way on all operating systems.</p>
</body>
</html>
    </body>
</html>
