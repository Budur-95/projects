<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        <h1>perl data types:</h1>
        <p>Perl is a loosely typed language and there is no need to specify a type<br>
            for your data while using in your program. The Perl interpreter will choose<br>
            the type based on the context of the data itself.<br><br>
            Perl has three basic data types − scalars, arrays of scalars, and hashes of <br>
            scalars, also known as associative arrays. Here is a little detail about these <br>
            data types.<br><br>
            <b>Types and Description:</b><br>
            <b>1-Scalar −</b><br>
            Scalars are simple variables. They are preceded by a dollar sign ($). A scalar<br>
            is either a number, a string, or a reference. A reference is actually an address <br>
            of a variable, which we will see in the upcoming chapters.<br><br>
            <b>2-Arrays −</b><br>
            Arrays are ordered lists of scalars that you access with a numeric index which <br>starts
            with 0. They are preceded by an "at" sign (@).<br><br>
            <b>3-Hashes −</b><br>
            Hashes are unordered sets of key/value pairs that you access using the keys as<br> subscripts.
            They are preceded by a percent sign (%).<br><br>
            <b>Numeric Literals:</b><br>
            Perl stores all the numbers internally as either signed integers or double-precision<br> floating-point
            values. Numeric literals are specified in any of the following<br> floating-point or integer formats −<br><br>
            Integer[1234]<br>
            Negative integer[-100]<br>
            Floating point[200.0]<br>
            Scientific notation[16.12E14]<br>
            Hexadecimal[0xffff]<br>
            Octal[0577]<br><br>
            <b>String Literals:</b><br>
            Strings are sequences of characters. They are usually alphanumeric values delimited by <br>either single (')
            or double (") quotes. They work much like UNIX shell quotes where <br>you can use single quoted strings and
            double quoted strings.
            


            
        </p>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
