<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
         <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
         <br>
    <p>
        Cascading Style Sheets (CSS) describe how documents are presented on screens, in print, or perhaps how they are pronounced.
        <br> W3C has actively promoted the use of style sheets on the Web since the Consortium was founded in 1994.<br>
        <br>
        Cascading Style Sheets (CSS) provide easy and effective alternatives to specify various attributes for the HTML tags.<br>
        Using CSS, you can specify a number of style properties for a given HTML element. <br>
        Each property has a name and a value, separated by a colon (:). Each property declaration is separated by a semi-colon (;).<br>
<br>
Example:<br>
First let's consider an example of HTML document which makes use of < font> tag and associated attributes to specify text color and font size:<br>
    <div id="example">
    < html><br>
    < head><br>
    < title>HTML CSS< /title><br>
< /head><br>
< body><br>
    < p>< font color="green" size="5">Hello, World!< /font>< /p><br>
< /body><br>
< /html><br></div><p>
We can re-write above example with the help of Style Sheet as follows:<br></p>
<br>
<div id="example">
    < html><br>
    < head><br>
    < title>HTML CSS< /title><br>
    < /head><br>
    < body><br>
    < p style="color:green;font-size:24px;">Hello, World!< /p><br>
< /body><br>
< /html><br>
</div>
<p>This will produce following result:</p>
<div style="padding-left: 11em">
    
<p style="color:green;font-size:24px;">Hello, World!</p>

</div>

<p>
    <b>You can use CSS in three ways in your HTML document:</b><br>
            <b>External Style Sheet</b> - Define style sheet rules in a separate .css file and then include that file in your HTML document using HTML < link> tag.<br>

            <b>Internal Style Sheet</b> - Define style sheet rules in header section of the HTML document using < style> tag .<br>

            <b>Inline Style Sheet</b> - Define style sheet rules directly along-with the HTML elements using style attribute.<br>
            <br>
            Let's see all the three cases one by one with the help of suitable examples.<br>
            <br>
            <b>External Style Sheet</b><br>
            If you need to use your style sheet to various pages, then its always recommended to define a common style sheet in a separate file.<br>
            A cascading style sheet file will have extension as .css and it will be included in HTML files using < link> tag.<br>
            <br>
            Example: <br>
            Consider we define a style sheet file style.css which has following rules:<br></b>
        <div id="example">
            .red{<br>
            color: red;<br>
            }<br>
            .thick{<br>
            font-size:20px;<br>
            }<br>
            .green{<br>
            color:green;<br>
            }<br></div><p>
            Here we defined three CSS rules which will be applicable to three different classes defined for the HTML tags. <br>
            I suggest you should not bother about how these rules are being defined because you will learn them while studying CSS. <br>
            Now let's make use of the above external CSS file in our following HTML document:<br>
            </p>
            <div id="example">
                < html><br>
                < head><br>
                < title>HTML External CSS< /title><br>
                < link rel="stylesheet" type="text/css" href="/html/style.css"><br>
                < /head><br> 
                < body><br>
                < p class="red">This is red< /p><br>

                < p class="thick">This is thick< /p><br>

                < p class="green">This is green< /p><br>

                < p class="thick green">This is thick and green< /p><br>
                < /body><br>
                < /html><br></div>
            <p>
                    This will produce following result:</p>
                <div style="padding-left:11em">
                <p style="color:red;">This is red</p>
                <p style="font-size:20px;">This is thick</p>

<p style="color:green;">This is green</p>

<p style="color:green;font-size:20px;">This is thick and green</p>
</div>
            <p>
                <b>Internal Style Sheet</b><br>
If you want to apply Style Sheet rules to a single document only then you can include those rules in header section of the HTML document using < style> tag .<br>
Rules defined in internal style sheet overrides the rules defined in an external CSS file.<br>
<br>
Example:<br>
Let's re-write above example once again, but here we will write style sheet rules in the same HTML document using < style> tag:<br></p>
            <div id="example">
&lt;html&gt;<br>
&lt;head&gt;<br>
&lt;title&gt;HTML Internal CSS&lt;/title&gt;<br>
&lt;style type="text/css"&gt;<br>
.red{<br>
color: red;<br>
   }<br>
.thick{<br>
font-size:20px;<br>
   }<br>
.green{<br>
color:green;<br>
   }<br>
&lt;/style&gt;<br>
&lt;/head&gt;<br>
&lt;body&gt;<br>
&lt;p class="red"&gt;This is red&lt;/p&gt;<br>

&lt;p class="thick"&gt;This is thick&lt;/p&gt;<br>

&lt;p class="green"&gt;This is green&lt;/p&gt;<br>

&lt;p class="thick green"&gt;This is thick and green&lt;/p&gt;<br>
&lt;/body&gt;<br>
&lt;/html&gt;<br></div>
            <p>
    This will produce following result:</p>

<div style="padding-left: 11em">
    <p style="color:red;">This is red</p>

<p style="font-size:20px;">This is thick</p>

<p style="color:green;">This is green</p>

<p style="color:green;font-size:20px;">This is thick and green</p>
</div>
<p>
    <b>Inline Style Sheet</b><br>
    You can apply style sheet rules directly to any HTML element using style attribute of the relevant tag<br>
    This should be done only when you are interested to make a particular change in any HTML element only.<br>

    Rules defined inline with the element overrides the rules defined in an external CSS file as well as the rules defined in  < style> element.<br>

    Example<br>
    Let's re-write above example once again, <br>
    but here we will write style sheet rules along with the HTML elements using style attribute of those elements.<br><p>
    
<div id="example">
    &lt;html&gt;<br>
&lt;head&gt;<br>
&lt;title&gt;HTML Inline CSS&lt;/title&gt;<br>
&lt;/head&gt;<br>
&lt;body&gt;<br>
&lt;p style="color:red;"&gt;This is red&lt;/p&gt;<br>

&lt;p style="font-size:20px;"&gt;This is thick&lt;/p&gt;<br>

&lt;p style="color:green;"&gt;This is green&lt;/p&gt;<br>

&lt;p style="color:green;font-size:20px;"&gt;This is thick and green&lt;/p&gt;<br>
&lt;/body&gt;<br>
&lt;/html&gt;<br>
</div>
<p>This will produce following result:</p>
<div style="padding-left: 11em">
    <p style="color:red;">This is red</p>

<p style="font-size:20px;">This is thick</p>

<p style="color:green;">This is green</p>

<p style="color:green;font-size:20px;">This is thick and green</p>
</div>
    </body>
</html>
