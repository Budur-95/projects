<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="ABOUT US.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br>
      <hr class="style5">
         <br><br><br>
     
        <br><br>
        <h1>Arrays in C++</h1>
       
           <p>
          <br>           
          An array is a series of elements of the same type placed in contiguous memory locations that can be individually referenced by adding an index to a unique identifier.
That means that, for example, five values of type int can be declared as an array without having to declare 5 different variables (each with its own identifier).
Instead, using an array, the five int values are stored in contiguous memory locations, and all five can be accessed using the same identifier, with the proper index.
           </p>
           <h4>Initializing arrays</h4>
           <p> By default, regular arrays of local scope (for example, those declared within a function) are left uninitialized. 
               This means that none of its elements are set to any particular value; their contents are undetermined at the point the array is declared.<br>

    <big>But the elements in an array can be explicitly initialized to specific values when it is declared, by enclosing those initial values in braces {}.<br>
        For example: </big> <br>
  
        <code>
            int foo [5] = { 16, 2, 77, 40, 12071 };
        </code>
<</p>
      <h4>arrays example</h4>
      <p>
      <code>
          #include <iostream><br>
using namespace std;<br>

int foo [] = {16, 2, 77, 40, 12071};<br>
int n, result=0;<br>

int main ()<br>
{
  for ( n=0 ; n<5 ; ++n )<br>
  {
    result += foo[n];<br>
  }<br>
  cout << result;<br>
  return 0;
}    
      </code>
      
     </p>
     
        <?php
        // put your code here
        ?>
    </body>
</html>
