<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
   <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    
        
                
<body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       


     <br><br>
           <br><br>
           <br>
           
    
          <center><h1>Quiz Questions</h1></center>
          <div style="padding-left: 11em" >
    <p>
    <form name="quiz">
    <p>
        Question 1.
        <h4>What does HTML stand for?
.</h4>
     
    <input type="radio" name="q1" value="Home Tool Markup Language">Home Tool Markup Language<br>
    <input type="radio" name="q1" value="Hyperlinks and Text Markup Language">Hyperlinks and Text Markup Language<br>
    
    <input type="radio" name="q1" value="Hyper Text Markup Language">Hyper Text Markup Language<br>
    
<br>


<p>
<hr>
Question 2.<br>
<h4>Choose the correct HTML element for the largest heading:</h4> 

<input type="radio" name="q2" value="< head >">< head ><br>
<input type="radio" name="q2" value="< h1 >">< h1 ><br>

<input type="radio" name="q1" value="< h6 >">< h6 ><br>

<p>
<hr>
Question 3.
<h4>	
    How do you make the text bold? </h4>


<input type="radio" name="q3" value="style:bold">style:bold<br>
<input type="radio" name="q3" value="font:b">font:b<br>
<input type="radio" name="q3" value=" font-weight:bold"> font-weight:bold<br>

<p>
<hr>
Question 4.
<h4>What tag tells where a link starts ? </h4>
 

<input type="radio" name="q4" value="< start >">< start ><br>
<input type="radio" name="q4" value="< l >">< l ><br>
<input type="radio" name="q4" value="< a >">< a ><br>

<p>
<hr>
Question 5.
<h4>	
What is the correct HTML for adding a background color?</h4>
 
<input type="radio" name="q5" value="1" > < body bg="yellow" ><br>
<input type="radio" name="q5" value="2"> < background > yellow < /background ><br>
    <input type="radio" name="q5" value="3"> < body style="background-color:yellow;" ><br>

<p>
<hr>
Question 6.
<h4>	
How can you make a list that lists the items with numbers?</h4>

    <input type="radio" name="q6" value="< ol >">< ol ><br>
<input type="radio" name="q6" value="< dl >">< dl ><br>
<input type="radio" name="q6" value="< ul >">< ul ><br>

<p>
<hr>
Question 7.
<h4> Which character is used to indicate an end tag </h4>


    <input type="radio" name="q7" value="<"> < <br>
<input type="radio" name="q7" value="*"> * <br>
    <input type="radio" name="q7" value="/"> / <br>

<p>
<hr>
Question 8.
<h4>	Besides&lt;b&gt;, another way to make text bold is what ?</h4>


<input type="radio" name="q8" value="< strong >">< strong ><br>
<input type="radio" name="q8" value="< fat >">< fat ><br>
<input type="radio" name="q8" value="< dark >">< dark ><br>

<p>
<hr>
Question 9.
<h4>How do you make each word in a text start with a capital letter?</h4>


<input type="radio" name="q9" value="You can't do that with CSS">You can't do that with CSS<br>
<input type="radio" name="q9" value="text-transform:capitalize">text-transform:capitalize<br>
<input type="radio" name="q9" value="text-transform:uppercase">text-transform:uppercase<br>

<p>
<hr>

Question 10.
<h4>What is the language of the Web?</h4>


<input type="radio" name="q10" value="MS Visual Basic">MS Visual Basic<br>
<input type="radio" name="q10" value="C++">C++<br>
<input type="radio" name="q10" value="HTML">HTML<br>

<p>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
          </div>
    
<p><form method="post" name="Form" onsubmit="" action=""></form> </p>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
    answers[0] = "Hyper Text Markup Language";
    answers[1] = "< h1 >";
    answers[2] = " font-weight:bold";
    answers[3] = "< a >";
    answers[4] = "3";
    answers[5] = "< ol >";
    answers[6] = "/";
    answers[7] = "< strong >";
    answers[8] = "text-transform:capitalize";
    answers[9] = "HTML";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>

    </body>
</html>
