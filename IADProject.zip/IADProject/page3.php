<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>     <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
        
        <h1>Arithmetic in Prolog</h1><br>
        <p>Prolog provides a number of basic arithmetic tools for manipulating integers (that is,<br>
            numbers of the form ...-3, -2, -1, 0, 1, 2, 3, 4...). Most Prolog implementation also<br>
            provide tools for handling real numbers (or floating point numbers) such as 1.53 or<br>
            635  105, but we’re not going to discuss these, for they are not particularly useful<br>
            for the symbolic processing tasks discussed in this course. Integers, on the other hand,<br>
            are useful for various tasks (such as finding the length of a list), so it is important to<br>
            understand how to work with them. We’ll start by looking at how Prolog handles the<br>
            four basic operations of addition, multiplication, subtraction, and division.</p><br>
        <table>
            <tr>
                <th> Arithmetic examples</th>
                <th>Prolog Notation</th>
                
            </tr>
            <tr>
                <td>6+2=8 </td>
                <td>8 is 6+2.</td>
            </tr>
            <tr>
                <td>6*2=12 </td>
                <td>12 is 6*2.</td>
            </tr>
            <tr>
                <td>6-2=4 </td>
                <td>4 is 6-2.</td>
            </tr>
            <tr>
                <td>6-8=-2 </td>
                <td>-2 is 6-8.</td>
            </tr>
            <tr>
                <td>6%2=3 </td>
                <td>3 is 6/2.</td>
            </tr>
            <tr>
                <td>7%2=3 </td>
                <td>3 is 7/2.</td>
            </tr>
            <tr>
                <td>1 is the remainder when 7 is divided by 2</td>
                <td>1 is mod(7,2).</td>
            </tr>
        </table><br>

        <p><b>Examples:</b></p>
        <p>
            ?- 8 is 6+2.<br>
            yes<br><br>
            ?- 12 is 6*2.<br>
                  yes
        </p>
        
        
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
