<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
              <script src="JavaScript/js1.js">
        </script>
    </head>
    <body >
        
        
        
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        <br><br>
        <br>
        
        
        
        
        
        
         <center><h1>Quiz Questions</h1></center>
    <p>
    <form name="quiz">
    <p>
        <b>Question 1.</b>
        <h4>f sky is blue, everyone likes it. - Write this statement as a prolog clause.?
.</h4>
     
    <input type="radio" name="q1" value="sky(blue) :- everyone(likes).">sky(blue) :- everyone(likes).<br>
    <input type="radio" name="q1" value="blue(sky), likes(X)."> blue(sky), likes(X)..<br>
    <input type="radio" name="q1" value="likes(sky,  everyone) :- blue(sky).
">likes(sky,  everyone) :- blue(sky).


<br>


<p><b>
<hr>
Question 2.<br>
<h4>?- 11 + 4 is 15.   -  How will prolog respond to this query? </h4> 

<input type="radio" name="q2" value="true">true<br>
<input type="radio" name="q2" value="fals">fals<br>


<p><b>
<hr>
Question 3.
<h4>?- owner(jack, cat(X)) :- fur(X),spots(X). - What would be the English meaning for this prolog clause.	
</h4></b>


<input type="radio" name="q3" value="jack is a owner of cat and fur and spots. 
">jack is a owner of cat and fur and spots. 
<br>
<input type="radio" name="q3" value="jack is the owner of X or jack is the owner of fur and spots ."> jack is the owner of X or jack is the owner of fur and spots .<br>
<input type="radio" name="q3" value="second answer.">second answer.<br>

<p><b>
<hr>
Question 4.
<h4>	
?- N is -(+(5,6),4).   and   ?- N is (5+6)-4.   -  Do these different queries produce the same result in prolog? </h4></b>
 

<input type="radio" name="q4" value="yes">yes<br>
<input type="radio" name="q4" value="no">no<br>


<p><b>
<hr>
Question 5.
<h4>	
dog('Buddy', likes('Buddy', toast)). - This statement is</h4></b>
 


<input type="radio" name="q5" value="Rule & Horn Clause"> Rule & Horn Clause<br>
<input type="radio" name="q5" value="Fact & Horn Clause">Fact & Horn Clause<br>
<input type="radio" name="q5" value="Not a Horn clause
">Not a Horn clause

<br>

<p><b>
<hr>
Question 6.
<h4>	
Which one from the options would return true/yes for given prolog program?</h4></b>
<p>
    boy(john,123). <br>
    girl(jane,234).<br> 
    student(john,123).<br>
</p>

<input type="radio" name="q6" value="?- girl(jane,x)">	
?- girl(jane,x)<br>
<input type="radio" name="q6" value="?- boy('john',123)."> ?- boy('john',123).<br>
<input type="radio" name="q6" value="All of above.">All of above. <br>

<p><b>
<hr>
Question 7.
<h4>	
Which one of the following is not a variable?</h4></b>


<input type="radio" name="q7" value="X_yz">	
 X_yz<br>
<input type="radio" name="q7" value="g_23A">g_23A<br>
<input type="radio" name="q7" value="both">both<br>

<p><b>
<hr>
Question 8.
<h4>A prolog query can be made up of only two subgoals.	
</h4></b>


<input type="radio" name="q8" value="true">	
 true<br>
<input type="radio" name="q8" value="false">false<br>


<p><b>
<hr>
Question 9.
<h4>	
?- vertical(seg(point(1,1),point(1,2))).</h4></b>


<input type="radio" name="q9" value="true">	
true<br>
<input type="radio" name="q9" value="false">false<br>


<p><b>
<hr>

Question 10.
<h4>	
  ?- horizontal(seg(point(1,1),point(2,Y))).</h4></b>



<input type="radio" name="q10" value="true">true<br>
<input type="radio" name="q10" value="false">false<br>

<p><b>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
<p>

    <form method="post" name="Form" onsubmit="" action="">
</form>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
     answers[0] = "likes(sky,  everyone) :- blue(sky).";
    answers[1] = "fals";
    answers[2] = "jack is a owner of cat and fur and spots.";
    answers[3] = "yes";
    answers[4] = "Fact & Horn Clause";
    answers[5] = "?- boy('john',123).";
    answers[6] = "g_23A";
    answers[7] = "true";
    answers[8] = "true";
    answers[9] = "true";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
