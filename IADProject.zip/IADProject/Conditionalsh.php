<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br><br>
        <hr class="style5">
         <br><br><br>
       <h1>Conditional in C#</h1>
       
           <p>           
          Makes the execution of a method dependent on a preprocessing identifier. 
          The Conditional attribute is an alias for ConditionalAttribute, and can be applied to a method or an attribute class.
                     <p/>
      <h4>In this example, Conditional is applied to a method to enable or disable the display of program-specific diagnostic information:</h4>                 
      <p>
        <code>
            #define TRACE_ON<br>
using System;<br>
using System.Diagnostics;<br>

public class Trace<br>
{<br>
    [Conditional("TRACE_ON")]<br>
    public static void Msg(string msg)<br>
    {<br>
        Console.WriteLine(msg);<br>
    }<br>
}<br>

public class ProgramClass<br>
{<br>
    static void Main()<br>
    {<br>
        Trace.Msg("Now in Main...");<br>
        Console.WriteLine("Done.");<br>
    }<br>
}
         </code>
          </p> 
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
