<!DOCTYPE html >
<html>
<head>
     <meta charset="utf-8"> 
     
    
    <title>SignIn</title>
             
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />

    <link href="css/style.css" rel="stylesheet">
        <script src="jc/jc.js"  type="text/javascript" ></script>
</head>

<body class="sign">
    
     <div align="left">
    <img src="images/learn.png" alt="logo" width="20%" height="40%"  >
    <br/>
    <br/>
</div>
<div id="header" class="container">
    <br/>
	<div id="menu">
		<ul>
                    
                  <li class="active"><a href="mailto:beedoo1415@hotmail.com"> Contact</a></li>

                    <li class="active"><a href="AboutUs.php"> AboutUs</a></li>
                     <li class="active"><a href="createNew.php"> creat new user</a></li>
                    <li class="active"><a href="proj.php">home page</a></li>  
                    
                    
                    
	   
	  
		</ul>
	</div>
</div>

<div id="page" class="container">
	
      <!--<img src="images/books-search.jpg" alt="...">-->

    <div class="search"> <!-- الخلفية-->
        <div class ="_form"> <!- محتوى البحث ، نعطي الخلفية شفافية لتبان الصورة بالخلف--->
        
        
			<h1 style="text-align:center">Sign in </h1>
                
        <form action="" method="POST" name ="Forms">
           
            <div align = "center">
                <p> Enter your username and password </p>
                 <input type="text" name="username" placeholder="username"  required>: UserName <br/><br/>
                 <input type="text" name="password" placeholder="password"  required>: password <br/><br/>
                 <input type="submit" href="http://localhost/IADProject/lang.php" onClick="validateForm(), location.reload()"onclick="ToPageLanguage()" value="submit">
                
                <br /><br /><br />
            
            
           <!--**************************************************************************************************-->
       <!-- Start Write into DB-->
      <div class="php" align = "center" >
      <?php
    error_reporting(E_ERROR | E_PARSE); // phpللتعامل مع الاخطاء في ال
	include("db/connectToDB.php"); // علشان اتصل بالداتابيس اللي انشاتها 
          
     /* اخذت "كلمة البحث المدخلة" في الاري بوست وخزنته في المتغير ، الاري بوست موجوده في فورم البحث*/
      $Search = $_POST['username'];
$pass =  $_POST['password'];
          /*  نخزن جميع الصفوص اللي تحقق شرط البحث */
      $bookInfo = "SELECT * FROM users  WHERE  users.username ='$Search'  &&  users.password ='$pass'";
	  $result = mysql_query($bookInfo);
   
         // شرط للتأكد من وجود نص 
    
       if($row = mysql_fetch_array($result)){
              echo "welcome to you $Search ";
          }
else {
     echo "sorry invalid username or password ";
    
    
}

    
          
          // close mysql
                mysql_close();    
          
          ?>
              
		
          
      
               
          
          
      </div>
     <!-- End Write into DB--> 
            </div>
            
        </form>
		          <!--***************** Form ends     *******************-->
        </div>
    </div>
	</div>

    

    
    
    </body>
</html>