<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
             <title></title>
           <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
              <li><a href="java.php">Java - What Is ? </a></li>
<li><a href="java1.php" >Java - basics </a></li>
<li><a href="java2.php">Java - variables </a></li>
<li><a href="java3.php">Java - conditionals</a></li>
<li><a href="java4.php">Java - arrays</a></li>
<li><a href="java5.php">Java -  user input</a></li>
<li><a href="java6.php">Java -  Quiz </a></li>

             
       </ul></div> 
        <h1>What is a variable?</h1>
        <p>

A variable is a container that stores a meaningful value that can be used throughout a program. For example, in a program that calculates tax on items you can have a few variables - one variable that stores the regular price of an item and another variable that stores the total price of an item after the tax is calculated on it. Variables store this information in a computer's memory and the value of a variable can change all through out a program.

Declaring variables

One variable in your program can store numeric data while another variable can store text data. Java has special keywords to signify what type of data each variable stores. Use these keywords when declaring your variables to set the data type of the variable.
<br>
<b >Java data types</b> <br>

<img src="http://java2learn.com/wp-content/uploads/2013/08/cmpdatatypes.png" > 
        </p>
   
    </body>
</html>
