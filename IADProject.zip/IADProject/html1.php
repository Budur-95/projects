<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="html.php">HTML - What Is ? </a></li>
            <li><a href="html1.php" >HTML - basics</a></li>
            <li><a href="html2.php">HTML - variables</a></li>
            <li><a href="html3.php">HTML - conditions</a></li>
            <li><a href="html4.php">HTML - Style Sheet</a></li>
            <li><a href="html6.php">HTML -  Quiz</a></li>

             
       </ul></div> 
    
    
        <h1>HTML Documents</h1>
        <p> All HTML documents must start with a document type declaration: &lt;!DOCTYPE html&gt;.<br>
        <br>
        The HTML document itself begins with &lt;html&gt; and ends with &lt;/html&gt;.<br>
        <br>
        The visible part of the HTML document is between &lt;body&gt; and &lt;/body&gt;.<br>
        <br>
        <br>
        Example:<p>
        <div id="example">
        &lt;!DOCTYPE html&gt;<br>
&lt;html&gt;<br>
    &lt;body&gt;<br>
        <br>
        &lt;h1&gt; My First Heading &lt;h1&gt;<br>
        &lt;p&gt;My first paragraph.&lt;/p&gt;<br>
<br>
&lt;/body&gt;<br>
&lt;/html&gt;<br>
        </div>
        <br>
        
        <p>
        <b>HTML Headings</b><br>
        HTML headings are defined with the < h1 > to < h6 > tags.<br>
<br>
        < h1 > defines the most important heading. < h6 > defines the least important heading:<br> 
        <br>
        Example:<br></p>
        <div id="example">
            < h1 >This is heading 1< /h1 ><br>
            < h2 >This is heading 2< /h2 ><br>
            < h3 >This is heading 3 < /h3 ><br>
        </div>

        <p><b>HTML Paragraphs</b><br>
            HTML paragraphs are defined with the < p > tag:<br>
            <br>
            Example<div id="example">
                < p >This is a paragraph.< /p ><br>
< p >This is another paragraph.< /p ></div>
        
        <p><b>HTML Images</b><br>
            HTML images are defined with the < img > tag.<br>
            <br>
            The source file (src), alternative text (alt), width, and height are provided as attributes:<br>
            <br>
            Example:</p><br><div id="example">
            < img src="YourImage.jpg" alt="YourImage" width="104" height="142"></div>
    </body>
    
    
</html>
