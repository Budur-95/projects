<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br><br>
        
<hr class="style5">
         <br><br><br>
        <h1>user input in C++</h1>
       
           <p> Using cin to get user input.<strong>
          </strong> <br>           
         Too many questions keep popping up with the same problem. How do I get user input from cin using >> into X type.
         Using the >> operator opens you up to alot of problems. Just try entering some invalid data and see how it handles it.

           </p>
           <h4> The example below shows you how to load information, and convert it between types.</h4>
           
            <p>
        <code>
            #include <iostream><br>
#include <string><br>
#include <sstream><br>

using namespace std;<br>

int main() {<br>

 string input = "";<br>

 // How to get a string/sentence with spaces<br>
 cout << "Please enter a valid sentence (with spaces):\n>";<br>
 getline(cin, input);<br>
 cout << "You entered: " << input << endl << endl;<br>

 // How to get a number.<br>
 int myNumber = 0;<br>

 while (true) {<br>
   cout << "Please enter a valid number: ";<br>
   getline(cin, input);<br>

   // This code converts from string to number safely.<br>
   stringstream myStream(input);<br>
   if (myStream >> myNumber)<br>
     break;<br>
   cout << "Invalid number, please try again" << endl;<br>
 }<br>
 cout << "You entered: " << myNumber << endl << endl;<br>

 // How to get a single char.<br>
 char myChar  = {0};<br>

 while (true) {<br>
   cout << "Please enter 1 char: ";<br>
   getline(cin, input);<br>

   if (input.length() == 1) {<br>
     myChar = input[0];<br>
     break;<br>
   }<br>

   cout << "Invalid character, please try again" << endl;<br>
 }<br>
 cout << "You entered: " << myChar << endl << endl;<br>

 cout << "All done. And without using the >> operator" << endl;<br>

 return 0;<br>
}<br>
Edit & Run

        </code> 
            </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
