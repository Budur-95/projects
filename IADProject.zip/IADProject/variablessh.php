<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            
        </title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
       <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
     <br><br>
<hr class="style5">
         <br><br><br>
        
       <h1>Variables and Constants in C#</h1>
      
           <p>  
           A variable represents a numeric or string value or an object of a class. 
           The value that the variable stores may change, but the name stays the same. 
           A variable is one type of field.<br>
           <strong> The following code is a simple example of how to declare an integer variable, assign it a value, and then assign it a new value. </strong><br><br>
          
        <code>
            int x = 1;  // x holds the value 1<br>
             x = 2;      // now x holds the value 2
     
         </code>
       </p>
      <h4> Constants </h4>  
      <p>
          A constant is another type of field. It holds a value that is assigned when the program is compiled, and never changes after that. 
          Constants are declared using the const keyword; they are useful for making your code more legible.<br><br>
          <code>
           const int speedLimit = 55;<br>
          const double pi = 3.14159265358979323846264338327950;
          </code>
      </p>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
