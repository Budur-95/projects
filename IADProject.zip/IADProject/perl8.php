<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        
        
        
        
        
         <center><h1>Quiz Questions</h1></center>
    <p>
    <form name="quiz">
    <p>
        <b>Question 1.</b>
        <h4>Which of the following is correct about Perl?
.</h4>
     
    <input type="radio" name="q1" value="Perl can handle encrypted Web data, including e-commerce transactions.">Perl can handle encrypted Web data, including e-commerce transactions.<br>
    <input type="radio" name="q1" value="Perl's DBI package makes web-database integration easy.">Perl's DBI package makes web-database integration easy.<br>
    <input type="radio" name="q1" value="All of the above.
">All of the above.
<br>


<p><b>
<hr>
Question 2.<br>
<h4>Which of the following special variable represents current file name? </h4> 

<input type="radio" name="q2" value="FILE">FILE<br>
<input type="radio" name="q2" value="_FILE_">_FILE_<br>
<input type="radio" name="q2" value="file">file<br>

<p><b>
<hr>
Question 3.
<h4>Which of the following is correct about Hashes?	
</h4></b>


<input type="radio" name="q3" value="A hash is a set of key/value pairs.">A hash is a set of key/value pairs.<br>
<input type="radio" name="q3" value="Hash variables are preceded by a percent (%) sign.">Hash variables are preceded by a percent (%) sign.<br>
<input type="radio" name="q3" value="All of the above.">All of the above.<br>

<p><b>
<hr>
Question 4.
<h4>	
How will you add a new key/value pair to a hash? </h4></b>
 

<input type="radio" name="q4" value="Using simple assignment">Using simple assignment<br>
<input type="radio" name="q4" value="using assign operator">using assign operator<br>
<input type="radio" name="q4" value="Both of the above.">Both of the above.<br>

<p><b>
<hr>
Question 5.
<h4>	
- Which of the following operator divides left hand operand by<br>
                right hand operand and returns remainder?</h4></b>
 


<input type="radio" name="q5" value="*">*<br>
<input type="radio" name="q5" value="/">/<br>
<input type="radio" name="q5" value="%">%<br>

<p><b>
<hr>
Question 6.
<h4>	
Which of the following operator returns true if the left<br>
                    argument is stringwise equal to the right argument?</h4></b>


<input type="radio" name="q6" value="eq">	
eq<br>
<input type="radio" name="q6" value="ne">ne<br>
<input type="radio" name="q6" value="ge">ge<br>

<p><b>
<hr>
Question 7.
<h4>	
 Which of the following operator returns a list of values counting<br>
                        (up by ones) from the left value to the right value?</h4></b>


<input type="radio" name="q7" value=".">	
 .<br>
<input type="radio" name="q7" value="x">x<br>
<input type="radio" name="q7" value="..">..<br>

<p><b>
<hr>
Question 8.
<h4>Which of the following is true about my operator?	
</h4></b>


<input type="radio" name="q8" value="Outside confined region , my variable 
                        cannot be used or accessed">	
 Outside confined region , my variable 
                        cannot be used or accessed <br>
<input type="radio" name="q8" value="Both of the above.">Both of the above.<br>
<input type="radio" name="q8" value="The my operator confines a variable to a 
                        particular region of code in which it can be used and accessed.">The my operator confines a variable to a 
                        particular region of code in which it can be used and accessed. <br>

<p><b>
<hr>
Question 9.
<h4>	
 Which of the following function renames existing file?</h4></b>


<input type="radio" name="q9" value="rename">	
  rename<br>
<input type="radio" name="q9" value="tell">tell<br>
<input type="radio" name="q9" value="seek">seek<br>

<p><b>
<hr>

Question 10.
<h4>	
  Which of the following variable context only happens inside quotes,<br>
                                  or things that work like quotes?</h4></b>


<input type="radio" name="q10" value="Interpolative">	
 Interpolative<br>
<input type="radio" name="q10" value="list"> list<br>
<input type="radio" name="q10" value="void"> void<br>

<p><b>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
<p>

    <form method="post" name="Form" onsubmit="" action="">
</form>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
     answers[0] = "All of the above.";
    answers[1] = "_FILE_";
    answers[2] = "A hash is a set of key/value pairs.";
    answers[3] = "Using simple assignment";
    answers[4] = "%";
    answers[5] = "ge";
    answers[6] = "..";
    answers[7] = "Both of the above.";
    answers[8] = "rename";
    answers[9] = "Interpolative";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>
        <?php
        // put your code here
        ?>
    </body>
</html>
