<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <script src="jc/jc.js"  type="text/javascript" ></script>
          <script src="jc/js1.js">
        </script>
 
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
         <br>
          
      <div >
   <center>
       <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="https://outlook.live.com/owa/?authRedirect=true" >CONTACT</a>
   </center>
                 
    </div>
         <br><br><br> 
          <hr class="style5">
         <br><br><br>
  
    <br>  
      <br><br>
<div id="layout">
<fieldset class="contact" onmouseover="mOver(this)" onmouseout="mOut(this)">
    <legend class="h1"><b>Any comments...:-)</b></legend>
<center>
<form >

<p class="h1"></p>
<textarea id="indexx2" cols="40" rows="4" > Click here to write ..</textarea><br />
<button type="button" onclick="valid()" id="index">send</button>
<p id="valid" ></p>
</center>
</form>
</fieldset>
        <?php
        // put your code here
        ?>
    </body>
</html>
