<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
          <link rel="stylesheet" type="text/css" href="css/stylle.css">
          
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
<hr class="style5">
         <br><br><br>
         <h1 id="hwhatis">PHP-Variables?</h1><br><br>
         <p id="pwhatis">
             The main way to store information in the middle of a PHP program is by using a variable.<br>

Here are the most important things to know about variables in PHP.<br>

1-All variables in PHP are denoted with a leading dollar sign ($).<br>

2-The value of a variable is the value of its most recent assignment.<br>

3-Variables are assigned with the = operator, with the variable on the left-hand 
side and the expression to be evaluated on the right.<br>

4-Variables can, but do not need, to be declared before assignment.<br>

5-Variables in PHP do not have intrinsic types - a variable does not know 
in advance whether it will be used to store a number or a string of characters.<br>

6-Variables used before they are assigned have default values.<br>

7-PHP does a good job of automatically converting types from one to another when necessary.<br>

8-PHP variables are Perl-like.<br>
<br>
<b>PHP has a total of eight data types which we use to construct our variables </b>−<br>
<b>Integers −</b> are whole numbers, without a decimal point, like 4195.<br>

<b>Doubles − </b>are floating-point numbers, like 3.14159 or 49.1.<br>

<b>Booleans − </b>have only two possible values either true or false.<br>

<b>NULL −</b> is a special type that only has one value: NULL.<br>

<b>Strings −</b> are sequences of characters, like 'PHP supports string operations.'<br>

<b>Arrays − </b>are named and indexed collections of other values.<br>

<b>Objects − </b>are instances of programmer-defined classes, which can package 
up both other kinds of values and functions that are specific to the class.<br>

<b>Resources −</b> are special variables that hold references to resources external to PHP 
(such as database connections).<br>
Examples :   <br>
         <p id="border">
             < ?php<br>
$txt = "Hello world!";<br>
$x = 5;<br>
$y = 10.5;<br>
?><br><br>
        another example:<br>     
         </p>
           <p id="border"> < ?php<br>
$txt = "W3Schools.com";<br>
echo "I love $txt!";<br>
?> <br></p>
         </p>
         
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
