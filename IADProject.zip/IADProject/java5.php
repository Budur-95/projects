<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
      
        <title></title>     <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>

 
    <p><b>This program tells you how to get input from user in a java program.</b><br>
        We are using Scanner class to get input from user.
        <br> This program firstly asks the user to enter a string and then the string is printed, then an integer and entered integer is also printed and finally a float and it is also printed on the screen.<br>
        Scanner class is present in java.util package so we import this package in our program.
        <br> We first create an object of Scanner class and then we use the methods of Scanner class.
        <br> Consider the statement<br>
        <br>
        Scanner a = new Scanner(System.in);<br>
        Here Scanner is the class name, a is the name of object, new keyword is used to allocate the memory and System.in is the input stream.<br> 
        Following methods of Scanner class are used in the program below :-<br>
        1) nextInt to input an integer<br>
        2) nextFloat to input a float<br>
        3) nextLine to input a string<br>
 
     import java.util.Scanner;
 <br>
class GetInputFromUser<br>
{<br>
   public static void main(String args[])<br>
   {<br>
      int a;<br>
      float b;<br>
      String s;<br>
 <br>
      Scanner in = new Scanner(System.in);<br>
 <br>
      System.out.println("Enter a string");<br>
      s = in.nextLine();<br>
      System.out.println("You entered string "+s);<br>
 <br>
      System.out.println("Enter an integer");<br>
      a = in.nextInt();<br>
      System.out.println("You entered integer "+a);<br>
 <br>
      System.out.println("Enter a float");<br>
      b = in.nextFloat();<br>
      System.out.println("You entered float "+b);<br>   
   }<br>
   }<br>
    
    </p>
    </body>
</html>
