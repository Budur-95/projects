<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <link rel="stylesheet" type="text/css" href="css/stylle.css">
         
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
        <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
        
        <br><br>
<hr class="style5">
         <br><br><br>
        <h1 id="hwhatis">PHP-Basic?</h1><br><br>
        <p id="pwhatis">
            A PHP script can be placed anywhere in the document.

A PHP script starts with  < ?php and ends with ?>;
        <p id="border"> 
        < ?php <br>
        // PHP code goes here <br>
        ?><br>
        </p>
        The default file extension for PHP files is ".php".<br>

A PHP file normally contains HTML tags, and some PHP scripting code.<br>

Below, we have an example of a simple PHP file, with a PHP script that uses a built-in 
PHP function "echo" to output the text "Hello World!" on a web page:  <br>

<p id="border"> 
<!DOCTYPE html>
< html> <br>
< body><br>

< h1>My first PHP page< /h1><br>

< ?php<br>
 echo "Hello World!";<br>
?><br>

< /body><br>
< /html><br>

</p>
<b>Comments in PHP:<br></b>
A comment in PHP code is a line that is not read/executed as part of the program.
Its only purpose is to be read by someone who is looking at the code.<br>

Comments can be used to:<br>

Let others understand what you are doing<br>
Remind yourself of what you did - Most programmers have experienced coming back
to their own work a year or two later and having to re-figure out what they did.<br>
Comments can remind you of what you were thinking when you wrote the code<br>
PHP supports several ways of commenting:<br>
<p id="border"> 

    < ?php<br>
// This is a single-line comment<br>

# This is also a single-line comment<br>

/*<br>
This is a multiple-lines comment block<br>
that spans over multiple<br>
lines<br>
*/<br>

// You can also use comments to leave out parts of a code line<br>
$x = 5 /* + 15 */ + 5;<br>
echo $x;<br>
?><br>
</p>

        </p>
        <?php
       
        ?>
    </body>
</html>
