<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
     
        <h1>perl-IF ELSE:</h1><br>
        <p>
            Perl conditional statements helps in the decision making, which require <br>
            that the programmer specifies one or more conditions to be evaluated or <br>
            tested by the program, along with a statement or statements to be executed<br>
            if the condition is determined to be true, and optionally, other statements<br>
            to be executed if the condition is determined to be false.<br><br>
            <b>1-if statement:</b><br>
            A Perl if statement consists of a boolean expression followed by one or more <br>
            statements.<br><br>
            <b>The syntax of an if statement in Perl programming language is −</b><br>
            if(boolean_expression){<br>
            # statement(s) will execute if the given condition is true<br>
            }<br><br>
            <b>2-if else statement: </b><br>
            A Perl if statement can be followed by an optional else statement, which <br>
            executes when the boolean expression is false.<br><br>
            The syntax of an if...else statement in Perl programming language is −<br><br>

            if(boolean_expression){<br>
            # statement(s) will execute if the given condition is true<br>
            }else{<br>
            # statement(s) will execute if the given condition is false<br>
            }<br><br>
            <b>3-if elseif else statement:</b><br>
            An if statement can be followed by an optional elsif...else statement,<br>
            which is very useful to test the various conditions using single if...elsif <br>
            statement.<br><br>
            The syntax of an if...elsif...else statement in Perl programming language is −<br><br>

            if(boolean_expression 1){<br>
            # Executes when the boolean expression 1 is true<br>
            }<br>
            elsif( boolean_expression 2){<br>
            # Executes when the boolean expression 2 is true<br>
            }<br>
            elsif( boolean_expression 3){<br>
            # Executes when the boolean expression 3 is true<br>
            }<br>
            else{<br>
            # Executes when the none of the above condition is true<br>
            }<br><br>
            <b>4-switch statement:</b><br>
            The synopsis for a switch statement in Perl programming language is as follows −<br><br>
            use Switch;<br>

            switch(argument){<br>
            case 1            { print "number 1" }<br>
            case "a"          { print "string a" }<br>
            case [1..10,42]   { print "number in list" }<br>
            case (\@array)    { print "number in list" }<br>
            case /\w+/        { print "pattern" }<br>
            case qr/\w+/      { print "pattern" }<br>
            case (\%hash)     { print "entry in hash" }<br>
            case (\&sub)      { print "arg to subroutine" }<br>
            else              { print "previous case not true" }<br>
            }<br>
            
        </p>
        
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
