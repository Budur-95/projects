



<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
        
 <ul id="e">
           <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="http://localhost/IADProject/jswhatis.php">JavaScript - What Is ? </a></li>
            <li><a href="http://localhost/IADProject/jsbasics.php">JavaScript - Syntax </a></li>
            <li><a href="http://localhost/IADProject/jsvariables.php">JavaScript -  Variables</a></li>
            <li><a href="http://localhost/IADProject/jscondition.php">JavaScript  - Conditions</a></li>
            <li><a href="http://localhost/IADProject/jsquize.php">JavaScript  - Quizes</a></li>

             
       </ul></div> 

           <h1 id="hwhatis">JAVASCRIPT</h1><br><br>
           <p id="pwhatis">JavaScript is a programming language that can be included on web pages to make them more interactive.<br>
               You can use it to check or modify the contents of forms, change images, open new windows and write dynamic page content.<br>
               You can even use it with CSS to make DHTML (Dynamic HyperText Markup Language). This allows you to make parts of<br>
               your web pages appear or disappear or move around on the page. JavaScripts only execute on the page(s) <br>
               that are on your browser window at any set time. When the user stops viewing that page, any scripts <br>
               that were running on it are immediately stopped. The only exceptions are cookies or various client side storage APIs, <br>
               which can be used by many pages to store and pass information between them, even after the pages have been closed.</p><br>
<?php

?>
   
</body>
</html>