<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
     <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>   
        
        <h1>perl operator:</h1><br>
        <p>
            <b>What is an Operator?</b> <br> 
            Simple answer can be given using the expression 4 + 5 is <br>equal to 9.
            Here 4 and 5 are called operands and + is called<br> operator. Perl language
            supports many operator types, but <br>following is a list of important and 
            most frequently used operators −<br><br>
        
            1-Arithmetic Operators<br>
            2-Equality Operators<br>
            3-Logical Operators<br>
            4-Assignment Operators<br>
            5-Bitwise Operators<br>
            6- Logical Operators<br>
            7-Quote-like Operators<br>
            8- Miscellaneous Operators<br><br>
            Lets have a look at all the operators one by one.<br><br>
            <b>Regular Expressions:</b><br><br>
            A regular expression is a string of characters that defines the pattern<br>
            or patterns you are viewing. The syntax of regular expressions in Perl<br>
            is very similar to what you will find within other regular expression.<br>
            supporting programs, such as sed, grep, and awk.<br><br>
            The basic method for applying a regular expression is to use the pattern <br>
            binding operators =~ and !~. The first operator is a test and assignment <br>
            operator.<br><br>
            <b>There are three regular expression operators within Perl.</b><br>

            Match Regular Expression - m//<br>

            Substitute Regular Expression - s///<br>

            Transliterate Regular Expression - tr///<br><br>
            


                
            </p>
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
