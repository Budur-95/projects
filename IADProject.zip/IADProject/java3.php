<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
       <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
              <li><a href="java.php">Java - What Is ? </a></li>
<li><a href="java1.php" >Java - basics </a></li>
<li><a href="java2.php">Java - variables </a></li>
<li><a href="java3.php">Java - conditionals</a></li>
<li><a href="java4.php">Java - arrays</a></li>
<li><a href="java5.php">Java -  user input</a></li>
<li><a href="java6.php">Java -  Quiz </a></li>

             
       </ul></div>

    <p>The if-then Statement <br>

The if-then statement is the most basic of all the control flow statements.<br>
It tells your program to execute a certain section of code only if a particular test evaluates to true.<br>
For example, the Bicycle class could allow the brakes to decrease the bicycle's speed only if the bicycle is already in motion.<br>
One possible implementation of the applyBrakes method could be as follows:<br>

void applyBrakes() {<br>
    // the "if" clause: bicycle must be moving<br>
    if (isMoving){ <br>
        // the "then" clause: decrease current speed<br>
        currentSpeed--;<br>
    }<br>
}<br>
If this test evaluates to false (meaning that the bicycle is not in motion), control jumps to the end of the if-then statement.<br>
<br>
In addition, the opening and closing braces are optional, provided that the "then" clause contains only one statement:<br>
<br>
void applyBrakes() {<br>
    // same as above, but without braces <br>
    if (isMoving)<br>
        currentSpeed--;<br>
}<br>
Deciding when to omit the braces is a matter of personal taste. Omitting them can make the code more brittle.<br>
If a second statement is later added to the "then" clause, a common mistake would be forgetting to add the newly required braces.<br>
The compiler cannot catch this sort of error; you'll just get the wrong results.<br>
<br>
The if-then-else Statement<br>
<br>
The if-then-else statement provides a secondary path of execution when an "if" clause evaluates to false.<br>
You could use an if-then-else statement in the applyBrakes method to take some action if the brakes are applied when the bicycle is<br> not in motion. 
In this case, the action is to simply print an error message stating that the bicycle has already stopped.<br>
<br>
void applyBrakes() {<br>
    if (isMoving) {<br>
        currentSpeed--;<br>
    } else {<br>
        System.err.println("The bicycle has already stopped!");<br>
    } <br>
}<br>
The following program, IfElseDemo, assigns a grade based on the value of a test score: an A for a score of 90% or above, a B for a score of 80% or above, and so on.<br>
<br>
<br>
class IfElseDemo {<br>
    public static void main(String[] args) {<br>
<br>
        int testscore = 76;<br>
        char grade;<br>
<br>
        if (testscore >= 90) {<br>
            grade = 'A';<br>
        } else if (testscore >= 80) {<br>
            grade = 'B';<br>
        } else if (testscore >= 70) {<br>
            grade = 'C';<br>
        } else if (testscore >= 60) {<br>
            grade = 'D';<br>
        } else {<br>
            grade = 'F';<br>
        }<br>
        System.out.println("Grade = " + grade);<br>
    }<br>
}<br>
The output from the program is:<br>
<br>
    Grade = C<br>
You may have noticed that the value of testscore can satisfy more than one expression in the compound statement:<br>
76 >= 70 and 76 >= 60. However, once a condition is satisfied,<br>
the appropriate statements are executed (grade = 'C';) and the remaining conditions are not evaluated.<br></p>
    </body>
</html>
