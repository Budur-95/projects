<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br><br>
        <hr class="style5">
         <br><br><br>
         <h1>C# Basic Syntax</h1>
       
           <p>          
        C# is an object-oriented programming language. In Object-Oriented Programming methodology, a program consists of various objects that interact with each other by means of actions.
        The actions that an object may take are called methods. Objects of the same kind are said to have the same type or, are said to be in the same class.

           </p>
           <h4> Let us look at implementation of a Rectangle class and discuss C# basic syntax:</h4>
           
            <p>
        <code>
            using System;<br>
namespace RectangleApplication<br>
{<br>
   class Rectangle <br>
   {<br>
      // member variables<br>
      double length;<br>
      double width;<br>
      public void Acceptdetails()<br>
      {<br>
         length = 4.5; <br>
         width = 3.5;<br>
      }<br>
      
      public double GetArea()<br>
      {<br>
         return length * width; <br>
      }<br>
      
      public void Display()<br>
      
      {<br>
         Console.WriteLine("Length: {0}", length);<br>
         Console.WriteLine("Width: {0}", width);<br>
         Console.WriteLine("Area: {0}", GetArea());<br>
      }<br>
   }<br>
   
   class ExecuteRectangle <br>
   {<br>
      static void Main(string[] args) <br>
      {<br>
         Rectangle r = new Rectangle();<br>
         r.Acceptdetails();<br>
         r.Display();<br>
         Console.ReadLine(); <br>
      }<br>
   }<br>
}
        </code>
            </p>
            <h4>When the above code is compiled and executed, it produces the following result:</h4>
            <p>
                <code>
      Length: 4.5<br>
      Width: 3.5<br>
      Area: 15.75
                    
                </code>
            </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
