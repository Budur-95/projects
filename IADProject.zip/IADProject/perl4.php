<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        
        <h1>perl Array:</h1>
        <p>An array is a variable that stores an ordered list of scalar values.<br>
            Array variables are preceded by an "at" (@) sign. To refer to a single<br>
            element of an array, you will use the dollar sign ($) with the variable<br>
            name followed by the index of the element in square brackets.<br><br>
            Here is a simple example of using the array variables −<br><br>
            #!/usr/bin/perl<br>

            @ages = (25, 30, 40);<br>             
            @names = ("John Paul", "Lisa", "Kumar");<br>

            print "\$ages[0] = $ages[0]\n";<br>
            print "\$ages[1] = $ages[1]\n";<br>
            print "\$ages[2] = $ages[2]\n";<br>
            print "\$names[0] = $names[0]\n";<br>
            print "\$names[1] = $names[1]\n";<br>
            print "\$names[2] = $names[2]\n";<br><br>
            <b>Accessing Array Elements:</b><br><br>
            When accessing individual elements from an array, you must prefix the <br>
            variable with a dollar sign ($) and then append the element index within<br>
            the square brackets after the name of the variable. For example −<br><br>
            #!/usr/bin/perl<br>

            @days = qw/Mon Tue Wed Thu Fri Sat Sun/;<br>

            print "$days[0]\n";<br>
            print "$days[1]\n";<br>
            print "$days[2]\n";<br>
            print "$days[6]\n";<br>
            print "$days[-1]\n";<br>
            print "$days[-7]\n";<br><br>
            This will produce the following result −<br>
            Mon<br>
            Tue<br>
            Wed<br>
            Sun<br>
            Sun<br>
            Mon<br><br>
            <b>Array Size:</b><br>
            The size of an array can be determined using the scalar context on the <br>
            array - the returned value will be the number of elements in the array −<br><br>
            @array = (1,2,3);<br>
            print "Size: ",scalar @array,"\n";<br><br>
            <b>Merging Arrays:</b><br>
            Because an array is just a comma-separated sequence of values, you can <br>
            combine them together as shown below −<br><br>
            !/usr/bin/perl<br>

            @numbers = (1,3,(4,5,6));<br>

            print "numbers = @numbers\n";<br><br>
            This will produce the following result −<br>

            numbers = 1 3 4 5 6<br><br>
            <b>Selecting Elements from Lists:</b><br>
            The list notation is identical to that for arrays. You can extract an element<br>
            from an array by appending square brackets to the list and giving one or<br>
            more indices −<br><br>
            #!/usr/bin/perl<br>

            $var = (5,4,3,2,1)[4];<br>

            print "value of var = $var\n"<br><br>
            This will produce the following result −<br>

            value of var = 1<br><br>
            <b>Similarly, we can extract slices, although without the requirement for a <br>
                leading @ character −</b><br><br>

            #!/usr/bin/perl<br>

            @list = (5,4,3,2,1)[1..3];<br>

            print "Value of list = @list\n";<br><br>
            This will produce the following result −<br>

            Value of list = 4 3 2<br>


            
            
            
            
            
            
        </p>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
