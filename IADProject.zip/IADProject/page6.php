<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
      <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />

    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        <br><br>
        <br><br>
        <ul class="mylist" class="nav nav-list primary left-menu" >
<li>prolog Advanced</li>
<li><a href="page1.php">prolog - What Is ? </a></li>
<li><a href="page2.php">prolog - syntax </a></li>
<li><a href="page3.php">prolog - Arithmetic  </a></li>
<li><a href="page4.php">prolog - lists</a></li>
<li><a href="page5.php">prolog- Comparing integers </a></li>
<li><a href="page6.php">prolog - Recursion</a></li>
<li><a href="page7.php">prolog - Quize </a></li>
</ul>
        
        <h1>prolog Recursion:</h1>
        <p>
            <b class="a">Recursion 1:</b><br><br>
            As is commonly the case in many programming tasks, we often wish to<br>
            repeatedly perform some operation either over a whole data-structure,<br>
            or until a certain point is reached. The way we typically do this in<br>
            Prolog is by recursion. This simply means a program calls itself typically<br>
            until some final point is reached. Frequently in Prolog what this means<br>
            is that we have a first fact that acts as some stopping condition followed<br>
            up by some rule(s) that performs some operation before reinvoking itself.<br><br>
            Recursion is often found to be a hard concept to grasp. For this reason we<br>
            will present two detailed examples of how it works.<br><br>
            <b class="a">Recursion 2:</b><br><br>
            on_route(rome).<br>
            on_route(Place):-<br>
            move(Place,Method,NewPlace),<br>
            on_route(NewPlace).<br>
            move(home,taxi,halifax).<br>
            move(halifax,train,gatwick).<br>
            move(gatwick,plane,rome).<br><br>
            on_route is a recursive predicate. This program sees if it is possible<br>
            to travel to rome from a particular place. The first clause sees if we<br>
            have already reached rome, in which case we stop. The second clause sees<br>
            if there is a move from the current place, to somewhere new, and then <br>
            recursive sees if the NewPlace is on_route to rome. The database of moves<br>
            that we can make is on the right.<br><br>
            <b class="a">Recursion 3:</b><br><br>
            on_route(rome).<br> 
            on_route(Place):-<br>
            move(Place,Method,NewPlace),<br>
            on_route(NewPlace).<br>
            move(home,taxi,halifax).<br>
            move(halifax,train,gatwick).<br>
            move(gatwick,plane,rome).<br><br>
            The goal on_route(halifax) will fail to unify on clause one, so again<br>
            we'll use the recursive clause two and find some new place to go to.<br>
            Hence we try the goal move(halifax,Method,NewPlace) this succeeds because<br>
            we can catch a train from halifax to gatwick airport. Hence Method=train,<br>
            NewPlace=gatwick. As a result we then try the recursive call on_route(gatwick),<br>
            i.e. we see if there is a move from gatwick which will get us to rome.<br><br>
            <b class="a">Recursion 4:</b><br><br>
            parent(john,paul).             /* paul is john's parent */ <br> 
     
            parent(paul,tom).              /* tom is paul's parent */<br>

            parent(tom,mary).              /* mary is tom's parent */ <br>      
    
            ancestor(X,Y):- parent(X,Y).   /* someone is your ancestor if there are <br>
            your parent */<br><br>
            The first clause of ancestor looks to see if there exists a clause that<br>
            could match the goal parent(john,tom). This fails to match, as a result<br>
            we try the second clause of ancestor. We now pose the query parent(john,Z).<br>
            This results in us choosing clause one of parent and binding Z=paul. As a <br>
            result, we now pose the recursive query ancestor(paul,tom). Applying the <br>
            ancestor rule again, we first try the first clause. This means we check<br>
            for parent(paul,tom). which successfully matches the second clause of <br>
            parent. As a result the goal ancestor(paul,tom) succeeds. This in turn<br>
            leads to the goal ancestor(john,tom) succeeding and Prolog responding yes


        </p>
        
        <?php
        // put your code here
        ?>
    </body>
</html>
