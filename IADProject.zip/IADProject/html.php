<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="html.php">HTML - What Is ? </a></li>
            <li><a href="html1.php" >HTML - basics</a></li>
            <li><a href="html2.php">HTML - variables</a></li>
            <li><a href="html3.php">HTML - conditions</a></li>
            <li><a href="html4.php">HTML - Style Sheet</a></li>
            <li><a href="html6.php">HTML -  Quiz</a></li>

             
       </ul></div> 
    
    
        <h1>What is HTML?</h1>
        <p>
            HTML is the standard markup language for creating Web pages.<br>
            <br>
            HTML stands for Hyper Text Markup Language<br>
            HTML describes the structure of Web pages using markup<br>
            HTML elements are the building blocks of HTML pages<br>
            HTML elements are represented by tags<br>
            HTML tags label pieces of content such as "heading", "paragraph", "table", and so on<br>
            Browsers do not display the HTML tags, but use them to render the content of the page <br>
            <br>
            <br>
            <b>Example Explained</b> <br>
            The <!DOCTYPE html> declaration defines this document to be HTML5<br>
            The < html > element is the root element of an HTML page<br>
                The < head > element contains meta information about the document<br>
                The < title > element specifies a title for the document<br>
                    The < body > element contains the visible page content<br>
                        The < h1 > element defines a large heading<br>
                            The < p > element defines a paragraph<br>
                            <br>
                            <b>HTML Tags</b><br>
                            HTML tags are element names surrounded by angle brackets:<br>
                            <br>
                            
                            < tagname >content goes here...< /tagname ><br>
                            HTML tags normally come in pairs like < p > and < /p ><br>
                            The first tag in a pair is the start tag, the second tag is the end tag<br>
                            The end tag is written like the start tag, but with a forward slash inserted before the tag name<br>
                            <br>
                            <br>
            <b>HTML Page Structure</b>
            <p>Below is a visualization of an HTML page structure:</p><br>
<div id="bor">&lt;html&gt;
<div id="bor">&lt;head&gt;
<div id="bor">&lt;title&gt;Page title&lt;/title&gt;
</div>
&lt;/head&gt;
</div>
<div id="bor">&lt;body&gt;
<div id="bor">
<div id="bor">&lt;h1&gt;This is a heading&lt;/h1&gt;</div>
<div id="bor">&lt;p&gt;This is a paragraph.&lt;/p&gt;</div>
<div id="bor">&lt;p&gt;This is another paragraph.&lt;/p&gt;</div>
</div>
&lt;/body&gt;
</div>
&lt;/html&gt;
</div>
          
</body>
</html>
        
        </p>
    </body>
</html>
