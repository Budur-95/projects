<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
 <html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div>
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
            <br><br>
            <hr class="style5">
         <br><br><br>
    </div>
        
        <h1 id="hwhatis">Java Script-Syntax?</h1><br><br>
        
        <p id="pwhatis" > JavaScript can be implemented using JavaScript statements that are placed within the <b> < script>... </ script></b> <br>
            HTML tags in a web page can place the <b>< script> </b>tags, containing your JavaScript, anywhere within your web page, but it is normally recommended that you should keep it within the <b>< head></b> tags.<br>

The<b> < script></b> tag alerts the browser program to start interpreting all the text between these tags as a script. A simple syntax of your JavaScript will appear as follows.
        </p>
   
        <?php
        // put your code here
        ?>
    </body>
</html>
