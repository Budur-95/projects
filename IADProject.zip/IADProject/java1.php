<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
  
           <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
               <li><a href="java.php">Java - What Is ? </a></li>
<li><a href="java1.php" >Java - basics </a></li>
<li><a href="java2.php">Java - variables </a></li>
<li><a href="java3.php">Java - conditionals</a></li>
<li><a href="java4.php">Java - arrays</a></li>
<li><a href="java5.php">Java -  user input</a></li>
<li><a href="java6.php">Java -  Quiz </a></li>

             
       </ul></div> 
    <p>
        Every Java program (no matter how simple or complex) contains a fundamental structure. The simplest thing you can do in a Java program is print some text.
        <b>Java program core code </b> <br>

        Fundamental structure of a Java program consists of these elements:<br>

        <b>A class declaration </b>- A class is a grouping of related variables and functions (methods) that is used to achieve something. <br>We explain variables and methods shortly, don't worry if right now you don't know what they are. All the source code for a Java program will be placed within the class definition. The class is given a name and the code within it is sorrounded by curly brackets.<br>

Example:
class PrintText{
}
A main() method - A method is a grouping of code that executes when it is called. One method used in every Java program is the main() method, it's what makes a Java program work. The main() method has to be set with a few special keywords and a certain parameter like in the example below.

Example:
class PrintText{
  public static void main(String[] args){
       
   }
}
The above example is a 'bare bones' Java program. It doesn't do anything, only contains the fundamental Java program structure.
    </p>
    </body>
</html>
