<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/style.css" rel="stylesheet">
        <link href="css/default.css" rel="stylesheet" type="text/css" media="all" />
    </head>
    <body class="about">


        <div id="header" class="container">
            <br/>
            <div id="menu">
                <ul>




                    <li class="active"><a href="mailto:beedoo1415@hotmail.com"> Contact</a></li>

                    <li class="active"><a href="createNew.php"> Sign Up</a></li>
                    <li class="active"><a href="signIn.php">Sign in</a></li>
                    <li class="active"><a href="index.php">home page</a></li>
                </ul>
            </div></div>
        <div class="info">
            <dl>
                <dt>:Learn From Zero </dt>
                <dd> 
                    <b>Learn From Zero</b> is about programming languages that the people can<br />
                    learn and understand easy by many of ways for learn any language want <br />


                    <br	/>
                </dd>


                <dt>:Services</dt>
                <dd> 
                    .our website offers some Features like<br/>

                     person can be add any resourses-<br/>
                    The website offers quizzes for languages- <br/>
                    The website offers Refrences free of books- <br/></dd>
                <dt></dt>
                <dd></dd>
            </dl>
        </div>
        <?php
        ?>

    </body>
</html>
