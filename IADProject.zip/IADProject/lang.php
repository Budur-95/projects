<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <script src="jc/jc7.js"></script>
        
        
        
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div>
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
         <hr class="style5">
         <br><br><br>
        
        <br>
        <br>
        <br>
         <br>
        <br>
        <br>
        
        <div class="tra">
        <h1><b>Choose the language you want to learn :</b> </h1>
        
        <br>
        <table align="center" width="55%" height="50%"  > 
<tr> 
    <td align="center">  <a href="javascript.php"><img src="images/js0.png"  width="130%" onclick="myFunction3()" > </a></td>
    <td align="center">  <a href="java.php"> <img  src="images/java0.png" width="100%" onclick="myFunction2()" > </a></td> 
  
      <td align="center"><a href="php.php"><img src="images/php.png" width="40%" onclick="myFunction1()"></a></td>
            <td align="center">  <a href="perl1.php"><img src="images/perl0.png" width="80%" onclick="myFunction4()"> </a></td> 
</tr> 
<tr> 
    <td align="center"><a href="html.php"> <img src="images/html0.png" width="40%" onclick="myFunction5()"></a></td>
    <td align="center"><a href="c++page.php"><img src="images/c++0.png" width="100%" onclick="myFunction6()"></a></td>
    <td align="center"><a href="csharppage.php"><img src="images/c##.png" width="100%" onclick="myFunction7()"></a></td>
    <td align="center"><a href="page1.php"><img src="images/prolog0.png" width="100%" onclick="myFunction8()"></a></td>
    
</tr> 
</table>
        </div>

    </body>
</html>
