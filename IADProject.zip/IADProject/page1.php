<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
   
           <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
              <li><a href="java.php">Java - What Is ? </a></li>
<li><a href="java1.php" >Java - basics </a></li>
<li><a href="java2.php">Java - variables </a></li>
<li><a href="java3.php">Java - conditionals</a></li>
<li><a href="java4.php">Java - arrays</a></li>
<li><a href="java5.php">Java -  user input</a></li>
<li><a href="java6.php">Java -  Quiz </a></li>

             
       </ul></div> 


        
        <h1>What is prolog ?</h1><br>
        <p>
            Prolog is a programming language particularly well suited to logic and artificial intelligence programming.<br>
            "Prolog" in fact stands for "Programming in Logic." In this brief introduction we will try to give you a little<br>
            taste of Prolog without bogging you down with a great deal of technical jargon. By the end of this section you <br>
            should be able to use Prolog and write some little programs that give you a feel for the language. Feel free to <br>
            consult the books and Web sites on Prolog mentioned later should you want to go further.
        </p>
    
    
    
    
    
        <?php
        // put your code here
        ?>
    </body>
</html>
