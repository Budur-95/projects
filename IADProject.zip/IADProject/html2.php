<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="html.php">HTML - What Is ? </a></li>
            <li><a href="html1.php" >HTML - basics</a></li>
            <li><a href="html2.php">HTML - variables</a></li>
            <li><a href="html3.php">HTML - conditions</a></li>
            <li><a href="html4.php">HTML - Style Sheet</a></li>
            <li><a href="html6.php">HTML -  Quiz</a></li>

             
       </ul></div> 
    
        <h1>Variables</h1>


        <p>a variable has a name and a value.<br>
            They are the way we store data, and you’ll be using them a lot.<br>
            There are two parts to creating a variable; declaration and initialization.<br>
            Once it’s created, you can assign (or set) its value.<br>
            <br>
            <b>Declaration</b>
            Declaration is declaring a variable to exist.<br>
            To return to the shelf metaphor, it’s like picking an empty shelf in a massive warehouse and putting a name on it.<br>
            As above, to declare a variable, use the var keyword followed by the variable name, like this:<br></p>
        <div id="example">
            var surname;<br>
            var age;<br>
            Notice those semicolons (“;”)? Almost every line in JavaScript ends in a semicolon - you’ll be using them a lot.<br>
        </div>
        <p>
            <b>Initialization</b>
            Initialization is giving a variable its value for the first time. The value can change later, but it is only initialized once.<br>
            You initialize a variable using the equals sign (=).<br>
            You can read it as “the value of the variable on the left should be the data on the right”:<br>
            var name = "Tom";<br>
            “Tom” is a string - a collection of letters. A string is surrounded by single or double quote marks.<br></p>
        <br> <div id="example">
            var age = 20;<br>
            20 is just a number - and numbers don’t go in quotes.<br>
        </div>
        <p><b>Assignment</b>

            As mentioned, you can set a variable’s value as many times as you like.<br>
            It’s called assignment and it looks very similar to initialization.<br>
            You again use the equals sign, but there’s no need for the var keyword because we’ve already declared the variable.<br>
            <br>
            It’s like this:</p>
        <div id="example">
            name = "Andy";<br>
            age = 43;<br>
            Only do this if you’ve declared the variable using the var keyword!</div>
    </body>
</html>
