<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> 
        <title></title>     <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
       
    <p>Java provides a data structure, the array, which stores a fixed-size sequential collection of elements of the same type.<br>
        An array is used to store a collection of data, but it is often more useful to think of an array as a collection of variables of the same type.<br>
        <br>
        Instead of declaring individual variables, such as number0, number1, ..., and number99, you declare one array variable such as numbers and use numbers[0], numbers[1], and ..., numbers[99] to represent individual variables.<br>
        <br>
        Declaring Array Variables<br>
    To use an array in a program, you must declare a variable to reference the array, and you must specify the type of array the variable can reference.
    <br> Here is the syntax for declaring an array variable −<br>
    dataType[] arrayRefVar;   // preferred way.<br>
or
dataType arrayRefVar[];  // works but not preferred way.<br>
    </p>
    </body>
</html>
