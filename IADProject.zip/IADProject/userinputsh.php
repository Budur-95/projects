<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    
    <body>
       <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
  
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
       <br><br>
<hr class="style5">
         <br><br><br>

        
        <h1>user input in C#</h1>
       
           <p>            
   I have been into C++ for a few months and got up to learning functions, pointers, references, and a little OOP. 
   I wanted to experiment with C#, for many personal reasons. It seems to attract me more..<br>

   With C++ all you have to do is..<br>

   cout << "Enter a num";<br>
cin >> num;
                     <p/>
      <h4> The example below shows user input in c#</h4>                 
        
          <p>
        <code>
            Code Snippet<br>
static void Main(string[] args)<br>

{<br>

 

Console.WriteLine("Please enter a number.");<br>

 

 //ReadLine example<br>

 

string input = Console.ReadLine();<br>

double inputAsNumber;<br>

if (double.TryParse(input, out inputAsNumber) == true)<br>

{<br>

Console.WriteLine("You entered a valid number: {0}", inputAsNumber);<br>

}<br>

else<br>

{<br>

Console.WriteLine("You entered an invalid number");<br>

}<br>

Console.ReadLine();<br>

 

 //ReadKey example<br>

 

Console.WriteLine("Please enter a number.");<br>

ConsoleKeyInfo key = Console.ReadKey();<br>

if (double.TryParse(key.KeyChar.ToString(), out inputAsNumber) == true)<br>

{<br>

Console.WriteLine("You entered a valid number: {0}", inputAsNumber);<br>

}<br>

else<br>

{<br>

Console.WriteLine("You entered an invalid number");<br>

}<br>

Console.ReadLine();<br>

}

         </code>
          </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
