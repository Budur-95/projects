<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <link rel="stylesheet" type="text/css" href="css/stylle.css">
         <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <title></title>
    </head>
    <body >
        <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
<hr class="style5">
         <br><br><br>
        <h1 id="hwhatis">PHP-What Is?</h1><br><br>
        <p id="pwhatis">
            PHP started out as a small open source project that evolved as more and more people
            found out how useful it was.<br> Rasmus Lerdorf unleashed the first version of PHP way 
            back in 1994.<br>

PHP is a recursive acronym for "PHP: Hypertext Preprocessor".<br>

PHP is a server side scripting language that is embedded in HTML.<br>
It is used to manage dynamic content, databases, session tracking, even build entire e-commerce sites.<br>

It is integrated with a number of popular databases, including MySQL, PostgreSQL, Oracle, Sybase, Informix, and Microsoft SQL Server.<br>

PHP is pleasingly zippy in its execution, especially when compiled as an Apache module on the Unix side.<br>
The MySQL server, once started, executes even very complex queries with huge result sets in 
record-setting time.<br>

PHP supports a large number of major protocols such as POP3, IMAP, and LDAP. <br>
PHP4 added support for Java and distributed object architectures (COM and CORBA),
making n-tier development a possibility for the first time.<br>

PHP is forgiving: PHP language tries to be as forgiving as possible.<br>

PHP Syntax is C-Like.<br>
        </p>
        <?php
      
        ?>
    </body>
</html>
