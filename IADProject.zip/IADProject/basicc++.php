<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>c++ basic</title>
        <link rel="stylesheet"  type="text/css" href="css/stylesheetbasic.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br><br>
        <hr class="style5">
         <br><br><br>
        <h1>C++ Programming Language Basics</h1>
      
           
                   <h4>C++ Standards</h4>
                   <ol>
 C++ is standardized as ISO/IEC 14882. Currently, there are two versions:
 <li>C++98 (ISO/IEC 14882:1998): 1st standard version of C++.</li>
 <li>C++03 (ISO/IEC 14882:2003): minor "bug-fix" to C++98 with no change to the language. Commonly refer to as C++98/C++03 or First C++ standard.</li>
<li>C++11 (ISO/IEC 14882:2011): 2nd standard version of C++. Formerly called C++0x, as it was expected to finalize in 200x. It adds some new features to the language; more significantly, it greatly extends the C++ standard library and standard template library (STL).</li>
</ol>
<h4>C++ Features</h4>
<ol>
    <li>C++ is C. C++ supports (almost) all the features of C. Like C, C++ allows programmers to manage the memory directly, so as to develop efficient programs.</li>
<li>C++ is OO. C++ enhances the procedural-oriented C language with the object-oriented extension. The OO extension facilitates design, reuse and maintenance for complex software.</li>
<li>Template C++. C++ introduces generic programming, via the so-called template. You can apply the same algorithm to different data types.</li>
<li>STL. C++ provides a huge set of reusable standard libraries, in particular, the Standard Template Library (STL).</li>
</ol>
<h4>C++ Strength and Pitfall</h4>
<p><strong>C++ is a powerful language for high-performance applications, including writing operating systems and their subsystems, games and animation. C++ is also a complex and difficult programming language, which is really not meant for dummies.
For example, to effectively use the C++ Standard Template Library (STL), you need to understand these difficult concepts: pointers, references, operator overloading and template, on top of the object-oriented programming concepts such as classes and objects, inheritance and polymorphism; and the traditional constructs such as decision and loop. C++ is performance centric.
The C++ compiler does not issue warning/error message for many obvious programming mistakes, undefined and unspecified behaviors, such as array index out of range, using an uninitialized variable, etc, due to the focus on performance and efficiency rather than the ease of use - it assumes that those who choose to program in C++ are not dummies.
               </strong>
           </p>
           <h2> Basic Syntaxes </h2>
           <code>
               /*
               * Sum the odd and even numbers, respectively, from 1 to a given upperbound.<br>
               * Also compute the absolute difference.<br>
               * (SumOddEven.cpp)<br>
 */
 <br>
 #include <iostream>   // Needed to use IO functions<br>
using namespace std;
<br>
int main() {<br>
int sumOdd  = 0; // For accumulating odd numbers, init to 0<br>
int sumEven = 0; // For accumulating even numbers, init to 0<br>
int upperbound;  // Sum from 1 to this upperbound<br>
   int absDiff;     // The absolute difference between the two sums
   <br>
   // Prompt user for an upperbound<br>
   cout << "Enter the upperbound: ";<br>
   cin >> upperbound;
   <br>
   // Use a while-loop to repeatedly add 1, 2, 3,..., to the upperbound<br>
   int number = 1;<br>
   while (number <= upperbound) {<br>
      if (number % 2 == 0) {  // Even number<br>
         sumEven += number;   // Add number into sumEven<br>
      } else {                // Odd number<br>
         sumOdd += number;    // Add number into sumOdd<br>
      }<br>
      ++number; // increment number by 1<br>
   }
   <br>
   // Compute the absolute difference between the two sums<br>
   if (sumOdd > sumEven) {<br>
      absDiff = sumOdd - sumEven;<br>
   } else {<br>
      absDiff = sumEven - sumOdd;<br>
   }
   <br>
   // Print the results<br>
   cout << "The sum of odd numbers is " << sumOdd << endl;<br>
   cout << "The sum of even numbers is " << sumEven << endl;<br>
   cout << "The absolute difference is " << absDiff << endl;<br>
 
   return 0;<br>
}
<br>
Enter the upperbound: 1000<br>
The sum of odd numbers is 250000<br>
The sum of even numbers is 250500<br>
The absolute difference is 500
</code>
        <?php
        // put your code here
        ?>
    </body>
</html>
