<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        
    </head>
    <body>
     <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>   
        <form name="Temps11"><br>
          <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
  
   </center>
                 
    </div>
        </form>
        <br><br>
        <hr class="style5">
         <br><br><br>
        <h1>Conditional Execution in C++</h1>
       
           <p><strong>
           The if Statement</strong> <br>           
           Quite often we need to control the flow of execution of a program; in particular, to decide if a certain instruction or block of instructions should be executed, depending on a given condition.
           For example, in a more advanced version of our invoice program, we may want to take into account the fact that some products are taxable and some are not.
           The program could ask the user whether the product is taxable or not, and depending on what the user indicates, calculate things accordingly.
         The most fundamental statement related to these types of situations is the if statement. 
                                <p/>
      <h4>The syntax for the if statement is as follows:</h4>                 
      <p>
        <code>
             if (condition)<br>
    {<br>
        statement(s);<br>
       }
         </code>
          </p>
          <h4>A simple concrete example is shown below:</h4>
          <p>
        <code>
       if (number < 0)<br>
    {<br>
        cout << "Error! You must enter a positive number!" << endl;
}<br>
       }
         </code>
          </p>
            <h4>The examples below illustrate the use of conditions in an if statement:</h4>
            <p>
        <code>
          if (price <= 0) <br>
    {<br>
          // Error condition
  <br>
  }<br>
  if (price > average_price)<br>
{<br>
    // Apply some discount<br>
}<br>

if (age < 18)<br>
{<br>
    // Error message -- not allowed to buy alcohol<br>
}<br>

if (age >= 65)<br>
{<br>
    // Apply seniors' discount<br>
}
         </code>
          </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
