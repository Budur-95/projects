<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
       <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
              <li>prolog Advanced</li>
<li><a href="page1.php">perl - What Is ? </a></li>
<li><a href="page2.php">perl - syntax </a></li>
<li><a href="page3.php">perl-  data types  </a></li>
<li><a href="page4.php">perl - perl</a></li>
<li><a href="page5.php">perl-  IF ELSE  </a></li>
<li><a href="page6.php">perl - loop</a></li>
<li><a href="page7.php">perl - operator </a></li>
<li><a href="page8.php">perl - Quize</a></li>

             
       </ul></div> 

        <br>
        <h1>What is perl ?</h1>
        <p>
            Perl is a general-purpose programming language originally developed for text manipulation and now used<br>
            for a wide range of tasks including system administration, web development, network programming, GUI development,<br>
            and more.<br><br>
            1-Perl is a stable, cross platform programming language.<br>

           2- Though Perl is not officially an acronym but few people used it as Practical Extraction and Report Language.<br>
           3-it is used for mission critical projects in the public and private sectors.
           4-Perl is an Open Source software, licensed under <br>its Artistic License, or the GNU General Public License (GPL).<br>
           5-Perl was created by Larry Wall.<br>
           6-Perl 1.0 was released to usenet's alt.comp.sources in 1987<br>
           7-At the time of writing this tutorial, the latest version of perl is 5.16.2<br>
           8-Perl is listed in the Oxford English Dictionary.
        </p>
    
        <?php
        // put your code here
        ?>
    </body>
</html>
