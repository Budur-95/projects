<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
     
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
         <hr class="style5">
         <br><br><br>
        <h1 id="hwhatis">JavaScript-Variables</h1><br>
        <p id="pwhatis">
            
        Like many other programming languages, JavaScript has variables. 
        Variables can be thought of as named containers. You can place data into these containers
        and then refer to the data simply by naming the container.

Before you use a variable in a JavaScript program, you must declare it. 
Variables are declared with the <b>var</b> keyword as follows. <br>
        <p id="border"><b>< script type="text/javascript"><br>
  
    var money;<br>
    var name;<br>
   
    < /script></b></p>
            
            
            
        </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
