<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title> <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        
        <h1>perl syntax:</h1><br> 
        <p><b> Interactive Mode Programming: </b><br>
            You can use Perl interpreter with -e option at command line, which lets you execute<br>
            Perl statements
            from the command line. Let's try something at $ prompt as follows −<br><br></p>
           <p class="one">
            $perl -e 'print "Hello World\n"<br>
            This execution will produce the following result −<br>
            Hello, world.<br><br></p>
           <p>
            <b> Script Mode Programming :  </b><br>
            Assuming you are already on $ prompt, let's open a text file hello.pl using vi or vim editor<br>
            and put the following lines inside your file.<br><br>
            #!/usr/bin/perl<br>

            # This will print "Hello, World"<br>
            print "Hello, world\n";<br><br>
            Here /usr/bin/perl is the actual perl interpreter binary. Before you execute your script,<br>
            be sure to change the mode of the script file and give execution priviledge, generally a<br>
            setting of 0755 works perfectly and finally you execute the above script as follows −<br><br>
            $chmod 0755 hello.pl<br>
            $./hello.pl<br>
            This execution will produce the following result −<br>
            Hello, world<br><br>
            You can use parentheses for functions arguments or omit them according to your personal taste.<br>
            They are only required occasionally to clarify the issues of precedence. Following two statements<br>
            produce the same result.<br><br>
            print("Hello, world\n");<br>
            print "Hello, world\n";<br>
            This will produce the following result −<br>
            Hello, world<br>
            Hello, world<br><br>
            <b>Comments in Perl:</b><br>
            Comments in any programming language are friends of developers. Comments can be used to make<br> program 
             user friendly and they are simply skipped by the interpreter without impacting the code <br>functionality.
             For example, in the above program, a line starting with hash #is a comment.<br><br>

             Simply saying comments in Perl start with a hash symbol and run to the end of the line −   <br>    
             # This is a comment in perl<br><br>
             <b>Whitespaces in Perl:</b><br>
             A Perl program does not care about whitespaces. Following program works perfectly fine −<br><br>

             #!/usr/bin/perl<br>
             print       "Hello, world\n";<br>
             This will produce the following result −<br>
             Hello, world<br><br>
             But if spaces are inside the quoted strings, then they would be printed as is. For example −<br><br>
             #!/usr/bin/perl<br>
             # This would print with a line break in the middle<br>
             print "Hello<br>
             world\n";<br><br>
             This will produce the following result −<br>

             Hello<br>
             world<br><br>
             <b>Single and Double Quotes in Perl:</b><br>
             You can use double quotes or single quotes around literal strings as follows −<br><br>

             #!/usr/bin/perl<br>

             print "Hello, world\n";<br>
             print 'Hello, world\n';<br><br>
             This will produce the following result −<br><br>

             Hello, world<br>
             Hello, world\n<br>
             <br>
             <b>Perl Identifiers:</b><br>
             A Perl identifier is a name used to identify a variable, function, class, module,<br>
             or other object. A Perl variable name starts with either $, @ or % followed by zero or<br>
             more letters, underscores, and digits (0 to 9).allow punctuation characters such as @, $, <br>
             and % within identifiers. Perl is a <b>case sensitive </b>programming language. Thus<b> $Manpower </b>and <br>
                     <b> $manpower</b> are two different identifiers in Perl.


        
           </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
