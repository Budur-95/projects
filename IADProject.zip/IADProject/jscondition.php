<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body>
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div>
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
         <br><br>
         <hr class="style5">
         <br><br><br>
         
         
        <h1 id="hwhatis">JavaScript-Conditions</h1>
        <p id="pwhatis">
            While writing a program, there may be a situation when you need to adopt one out of a given 
            set of paths. In such cases, you need to use conditional statements that allow your program 
            to make correct decisions and perform right actions.<br><br>

JavaScript supports conditional statements which are used to perform different actions based on different
conditions. <br>

<b>Here we will explain the if.. statement.</b><br>
<img src="images/ifelse.jpg" width="220" height="280">
        <p id="pwhatis">
            <b>1- If statement </b><br>
The if statement is the fundamental control statement that allows JavaScript to make decisions and execute 
statements conditionally.

<b>Syntax</b>
The syntax for a basic if statement is as follows −<br>
        <p id="border">
            
            if (expression){<br>
            Statement(s) to be executed if expression is true<br>
            }</p>
        <br><p id="pwhatis">
    Here a JavaScript expression is evaluated. If the resulting value is true, 
    the given statement(s) are executed. If the expression is false, then no statement 
    would be not executed. Most of the times, you will use comparison operators while making decisions.<br><br>
    <img src="images/if-else.jpg" width="220" height="280"><br>
    <b>2- If...else statement </b><br>
     
    The 'if...else' statement is the next form of control statement that allows JavaScript to execute
    statements in a more controlled way.<br>
    Syntax<br>

        <p id="border">if (expression){<br>
   Statement(s) to be executed if expression is true<br>
}<br><br>

else{<br>
   Statement(s) to be executed if expression is false<br>
   
}<br>
        </p>
        <p id="pwhatis">Here JavaScript expression is evaluated. If the resulting value is true,
            the given statement(s) in the ‘if’ block, are executed. If the expression is false,
            then the given statement(s) in the else block are executed.</p><br>
            
        <p id ="pwhatis">
            <b>3- Switch Case</b><br>
            you can use a switch statement which handles exactly this situation, and it does so more efficiently than repeated if...else if statements.<br>
            <b> Flow Chart:</b><br>
            The following flow chart explains a switch-case statement works<br>
            
            <img src="images/switch_case.jpg." width="220" height="280"><br>
            
            The objective of a switch statement is to give an expression to evaluate and several
            different statements to execute based on the value of the expression. The interpreter 
            checks each case against the value of the expression until a match is found. If nothing
            matches, a default condition will be used.<br>
        <p id="border">
            
            switch (expression)<br>
{<br>
   case condition 1: statement(s)<br>
   break;<br>
   
   case condition 2: statement(s)<br>
   break;<br>
   ...<br>
   
   case condition n: statement(s)<br>
   break;<br>
   
   default: statement(s)<br>
   }</p>
<b>Example</b><br>
Try the following example to implement switch-case statement.<br>
<p id="border">
    
   
    <!--
      <script type="text/javascript">-->
         
    var grade='A'; <br>
            document.write("Entering switch block<br />");<br>
            switch (grade)<br>
            {<br>
              case 'A': document.write("Good job<br />");<br>
               break;<br>
            
               case 'B': document.write("Pretty good<br />");<br>
               break;<br>
            
               case 'C': document.write("Passed<br />");<br>
               break;<br>
            
               case 'D': document.write("Not so good<br />");<br>
               break;<br>
            
               case 'F': document.write("Failed<br />");<br>
               break;<br>
            
               default:  document.write("Unknown grade<br />")<br>
            }<br>
            document.write("Exiting switch block");<br>
           
         //-->
</p>
      
      
      <b >Output</b><br></p>
      <p id="border">
          Entering switch block<br>
Good job<br>
Exiting switch block<br>

Set the variable to different value and then try...
</p>
        </p>

</p>
            
       
        
        <?php
        // put your code here
        ?>
    </body>
</html>
