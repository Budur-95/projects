<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
     <meta charset="utf-8"> 
     
    
    <title>Create new account </title>
    
  
    <link href="css/style.css" rel="stylesheet">
     <script src="jc/jc.js"  type="text/javascript" >  </script>
</head> 
</head>

<body class="sign">
    <div align="left">
    <img src="images/learn.png" alt="logo" width="20%" height="40%"  >
    
</div>
<div id="header" class="container">
    <br/>
	<div id="menu">
		<ul>
	     <li class="active"><a href="mailto:beedoo1415@hotmail.com"> Contact</a></li>

                    <li class="active"><a href="AboutUs.php"> AboutUs</a></li>
                    <li class="active"><a href="signIn.php">Sign in</a></li>
                    <li class="active"><a href="index.php">home page</a></li>
		</ul>
	</div>
</div>

<div id="page" class="container">
	
      <!--<img src="images/books-search.jpg" alt="...">-->

    <div class="search"> <!-- الخلفية-->
        <div class ="_form"> 
        
        
			<h1 style="text-align:center">Add New Materials </h1>
                <p id="hwhatis"> Conditions for acceptance of courses: </p>
                <p id="pwhatis">
                    1- The course must not be on the course site<br>
                    2- The courses we receive are in Arabic and English only<br>
                    3-The course must be free<br>
                    4- The course must be completed<br>
                    5- The image and sound quality of the video must be good<br>
                    6-The courses we receive are a YouTube playlist<br></p>
        <form action="" method="POST" name ="myForm">
           
            <div align = "center">
                <table>
                    <tr>
               <td><input type="text" name="Name of course" placeholder="Name of course"  required > </td> <td> Name of course </td>
                        </tr><tr>
                    <td><input type="text" name="Language of course" placeholder="Language of course"  required> </td> <td>Language of course </td></tr>
            <tr> <td><input type="text" name="Email" placeholder="Email"    required> </td> <td> Email      </td></tr>
           
                    <tr> <td><input type="text" name="Playlist link " placeholder="Playlist link "     required> </td><td> Playlist link      </td></tr>
                    
                </table>
                <input type="submit" onClick="validatenewuser()"onclick="ToPageLanguage()"  value="submit">
                <br /><br /><br />
            
            
           <!--**************************************************************************************************-->
      
      <!-- Start Write into DB-->
      <div class="php" align = "center" >
      <?php
    $servername = "localhost";
$dbname = "database";

// Create connection
$conn = new mysqli($servername, 'root', '1416', $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['Email']) && isset($_POST['Age'])&&isset($_POST['department']) ){
$user = $_POST['username']; 
$pass = $_POST['password'];
$em = $_POST["Email"];
$age= $_POST['Age'];
    $dep =$_POST['department'];
$sql = "INSERT INTO users (username, password, email , age , department) VALUES ('$user','$pass','$em','$age','$dep')";

if ($conn->query($sql) === TRUE) {
    echo "welcome '$user' ";
}} else {
    
}

$conn->close();
?>
         
      </div>
     <!-- End Write into DB--> 
            </div>
            
        </form>


    

    
    
    </body>
</html>