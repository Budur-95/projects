<html>
    <head>
        <meta charset="UTF-8">
        <title>  C++ course</title>
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <script src="jc/js1.js">
        </script>
 
    </head>
   
   
    <body onLoad="debuteTemps1()" onUnload="clearTimeout(ddt1)"> 
 <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
   
 
        <form name="Temps11" >
            <input type="text" name="heure" size="6"onmouseover="mOver(this)" onmouseout="mOut(this)"><br>
      <div >
   <center>
       <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="https://outlook.live.com/owa/?authRedirect=true" >CONTACT</a>
   </center>
                 
    </div>
           
          <hr class="style5">
         <br><br><br>
  
      </form>
    
       <ul id="e">
           <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="c++page.php">C++ - What Is?</a></li>
            <li><a href="basicc++.php">C++ - basics</a></li>
            <li><a href="variablesc++.php">C++ - Variables</a></li>
            <li><a href="conditionalsc++.php">C++ - conditionals</a></li>
            <li><a href="Arrayc++.php">C++ - Arrays</a></li>
            <li><a href="userinputc++.php">C++ - user input</a></li>
            <li><a href="c++quize.php">C++ - Quize</a></li>
             
       </ul></div> 
           <br>
           <h1>What is C++ ?</h1>
      
           <p><strong>
           C++ is a general-purpose object-oriented programming (OOP) language, developed by Bjarne Stroustrup, and is an extension of the C language. It is therefore possible to code C++ in a "C style" or "object-oriented style." In certain scenarios, it can be coded in either way and is thus an effective example of a hybrid language.

           C++ is considered to be an intermediate-level language, as it encapsulates both high- and low-level language features. Initially, the language was called "C with classes" as it had all the properties of the C language with an additional concept of "classes." However, it was renamed C++ in 1983.
           C++ is one of the most popular languages primarily utilized with system/application software, drivers, client-server applications and embedded firmware.
               </strong>
<br />
      <big>Note:  Due to their power and ease of use, C and C++ were used in the programming of the special effects for Star Wars.</big> </p>

       
   <?php
      ?>
      
  

      
       </body>
       </html>
    
