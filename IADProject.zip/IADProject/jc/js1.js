function quiz() {
    alert("To avoid loss of time We have provided you with online sites");
}
function mOver(obj) {
    obj.style.background = "lightblue"
}


function mOut(obj) {
  obj.style.background = "#E0E0E0"
}

var ddt1, delay;
function debuteTemps1() {
  var hhmmss = "  ", mymin, sec;
  delay = 1000;

  adate = new Date();
  hhmmss += adate.getHours();
  mymin = adate.getMinutes();
  if (mymin < 10) hhmmss += ":0" + mymin;
  else hhmmss += ":" + mymin;
  sec = adate.getSeconds();
  if (sec < 10) hhmmss += ":0" + sec;
  else hhmmss += ":" + sec;
  hhmmss = " " + hhmmss;
  document.Temps11.heure.value = hhmmss;

  ddt1 = setTimeout("debuteTemps1(delay)",delay);
}





