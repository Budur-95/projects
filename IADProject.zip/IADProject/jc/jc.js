

function ToPageLanguage() {
    window.location('languages.php');
}

function validateForm() {
    var user = document.forms["Forms"]["username"].value;
    if (user === "") {
        alert("username must be filled out");
        return false;
    }
var pass = document.forms["Forms"]["password"].value;
    if (pass=== "") {
  alert("password must be filled out");
        return false;
}
}

function validatenewuser() {
    var x = document.forms["myForm"]["username"].value;
    if (x == "") {
        alert("username must be filled out");
        return false;
    }
var pass = document.forms["myForm"]["password"].value;
    if (pass == "") {
  alert("password must be filled out");
        return false;
}
var em= document.forms["myForm"]["Email"].value;
    if (em == "") {
  alert("Email must be filled out");
        return false;
}
    else if(em.indexOf('@')==-1){
        alert("Email must written as XXX@XXX.com");
        return false;
    }
var age = document.forms["myForm"]["Age"].value;
    if (age== "") {
  alert("password must be filled out");
        return false;
}

}


function valid() {
var x;
var text;

    x= document.getElementById("indexx2").value;

      
   window.alert("thank you ");
    
}