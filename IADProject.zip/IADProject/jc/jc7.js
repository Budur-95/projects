        

    
    
function myFunction1() {
    alert("WELCOME TO PHP (: ");
}
function myFunction2() {
    alert("WELCOME TO JAVA (: ");
    }    
    
function myFunction3() {
    alert("WELCOME TO JAVASCRIPT (: ");
}


function myFunction4() {
    alert("WELCOME TO PERL (: ");
}


function myFunction5() {
    alert("WELCOME TO HTML (: ");
}


function myFunction6() {
    alert("WELCOME TO C++ (: ");
}


function myFunction7() {
    alert("WELCOME TO C# (: ");
    
}


function myFunction8() {
    alert("WELCOME TO PROLOG .");
}


