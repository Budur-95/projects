<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>     <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    <body >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
         <p id="javascript>"JS</P>
   

     <br><br>
           <br><br>
           <br>
        
         
        <h1>prolog syntax:</h1><br> 
        <h2>atoms:</h2>
        <p>An atom is either:</P>
        <p>1-A string of characters made up of upper-case letters, lower-case letters, digits,<br>
                and the underscore character, that begins with a lower-case letter. <b>For example:<br>
                    butch, big_kahuna_burger, and m_monroe2.</b></p>
                    <p>2-An arbitrary sequence of character enclosed in single quotes. <b>For example ’Vincent’,<br>
                        ’The Gimp’, ’Five_Dollar_Shake’, ’&^%&#@$ &*’, and ’ ’.</b> The character between<br>
                        the single quotes is called the atom name. Note that we are allowed to usespaces <br>
                        in such atoms — in fact, a common reason for using single quotes is s we can<br>
                        do precisely that.M</p>
                    <p>3-A string of special characters.<b> For example: @= and ====> and ; and :- are<br>
                            all atoms.</b> As we have seen, some of these atoms, such as ; and :- have a<br>
                            pre-defined meaning.</p><br>
                            
                      <h2>numbers:</h2>
    <p>Real numbers aren’t particularly important in typical Prolog applications. So although<br>
                most Prolog implementations do support floating point numbers or floats (that is, representations<br>
                of real numbers such as 1657.3087 or π) we are not going to discuss them<br>
                in this course.But integers (that is: ... -2, -1, 0, 1, 2, 3, ...) are useful for such tasks <br>
                as counting the elements of a list, and we’ll discuss how to manipulate them in a later lecture.<br>
                Their Prolog syntax is the obvious one: 23, 1001, 0, -365, and so on.</p><br>
    <h2>Variables</h2>
    <p>
        A variable is a string of upper-case letters, lower-case letters, digits and underscore<br>
        characters that starts either with an upper-case letter or with underscore.<b> For example,<br>
            X, Y, Variable, _tag, X_526, and List, List24, _head, Tail, _input and Output are<br>
            all Prolog variables</b> The variable _ (that is, a single underscore character) is<br> 
            rather special. It’s called the<br>anonymous variable, and we discuss it in a later lecture.
    </p>
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
