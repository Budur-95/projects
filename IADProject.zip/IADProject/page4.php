<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
        <link rel="stylesheet"type="text/css" href="style4.css"
    </head>
    <body >
       
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        <br><br>
        
        <ul class="mylist" class="nav nav-list primary left-menu" >
<li>prolog Advanced</li>
<li><a href="page1.php">prolog - What Is ? </a></li>
<li><a href="page2.php">prolog - syntax </a></li>
<li><a href="page3.php">prolog - Arithmetic  </a></li>
<li><a href="page4.php">prolog - lists</a></li>
<li><a href="page5.php">prolog- Comparing integers </a></li>
<li><a href="page6.php">prolog - Recursion </a></li>
<li><a href="page7.php">prolog - Quize </a></li>
</ul>
        <h1>Lists in prolog</h1><br>
        <p>
            As its name suggests, a list is just a plain old list of items. Slightly more precisely, it is<br>
            a finite sequence of elements. Here are some examples of lists in Prolog:<br>
            <br>
            [mia, vincent, jules, yolanda]<br>
            [mia, robber(honey_bunny), X, 2, mia]<br>
            []<br>
            [mia, [vincent, jules], [butch, girlfriend(butch)]]<br>
            [[], dead(zed), [2, [b, chopper]], [], Z, [2, [b, chopper]]]<br>
            <br>
            
        </p>
        <p>
            <b> We can learn some important things from these examples.</b><br><br>
            1. We can specify lists in Prolog by enclosing the elements of the list in square<br>
            brackets (that is, the symbols [ and ]). The elements are separated by commas.<br>
            For example, our first example <b>[mia, vincent, jules, yolanda]</b> is a list<br>
            with four elements, namely mia, vincent, jules, and yolanda. The length of<br>
            a list is the number of elements it has, so our first example is a list of length four<br><br>
            2. From our second example, <b>[mia,robber(honey_bunny),X,2,mia]</b>, we learn<br>
            that all sorts of Prolog objects can be elements of a list. The first element of this<br>
            list is mia, an atom; the second element is robber(honey_bunny), a complex<br>
            term; the third element is X, a variable; the fourth element is 2, a number. Moreover,<br>
            we also learn that the same item may occur more than once in the same<br>
            list: for example, the fifth element of this list is mia, which is same as the first<br>
            element.<br><br>
            3. The third example shows that there is a very special list, the empty list. The<br>
            empty list (as its name suggests) is the list that contains no elements. What is the<br>
            length of the empty list? Zero, of course (for the length of a list is the number of<br>
            members it contains, and the empty list contains nothing).<br><br>
            4-The fourth example <b>[mia, [vincent, jules], [butch,girlfriend(butch)]</b>is the list<br>
            [vincent,jules], and the third element is [butch,girlfriend(butch)]].In short, lists are<br>
            examples of recursive data structures: lists can be made out of lists. What is the length<br>
            of the fourth list? The answer is: three. If you thought it was five (or indeed, anything <br>
            else) you’re not thinking about lists in the right way. The elements of the list are the things<br>
            between the outermost square brackets separated by commas. So this list contains three elements:<br>
            the first element is mia, the second element is [vincent, jules], and the third element is [butch,<br>
            girlfriend(butch)].<br><br>
            5. The last example mixes all these ideas together. We have here a list which contains<br>
            the empty list (in fact, it contains it twice), the complex term dead(zed),<br>
            two copies of the list [2, [b, chopper]], and the variable Z. Note that the<br>
            third (and the last) elements are lists which themselves contain lists (namely<br>
            [b, chopper]).<br><br>
        </p>
        
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
