<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
             <link rel="stylesheet" type="text/css" href="css/stylle.css">
           <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
  <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />
    </head>
    <body  >
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>
        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div>
        
<br><br>
<hr class="style5">
         <br><br><br>
       
      <ul id="e">
           <br><br>
           <br><br>
           <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
            <li><a href="http://localhost/IADProject/phpwhatis.php">PHP - What Is ? </a></li>
            
            <li><a href="http://localhost/IADProject/phpbasics.php">PHP- Basic </a></li>
            
            <li><a href="http://localhost/IADProject/phpvariables.php">PHP -  Variables </a></li>
            
            <li><a href="http://localhost/IADProject/phpcondition.php">PHP  - Conditions</a></li>
             <li><a href="http://localhost/IADProject/phpfunction.php">PHP  - Functionss</a></li>

 </ul></div> 
           <h1 id="hwhatis">PHP:</h1><br><br>
           <p id="pwhatis">The PHP Hypertext Preprocessor (PHP) <br>
               is a programming language that allows web developers to create dynamic content<br>
               that interacts with databases. PHP is basically used for developing<br>
               web based software applications. This tutorial helps you to build your base with PHP.</p><br>
        <?php
        // put your code here
        ?>
    </body>
</html>
