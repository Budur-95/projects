<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
   <link rel="stylesheet" type="text/css" href="css/stylle.css">
        <link rel="stylesheet"  type="text/css" href="css/stylesheet.css" />
        <link rel="stylesheet"  type="text/css" href="css/style3.css" />
          <link rel="stylesheet"  type="text/css" href="css/styleSheet3.css" />

    </head>
    <body >
       
         <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>

        <div >
   <center>
   <a class="list" href="index.php" >HOME PAGE</a>
   <a class="list" href="mailto:beedoo1415@hotmail.com" >CONTACT</a>
   <a class="list" href="AboutUs.php" >ABOUT US</a>
     <a class="list" href="comment.php" >COMMENTS</a>
   </center>
    </div><br><br>
         <hr class="style5">
         <br><br><br>
       
        
        </br>
        <br><br>
        <br><br>
        
        <ul class="mylist" class="nav nav-list primary left-menu" >
<li>prolog Advanced</li>
<li><a href="page1.php">prolog - What Is ? </a></li>
<li><a href="page2.php">prolog - syntax </a></li>
<li><a href="page3.php">prolog - Arithmetic  </a></li>
<li><a href="page4.php">prolog - lists</a></li>
<li><a href="page5.php">prolog- Comparing integers </a></li>
<li><a href="page6.php">prolog - Recursion</a></li>
<li><a href="page7.php">prolog - Quize </a></li>
</ul>
        
        
         <h1>Comparing integers in prolog</h1><br>
        <p>
            Some Prolog arithmetic predicates actually do carry out arithmetic all by themselves<br>
            (that is, without the assistance of is)These are the operators that compare integers..<br></p>
        <table>
            <tr>
            <th>Arithmetic examples</th>
            <th>Prolog Notation</th></tr>
            <tr>
                <td>x<y </td>
                <td>X<Y.</td>
            </tr>
            <tr>
                <td>x<=y</td>
                <td>X =< Y</td>
            </tr>
            <tr>
                <td>x = y </td>
                <td>X =:= Y.</td>
            </tr>
            </table>
            
            
            <br>
            <p>
                <b> These operators have the obvious meaning:</b><br>
                2 < 4.<br>
                yes<br><br>
                2 =< 4.<br>
                yes<br><br>
                4 =< 4.<br>
                yes<br><br>
                <b> Moreover, they force both their right-hand and left-hand arguments to<br> be evaluated:</b><br>
                2 < 4+1.<br>
                yes<br><br>
                2+1 < 4.<br>
                yes<br><br>
                2+1 < 3+2.<br>
                yes<br>
        </p>
        <?php
        // put your code here
        ?>
    </body>
</html>
