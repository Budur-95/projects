<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>C# course</title>
        <link rel="stylesheet"  type="text/css" href="css/stylesheet1.css" />
        <script src="jc/js1.js">
        </script>
    </head>
    
    <body onLoad="debuteTemps1()" onUnload="clearTimeout(ddt1)" > 
     
     <img src="images/learn.png" alt="Stack Overflow" align="left">
         <br><br>   
        
     
     <form name="Temps11" >
    <input type="text" name="heure" size="6"onmouseover="mOver(this)" onmouseout="mOut(this)"><br> 
    
      <div >
   <center>
       <a class="list" href="index.php" >HOME PAGE</a>
       <a class="list" href="AboutUs.php" >ABOUT US</a>
   <a class="list" href="https://outlook.live.com/owa/?authRedirect=true" >CONTACT</a>
   
   </center>
                 
    </div>
           
        <br><br> 
<hr class="style5">
         <br><br><br>
      
      </form>
        
       
        <ul id="e">
            <br><br>
             <br><br>
             <br>
            <div id="b" onmouseover="mOver(this)" onmouseout="mOut(this)">
                <li><a href="csharppage.php">C# - What Is?</a></li> 
                <li><a href="basicsh.php">C# - basics</a></li> 
                <li><a href="variablessh.php">C# - Variables</a></li>
                <li><a href="Conditionalsh.php">C# - conditionals</a></li>
                <li><a href="Arraysh.php">C# - Arrays</a></li>
                <li><a href="userinputsh.php">C# - user input</a></li>
                <li><a href="csharpquize.php">C# - Quize</a></li>
       </ul></div>
             <br>
           <h1>What is C# ?</h1>
      
           <p><strong>
           C# is designed to be a platform-independent language in the tradition of Java (although it is implemented primarily on Windows). It's syntax is similar to C and C++ syntax, and C# is designed to be an object-oriented language. 
           There are, for the most part, minor variations in syntax between C++ and C#. Main has no return type, there are no semicolons after class names, there are some (to C++ programmers) strange decisions regarding capitalization - such as the capitalization of Main. Other a few differences, the syntax is often the same. This decision is reasonable, in light of the fact that C syntax has been used with several other languages - notably Java.

           Similar to Java, C# does not support multiple inheritance; instead it provides Java's solution: interfaces. Interfaces implemented by a class specify certain functions that the class is guaranteed to implement. Interfaces avoid the messy dangers of multiple inheritance while maintaining the ability to let several classes implement the same set of methods.
               </strong>

      </p>

       
       <p id="c"> 
           
      
       </p>
      
      <?php
      ?>
     
      
    </body>
</html>
