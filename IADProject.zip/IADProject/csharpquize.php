<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Quiz c#</title>
        <link rel="stylesheet"  type="text/css" href="css/styleSheetquize.css" />
         <script src="JavaScript/js1.js">
        </script>
    </head>
    <body>
         <center><h1>Quiz Questions</h1></center>
    <p>
    <form name="quiz">
    <p>
        <b>Question 1.
        <h4>Which of the following is a contextual keyword in C#?
.</h4>
     
    <input type="radio" name="q1" value="get and set">get and set<br>
    <input type="radio" name="q1" value="add">add<br>
    <input type="radio" name="q1" value="All of the above">All of the above
<br>


<p><b>
<hr>
Question 2.<br>
<h4> Which of the following is correct about Object Type in C#? </h4> 

<input type="radio" name="q2" value="The Object Type is the ultimate base class for all data types in C# Common Type System (CTS). and Object is an alias for System.Object class">
The Object Type is the ultimate base class for all data types in C# Common Type System (CTS). and Object is an alias for System.Object class.<br>
<input type="radio" name="q2" value="The object types can be assigned values of any other types, value types, reference types, predefined or user-defined types">
The object types can be assigned values of any other types, value types, reference types, predefined or user-defined types.<br>
<input type="radio" name="q2" value="All of the above">All of the above<br>

<p><b>
<hr>
Question 3.
<h4>	
Which of the following converts a type to a specified type in C#? </h4></b>


<input type="radio" name="q3" value="ToType">ToType<br>
<input type="radio" name="q3" value="ToSbyte">ToSbyte<br>
<input type="radio" name="q3" value="ToString">ToString<br>

<p><b>
<hr>
Question 4.
<h4>	
Which of the following converts a type to an unsigned big type in C#? </h4></b>
 

<input type="radio" name="q4" value="ToUInt16">ToUInt16<br>
<input type="radio" name="q4" value="ToUInt32">ToUInt32<br>
<input type="radio" name="q4" value="ToUInt64">ToUInt64<br>

<p><b>
<hr>
Question 5.
<h4>	
Which of the following access specifier in C# allows a class to hide its member variables and member functions from other functions and objects?  </h4></b>
 

<input type="radio" name="q5" value="Public"> Public<br>
<input type="radio" name="q5" value="Private">Private<br>
<input type="radio" name="q5" value="Protected">Protected<br>

<p><b>
<hr>
Question 6.
<h4>	
Which of the following property of Array class in C# gets a 64-bit integer, the total number of elements in all the dimensions of the Array?</h4></b>

<input type="radio" name="q6" value="Rank">	
Rank<br>
<input type="radio" name="q6" value="LongLength">LongLength<br>
<input type="radio" name="q6" value="Length">Length<br>

<p><b>
<hr>
Question 7.
<h4>	
Which of the following is the correct about static member variables of a class?</h4></b>


<input type="radio" name="q7" value="We can define class members variables as static using the static keyword">	
 We can define class members variables as static using the static keyword.<br>
<input type="radio" name="q7" value="When we declare a member of a class as static, it means no matter how many objects of the class are created, there is only one copy of the static member">
When we declare a member of a class as static, it means no matter how many objects of the class are created, there is only one copy of the static member.<br>
<input type="radio" name="q7" value="Both of the above"> Both of the above<br>

<p><b>
<hr>
Question 8.
<h4>	
Which of the following preprocessor directive defines a sequence of characters as symbol in C#?</h4></b>


<input type="radio" name="q8" value="define">define<br>
<input type="radio" name="q8" value="undef">undef<br>
<input type="radio" name="q8" value="region"> region<br>

<p><b>
<hr>
Question 9.
<h4>	
 Which of the following preprocessor directive allows generating a level one warning from a specific location in your code in C#?</h4></b>


<input type="radio" name="q9" value="warning">warning<br>
<input type="radio" name="q9" value="region"> region<br>
<input type="radio" name="q9" value="line"> line<br>

<p><b>
<hr>

Question 10.
<h4>	
Which .NET collection class allows elements to be accessed using a unique key?  </h4></b>


<input type="radio" name="q10" value="ListDictionary">	
  ListDictionary<br>
<input type="radio" name="q10" value="Stack"> Stack<br>
<input type="radio" name="q10" value="Hashtable"> Hashtable<br>

<p><b>
<hr>
<input type="button"value="Grade Me"onClick="getScore(this.form);">
<input type="reset" value="Clear"><p>
Number of score out of 10 = <input type= "text" size= "15" name= "mark">
Score in percentage = <input type="text" size="15" name="percentage"><br>

</form>
<p>

    <form method="post" name="Form" onsubmit="" action="">
</form>
<script>
var numQues = 10;
var numChoi = 3;
var answers = new Array(10);
    answers[0] = "All of the above";
    answers[1] = "All of the above";
    answers[2] = "ToType";
    answers[3] = "ToUInt64";
    answers[4] = "Private";
    answers[5] = "LongLength";
    answers[6] = "Both of the above";
    answers[7] = "define";
    answers[8] = "warning";
    answers[9] = "Hashtable";
    
      function getScore(form) {
   var score = 0;
  var currElt;
  var currSelection;
  for (i=0; i<numQues; i++) {
    currElt = i*numChoi;
    answered=false; 
    for (j=0; j<numChoi; j++) {
      currSelection = form.elements[currElt + j];
      if (currSelection.checked) {
        answered=true;
        if (currSelection.value == answers[i]) {
          score++;
          break;
        }
      }
    }
    if (answered ===false){alert("Do answer all the questions, Please") 
;return false;}
  }

  var scoreper = Math.round(score/numQues*100);
  form.percentage.value = scoreper + "%";
  form.mark.value=score;


}
    
</script>



        <?php
        // put your code here
        ?>
    </body>
</html>
