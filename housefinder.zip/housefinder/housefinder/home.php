<!--
Done by :
Khlood Bajahzar - 434006080
Manal Al-amer - 
Group : 2
search image
 <img src='Images/search.png' title='search' />
-->
<?php
ob_start();
session_start();

if (isset($_COOKIE["username"])) {
    $logged = $_COOKIE["username"];
} else if (isset($_SESSION["username"])) {
    $logged = $_SESSION["username"];
}
?>
<html>
    <head>
        <title>House Finder</title>
        <link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
        <meta name="author" content="Khlood , Manal">
        <meta name="keywords" content="finder, houses, hotel, apartment, travel, business">
    </head>

    <body>
        <?php
        ini_set('display_errors', 1);
        error_reporting(E_ALL & ~E_NOTICE);


        $city = array('Makkah', 'Jeddah', 'Riyadh', 'Jubail', 'khubar', 'Tabuk', 'Madienah', 'Taif', 'Abha');

        print '
		<div class="header"><img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br>
		<table>
			<tr><td>
				


';


        if (!empty($logged)) {

            print '<p style="color:#004778;font-size:20px"> Welcome  </strong> <i style="color:red;font-size:22px">' . $logged . '</i></p>

You can show and edit your profile from <a style="color:green; font-size:14px;" href="profile.php">here</a>.</br>
This site will help you to find a house , hotel or apartment on any city you want with short time .</br>

Hope to find what you want';
        } else {

            print '<p style="color:#004778;font-size:20px"><strong> Welcome to House Finder website</strong> <i style="color:red;font-size:22px">*</i></p>

This site will help you to find a house , hotel or apartment on any city you want with short time .</br>

Hope to find what you want';
        }

        print '



			
			</td></tr>

			<tr><td><div align="center">
				<br	/>
				<form action="result.php" method="post">
					<br	/>
					<p>Please, select one of Saudi Arabia cities :</p>
                    <select id="city" name="city">';

        foreach ($city as $key => $value) {
            print "<option>$value</option>";
        }

        print '
                </select>
					<br	/>
					<br	/>
            <input type="submit"  value="Search" id="search" name="info" />
					<br	/>';
        if(isset($logged)){
            print '<a href="LogOut.php">Log out</a> |';
        }else{
            print '<a href="LogIn.php">Log in</a> |';
        }

	print '<a href="Regester.php">Regester</a>
					<br	/>
					<br	/>
				</form>
			</div></td></tr>

			<tr><td class="center">
				<p>
				<a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
				<a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
				<a href="home.php"><img src="Images/home.png" title="home" /></a> |
                <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
				<a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
				</p>
			</td></tr>

			<tr><td class="center">
				<hr	/>
				<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
			</td></tr>
		</table>

        <br><br>
		<img align="right" src="Images/footer.png" title="footer" 	/>
		<br	/>
		';
        ?>
    </body>
</html>
        <?php
        ob_end_flush();
        ?>