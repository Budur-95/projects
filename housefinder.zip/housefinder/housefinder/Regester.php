<?php
ob_start();
session_start();
?>
<html>
	<head>
		<title>Regester</title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
	</head>
	<body>
		<?php
            
            ini_set ('display_errors', 1);
            error_reporting (E_ALL & ~E_NOTICE);

        print '<div class="header" align="center"> 
		</div>
                 <br>';
        print'<table style="width:30%;margin-left:430px;" cellspacing="5">';

        if(isset($_POST['submit'])){

            $name = $_POST['fName'];
        	$pass = $_POST['password'];
        	$email = $_POST['mail'];

        	if(empty($name)){
        		print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >First name is required</p></td></tr>';
        	}else if(empty($pass) || strlen($pass) > 10){
                print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >password is required and less or equal 10 characters</p></td></tr>';
        	}else if(empty($email)){
                print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >email is required</p></td></tr>';
        	}else{
                $con = mysqli_connect("localhost","root","") or die("Error Connection");
            	$db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");

            	$getData = mysqli_query($con, "select FIRST_NAME, EMAIL from register where FIRST_NAME = '$name' or EMAIL = '$email'");
                echo (var_dump($getData));
                $rowData = mysqli_fetch_array($getData );
            	if( count($rowData) > 0 ){
                    print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >User already exists</p></td></tr>';
            	}else{
                    $statement = "INSERT INTO register (FIRST_NAME, PASSWORD, EMAIL) VALUES ('$name', '$pass', '$email' )";
                	$insert = mysqli_query($con, $statement);
                	if($insert){
                           
                		print '<meta http-equiv="refresh" content="0;  URL=thankYou.php">';
                	} else {
                        print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >Error Register</p></td></tr>';
                	}
                }

                mysqli_close($con);
            }

        }

		print '
		<form action="Regester.php" method="post">
				<tr>
				<th class="center">First name :</th>
				<td class="center"><input type="text" name="fName"	/></td>
				</tr>

				<tr>
				<th class="center">Password :</th>
				<td class="center"><input type="password" name="password" 	/></td>
				</tr>

				<tr>
				<th class="center">E-mail :</th>
				<td class="center"><input type="text" name="mail" id="mail" onchange="checkE(\'eError\',this.id)" 	/></td>
				</tr>

				<tr>
				<td></td>
				<td><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="eError"></p></td>
				</tr>
				<tr>
				<td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="e-Error"></p></td>
				</tr>

				<tr>
				<td colspan="2" class="center"><input type="submit" name="submit" value="Regester" 	/>
									<input type="reset" value="Reset" 	/></td>
				</tr>

				<tr><td colspan="2"class="center">
				<p>
            <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
            <a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
            <a href="home.php"><img src="Images/home.png" title="home" /></a> |
            <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
            <a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
    			</p>
				</td></tr>

		</form></table>
	<footer style="margin-top:3cm"><img align="right" src="Images/footer.png" title="footer"/></footer>';
		?>
	</body>
</html>
<?php
ob_end_flush();
?>