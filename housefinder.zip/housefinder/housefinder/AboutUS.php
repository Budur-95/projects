<html>
	<head>
		<title>About us</title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
	</head>
	<body>

		<?php
            
            ini_set ('display_errors', 1);
            error_reporting (E_ALL & ~E_NOTICE);
            
		print '
		<div class="header">
		<img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br>
		<table>
			<tr><td>
			<dl>
			<dt>History</dt>
				<dd>House Finder is a site which found by <b>Khlood & Manal</b> whom are studying computer sciences.In 2015, they created an online platform to find a hotels and accommodations for businesses and travelers around the world.

  <p><b>Khlood</b>, was born in august 1995, studying computer sciences  in Um Al-Qura university, Saudi Arabia, Makkah.
	<br	/>
  <b>Manal</b>, was born in Jun 1995, studying computer sciences  in Um Al-Qura university, Saudi Arabia , Makkah.</p>

They established the site after sharing a group of ideas, when they had been conducted the meeting last month and they come up with creating this site to help others.
Finding their meets on their distention in quick and trusted way.</dd>

			<dt>Targets</dt>
				<dd>Our target is to help and support finding the suitable place for those whom need to enjoy their days and live with.Also, to ensure that all customers whom we serve are feeling good with our service through online finding  and to simplify their effort to find their distention needs. to be their best web site and that is the most targetable we need.</dd>

			<dt>Future plan</dt>
				<dd>We plan to increase finding the hotels around the world and we are in coordination with some of the biggest countries such as united state, Egypt,Casa plank and others . Moreover , we plan to provide an online booking , agent  on every hotels around the word to direct and help our customers and to make sure their reservation will be ready to enjoy it as well .</dd>
			</dl>
			</td></tr>

			<tr><td class="center">
			<p>
            <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
            <a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
            <a href="home.php"><img src="Images/home.png" title="home" /></a> |
            <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
            <a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
			</p>
			</td></tr>

			<tr><td class="center">
			<hr	/>
			<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
			</td></tr>
		</table>
		<img align="right" src="Images/footer.png" title="footer"	/>
		';
		?>
	</body>
</html>