<?php
ob_start();
session_start();
?>
<html>
	<head>
		<title> thank you </title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
		
	</head>
	<body>

	<?php

        ini_set ('display_errors', 1);
        error_reporting (E_ALL & ~E_NOTICE);
        
        print '
        <h2 align="center"> Thank you for register </h2>
        <p align="center">You will be redirected to home page after seconds</p>
        <meta http-equiv="refresh" content="3; URL=home.php">
        ';
	?>
	
	</body>
</html>
<?php
ob_end_flush();
?>