<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
        <title>Create the Database</title>
    </head>
    <body>
        <?php
        // Script 12.3 - create_db.php (This script connects to the MySQL server. It also creates and selects the database.
// Address error handling.
        ini_set('display_errors', 1);
        error_reporting(E_ALL & ~E_NOTICE);
// Attempt to connect to MySQL and print out messages.
        if ($dbc = mysqli_connect('localhost', 'root', '')) {// حطي بيناتك 
            if (!@mysqli_select_db($dbc, 'housefinder_db')) {//حطي اسم الداتا بيس حقتك
                die('<p>Could not select the database because: <b>' . mysqli_error($dbc) . '</b></p>');
            }
        } 
            die('<p>Could not connect to MySQL because: <b>' . mysqli_error($dbc) . '</b></p>');
        
// Define the query.
        $query = 'CREATE TABLE APARTMENTS (	CITY VARCHAR(100) NOT NULL,NAME VARCHAR(100) NOT NULL,PHONE INT(50),
EMAIL VARCHAR(100) NULL,NOTES VARCHAR(100)  NULL,ADDRESS VARCHAR(100) NOT NULL,
IMG_NAME VARCHAR(100)  NULL,AREA VARCHAR(100)  NULL, PRICE INT(50) NULL,NUM_OF_ROOMS INT(50)  NULL )';


// Run the query.
        if (@mysqli_query($dbc, $query)) {
            print '<p>The table has been created.</p>';
        } else {
            die('<p>Could not create the table because: <b>' . mysqli_error($dbc) . '</b>.</p>
<p>The query being run was: ' . $query . '</p>');
        }


        $query1 = 'CREATE TABLE HOTELS (	CITY VARCHAR(100) NOT NULL,NAME VARCHAR(100) NOT NULL,PHONE INT(50),
EMAIL VARCHAR(100)  NULL,NOTES VARCHAR(100)  NULL	,ADDRESS VARCHAR(100)  NULL,
IMG_NAME VARCHAR(100)  NULL)';


// Run the query.
        if (@mysqli_query($dbc, $query1)) {
            print '<p>The table has been created.</p>';
        } else {
            die('<p>Could not create the table because: <b>' . mysqli_error($dbc) . '</b>.</p>
<p>The query being run was: ' . $query1 . '</p>');
        }

        $query2 = 'CREATE TABLE HOUSES (	CITY VARCHAR(100) NOT NULL ,NAME VARCHAR(100) NOT NULL,PHONE INT(50),
EMAIL VARCHAR(100)  NULL,NOTES VARCHAR(100)  NULL	,ADDRESS VARCHAR(100) NOT NULL,
IMG_NAME VARCHAR(100)  NULL,AREA VARCHAR(100)  NULL, PRICE INT(50)  NULL,NUM_OF_ROOMS INT(50)  NULL )';

// Run the query.
        if (@mysqli_query($dbc, $query2)) {
            print '<p>The table has been created.</p>';
        } else {
            die('<p>Could not create the table because: <b>' . mysqli_error($dbc) . '</b>.</p>
<p>The query being run was: ' . $query2 . '</p>');
        }
        
        /////////////
        
              $query3 = 'CREATE TABLE User (	FIRST_NAME VARCHAR(100) NOT NULL ,PASSWORD VARCHAR(100) NOT NULL,
EMAIL VARCHAR(100) )';

// Run the query.
        if (@mysqli_query($dbc, $query3)) {
            print '<p>The table has been created.</p>';
        } else {
            die('<p>Could not create the table because: <b>' . mysqli_error($dbc) . '</b>.</p>
<p>The query being run was: ' . $query3 . '</p>');
        }
        mysqli_close($dbc); // Close the connection.	
        ?>
    </body>
</html>





