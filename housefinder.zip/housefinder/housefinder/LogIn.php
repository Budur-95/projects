<?php
ob_start();
session_start();
?>
<html>
	<head>
		<title>Log in</title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
	</head>
	<body>
		<?php
            
            ini_set ('display_errors', 1);
            error_reporting (E_ALL & ~E_NOTICE);

            print '<div class="header" align="center"> 
                
		</div>
                 <br> <table style="width:30%;margin-left:330px;" cellspacing="5">';

        if(isset($_POST['submit'])){
            $name = $_POST['fName'];
        	$pass = $_POST['password'];
        	$save = $_POST['save'];

            if(empty($name)){
                print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >First name is required</p></td></tr>';
            }else if(empty($pass) || strlen($pass) > 10){
                print '<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >Less or equal 10 characters password is required</p></td></tr>';
            }else{
                $con = @mysqli_connect("localhost","root","") or die("Error Connection");
            	$db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");

            	$getData = mysqli_query($con, "SELECT FIRST_NAME, PASSWORD FROM register WHERE FIRST_NAME = '$name' and PASSWORD = '$pass'");
                $rowData = mysqli_fetch_array($getData);
            	if( count($rowData) > 0 ) {//////
                    if( empty($save) ){
                        $_SESSION['username'] = $name;
                    } else{
                        setcookie("username", $name, time() + (86400 * 300), "/");
                    }
            		print'<meta http-equiv="refresh" content="0; URL=Welcome.php">';
            	} else {
                    print'<tr><td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" >Error Log in</p></td></tr>';
                }

                mysqli_close($con);
            }

        }

		print '
            
		<form action="Login.php" method="post">
				<tr>
				<th class="center">First name :</th>
				<td class="left"><input type="text" name="fName" /></td>
				</tr>

				<tr>
				<th class="center">Password :</th>
				<td class="left"><input type="password" name="password"/></td>
				</tr>

                <tr>
				<th class="center">save Login :</th>
				<td class="left"><input type="checkbox" name="save" /></td>
				</tr>

				<tr>
				<td colspan="2" class="center">
                    <input type="submit" name="submit" value="Log in" />
				    <input type="reset" value="Reset" />
				</td>
				</tr>

				<tr><td colspan="2" class="center">
				<p>
            <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
            <a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
            <a href="home.php"><img src="Images/home.png" title="home" /></a> |
            <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
            <a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
    			</p>
				</td></tr>
		</form></table>
            <br><br>
            <footer style="margin-top:3cm"><img align="right" src="Images/footer.png" title="footer"/></footer>
            <br	/>

		';
		?>
	</body>
</html>
<?php
ob_end_flush();
?>