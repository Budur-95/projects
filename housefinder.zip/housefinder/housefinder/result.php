<html>
    <head>
        <title>results</title>
        <link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
        <script src="JavaScript/javascript.js"></script>
    </head>
    <body>
        <div class="header">
            <img src="images/randa.gif" id="panner">
            <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
            <img src="images/flyin2.gif"  id="panner2">


        </div>
        <br>

        <?php
        ini_set('display_errors', 1);
        error_reporting(E_ALL & ~E_NOTICE);

        session_start();

        $_SESSION['city'] = $_POST['city'];


        print '
            <table    style="width:95%">
			<tr>
			<td> 
			<br	/>
			<a href="HotelsDetails.php"><div align="center"><img src="Images/land.png" title="Hotels"></a> </div></td>

			<td>
			 
			<br	/>
			<a href="HousesDetails.php"><div align="center"><img src="Images/house.png" title="Houses"></a>
			</div></td>

			<td>  
			 
			<br	/>
			<a href="ApartmentsDetails.php"><div align="center"><img src="Images/apartment.png" title="Apartments"></a>
			</div></td>
			</tr>

			<tr>
			<td colspan="3" align="center" style="color:#556EA4;font-size:16px;">
			<br	/>
			<br	/>
<strong>
			Some of the important places in the city
</strong>
			<br	/>
<br	/>
			</td>
			</tr>';
        print'<tr>';

        switch ($_POST['city']) {
            case 'Makkah':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/makkahHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/makkahS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/makkahOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;

            case 'Jeddah':
                print' <td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/jeddahHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/jeddahS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/jeddahOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;

            case 'Riyadh':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/RiyadhHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/RiyadhS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/riyadahothers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'Jubail':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/jubailHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/jubailS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/jubailothers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'khubar':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/khubarHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/khubarS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/khubarOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'Taif':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/taifHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/taifS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/taifOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'Madienah':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/madinahHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/madinahS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/madinahOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'Abha':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/abhaHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/abhaS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/abhaOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
            case 'Tabuk':
                print'<td><div align="center"><strong>Hospital:</strong> </br>';
                $data = file('cityInfo/tabukHos.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Schools:</strong> </br>';
                $data = file('cityInfo/tabukS.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                print'<td><div align="center"><strong>Others:</strong> </br>';
                $data = file('cityInfo/tabukOthers.txt');
                $string_words = implode('<br />', $data);
                print " $string_words ";

                print'</td>';

                break;
        }
        print'</tr>';


        print'
			<tr><td colspan="3" class="center">
				<hr	/>
				<br	/>
				<p>
                <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
				<a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
				<a href="home.php"><img src="Images/home.png" title="home" /></a> |
                <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
				<a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
				</p>
			</td></tr>

			<tr><td colspan="3" class="center">
				<hr	/>
				<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
			</td></tr>
            </table>';

        print ' <img align="right" src="Images/footer.png" title="footer"	/><br	/>';
        ?>
    </body>
</html>