<?php
ob_start();
session_start();

?>
<html>
	<head>
		<title>Details</title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
	</head>
	<body>
	
	<?php
        
        ini_set ('display_errors', 1);
        error_reporting (E_ALL & ~E_NOTICE);
        
        session_start();
        extract($_SESSION);
        $city = $_SESSION['city'];
        
        
        $con = @mysqli_connect("localhost","root","") or die("Error Connection");
        $db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");
        
        $getData = mysqli_query($con, "SELECT * FROM housefinder_db.APARTMENTS WHERE CITY = '$city'");
        
        print '<div class="header"><img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br><table><tr><td>';
        
        while($rowData = mysqli_fetch_array($getData)){
            
            print '<tr><td><table style="margin-left:300px" id="innerBorder" border="1"><tr><td class="center" colspan="2"><br   /><img src="'.$rowData['IMG_NAME'].'" title="" width="200" height="100"	/><br   /><br   /></td>';
            
            print '<td><b>Name :</b>'.$rowData['NAME'].'<br	/>';
            
            print '<b>Phone :</b>'.$rowData['PHONE'].'<br	/>';
            
            print '<b>E-mail:</b>'.$rowData['EMAIL'].'</td></tr>';
            
            print '<tr><td colspan="3"><b>Description :</b><br	/>'.$rowData['DESCRIPTION'].'</td></tr>';
            
            print '<tr><td><b>MAP:</b><br	/><p class="center"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3709.5233010735706!2d39.106897314562616!3d21.604522985689314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbd751aa2b57%3A0xd32f14ab8ce46662!2s$city+'.$rowData["NAME"].'!5e0!3m2!1sen!2ssa!4v1459625552114" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></p></td>';
            
            print '<td colspan="2"><b>Notes :</b>'.$rowData['NOTES'].'<br	/></td></tr>';
            
            print '<tr><td class="center"><b>Area:</b>'.$rowData['AREA'].'</td>';
            print '<td class="center"><b>Number of rooms:</b>'.$rowData['NUM_OF_ROOMS'].'</td>';
            print '<td class="center"><b>Price:</b>'.$rowData['PRICE'].'</td></tr></table></td></tr>';
        }
        mysqli_close($con);
	print '
            <tr><td colspan="2">
			<p class="center">
        <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
        <a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
        <a href="home.php"><img src="Images/home.png" title="home" /></a> |
        <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
        <a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>			</p>
			</td></tr>

			<tr><td colspan="2" class="center">
				<hr	/>
				<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
			</td></tr>
		</table>
		<img align="right" src="Images/footer.png" title="footer"	/>
		<br	/>
	';
	?>
	
	</body>
</html>
<?php
ob_end_flush();
?>