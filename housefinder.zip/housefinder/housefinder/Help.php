<html>
    <head>
        <title>Help</title>
        <link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
    </head>
    <body>

        <?php
        ini_set('display_errors', 1);
        error_reporting(E_ALL & ~E_NOTICE);

        print '
		<div class="header">
		<img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br>
		<table><tr><td>
                                     <h1>How to register in website?</h1>
                                     <p>In home page exist link Register press on, fill the form and submit</p>
                                     <h1>How to choose city</h1>
                                     <p>In Home page choose any city that you want from options.</p>
                                     <h1>what is the way to contact</h1>
                                     <p>From home page press on link contact and will open email and send that you want.</p>
                                     <h1>How to Know information about website?</h1>
                                     <p>page aboust us press on and will dispaly all information about website.</p>
                                     <h1>How to Know new advertise in website</h1>
                                     <p> exisiting in all pages </p>
                                     <h1>How to choose specific type of RealEstate</h1>
                                     <p> from home page after choose city will display type of specific RealEstate and choose of them </p>
                                 </td>
                             </tr>
                              
                         
                             <tr>
                                 <td class="center">
			 <p>
                                     <a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
                                     <a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
                                     <a href="home.php"><img src="Images/home.png" title="home" /></a> |
                                     <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
                                     <a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
			 </p>
			</td>
                             </tr>

			<tr>
                                    <td class="center">
			      <hr	/>
			<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
		              </td>
                                 </tr>
                                 
                </table> ';
        ini_set('display_errors', 1);
        error_reporting(E_ALL & ~E_NOTICE);

        print ' <img align="right" src="Images/footer.png" title="footer"	/><br	/>';
        ?>

    </body>
</html>