<?php
ob_start();
session_start();
?>
<html>
	<head>
		<title> Log Out </title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
	</head>
	<body>

	<?php
        
        ini_set ('display_errors', 1);
        error_reporting (E_ALL & ~E_NOTICE);


    if( isset($_COOKIE['username']) ){
        unset($_COOKIE['username']);
        setcookie("username", null, time() - 3600, "/");
    } else {
        session_destroy();
    }

    print '
    <h2 align="center"> Logged out successfully </h2>
    <p align="center">You will be redirected to home page after seconds</p>
    <meta http-equiv="refresh" content="2; URL=home.php">
    ';
	?>

	</body>
</html>
<?php
ob_end_flush();
?>