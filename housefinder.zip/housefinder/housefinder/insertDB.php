<?php
$servername = "localhost";
$username = "root";// حطي بيناتك
$password = "";// حطي بيناتك
$dbname = "housefinder_db";//حطي اسم الداتا بيس حقتك

   
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// inserting in apartments
   
   $sql = "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Jeddah' , 'Loaloat Jeddah Apartments' , 0557755891 , 'Loaloat@gmail.com' ,'',
	  'Seteen Street , Al Sharafyah District، Jeddah 21433',null,null,null,null  );";
	  
   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Jeddah' , 'Danat Quriash Furnished Apartments' , 026919402 , 'Danat@gmail.com' ,'',
	  'Quraysh St, As Salamah District, Jeddah 23437',null,null,null,null  );";
	 
   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
           VALUES  ( 'Jeddah' , 'Ayyam Inn' , 0126918368 , 'Ayyam@gmail.com' ,'',
	  'Saqr Quraish, As Salamah, Jeddah',null,null,null,null  );";	
	  
	//------------------ 	  
	  
	  
   $sql .= "INSERT INTO APARTMENTS(CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Makkah' , 'Manazl AlSteen Furnished Apartments' , 0504545082 , 'Manazl@gmail.com' ,'',
	  'Abdullah Aarif Street, Al Nozha District، Mecca 21955',null,null,null,null  );";

   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Makkah' ,'Dyafat Al Haramen -Dar Al Motaken' , 0568490013 , 'Dyafat@gmail.com' ,'',
	  'Al-Aziziah , Street Abdullah Al Khyat، Mecca 21955',null,null,null,null  );";
	  
	//------------------ 	  
	  
	  
   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Riyadh' , 'Corner Bahia' , 0514545212 , 'Corner@gmail.com' ,'',
	  'Al Aziziyah, Riyadh',null,null,null,null  );";
	  
   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Riyadh' , 'Dorean apartment' , 0514877712 , 'Dorean@gmail.com' ,'',
	  'Dhahrat Laban, Riyadh, Riyadh Region',null,null,null,null  );";


	//------------------  
 	  
   $sql .= "INSERT INTO APARTMENTS(CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Jubail' , 'Mergab Tower Hotel Apartments' , 0133444477 , 'Mergab@gmail.com' ,'',
	  ' Al Jubail',null,null,null,null  );"; 
	  
	  
   $sql .= "INSERT INTO APARTMENTS  (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Jubail' , 'Amasi For Hotel Suite' , 0133422277 , 'Amasi@gmail.com' ,'',
	  'Prince Sultan Street, Al Jubail 35513',null,null,null,null  );";


	//------------------ 

   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Khubar' , 'Danat Hotel Apartments	', 0133475277 , 'Danat@gmail.com' ,'',
	  'al joharah Street, Al khubar ',null,null,null,null  );";

   $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Khubar', 'Ward Aolaya' , 013785277 , 'Ward@gmail.com' ,'',
	  ' AL Aolaya Street, Al khubar ',null,null,null,null  );";	  
	  
	//----------------  

   $sql .= "INSERT INTO APARTMENTS(CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Tabuk' , 'Zain Tabuk Apartment ' , 014585277 , 'Zain@gmail.com' ,'',
	  ' kateb Street ',null,null,null,null  );";
	  
  $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Tabuk' , 'Gadeen Furnished Apartment ' , 013785277 , 'Gadeen@gmail.com' ,'',
	  ' AL Raboah Street ',null,null,null,null  );"; 	  
	  
	//------------------
	
  $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'AL Madienah' , 'Zaf Furnished Unites ' , 0127465577 ,'Zaf@gmail.com' ,'',
	  ' othman bn afan Street ',null,null,null,null  );";
	  
  $sql .= "INSERT INTO APARTMENTS(CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'AL Madienah' , 'Diyar Al Aziziyah ' , 0122254477 , 'Diyar@gmail.com' ,'',
	  ' Al Aziziyah Street ',null,null,null,null  );"; 
	  
	//------------------  
	
  $sql .= "INSERT INTO APARTMENTS  (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Taif' , 'Rest Horizon Hotel Apartments ' , 0127385555 , 'Rest@gmail.com','',
	  'airport road  ',null,null,null,null  );";

  $sql .= "INSERT INTO APARTMENTS (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Taif' , 'Sadeem Apartments' , 0127377777 , 'Sadeem@gmail.com' ,'',
	  'Shubra, Taif 26523 ',null,null,null,null  );";	
	  
	//------------------

  $sql .= "INSERT INTO APARTMENTS  (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)
      VALUES  ( 'Abha' , 'safoh Apartments ' , 0172284366 , 'safoh@gmail.com' ,'',
	  ' Umar Ibn Abdulaziz, Al Khasha, Abha 62521 ',null,null,null,null  );";	
		  
	
  $sql .= "INSERT INTO APARTMENTS  (CITY,NAME, PHONE,EMAIL,NOTES,ADDRESS,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS) 
      VALUES  ( 'Abha', 'alartga Apartments ' , 0172253333 , 'alartga@gmail.com' ,'',
	  'Al Imam Muhamed Ibn Saud, Al Qabil, Abha 62521 ',null,null,null,null  );";	
	  
	  
	  
	  //inserting in hotels 
		  	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Makkah', 'Dar Al Tawhid InterContinental' , 0125295000 , 'InterContinental@gmail.com' ,null,
		 'Ibrahim Al Khalil Street, Alsouq Alsagheer Tunnel, Mecca ',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Makkah', 'Makkah Hilton Towers' , 0125340000 , 'Hilton@gmail.com' ,null,
		 'Ibrahim alkalil , makkah ',null  );";

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Makkah', 'movenpick makkah hater tower' , 00966125717171 , 'movenpick@gmail.com' ,null,
		 ' Abraj Al-Bait Makkah  ',null  );";	
		 
	//--------------	 
	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Riyadh', 'four season hotel' , 0112115000 , 'season@gmail.com' ,null,
		 'Kingdom Centre, Al Urubah Road, Alolya, Riyadh 12214 ',null  );";	

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Riyadh', 'Holiday Inn ' , 0114505054 , 'Holiday@gmail.com' ,null,
		 '2907 Sh. Abdulwahab Bin Abdullah St, Al Izdihar, Unit 1 – Izdihar District, Riyadh 00000',null  );";			 
 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Riyadh', 'Radisson Blu Hotel' , 0114791234 , 'Radisson@gmail.com' ,null,
		 'King Abdulaziz Street Al Mubarakiah Plaza, Riyadh ',null  );";
		 
    //---------------	

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Jeddah', 'Hilton hotel' , 01280083121 , 'Hilton@gmail.com' ,null,
		 'sa, jeddah , corinash ',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Jeddah', 'Sheraton' , 01908339715 , 'Sheraton@gmail.com' ,null,
		 'sa, jeddah , corinash ',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Jeddah', 'Movenpeick Hotel' , 01950003425 , 'Movenpeick@gmail.com' ,null,
		 'sa , jeddah , city center ',null  );";

    //-----------------


   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Jubail', 'Coral Jubail Hotel' , 0133628800 , 'Coral@gmail.com' ,null,
		 'King Faisal N, Al Jubail ',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Jubail', 'Karan Hotel' , 0133471144 , 'Karan@gmail.com' ,null,
		 'Jubal , Al Fanater area - Corniche, Al Jubail 99999 ',null  );";
		 
	 //-----------------
	 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'khubar', 'Le Méridien Al Khobar Hotel' , 01038969000 , 'Meridien@gmail.com' ,null,
		 'Prince Turkey Street, Cornishe, Al Khobar',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'khubar', 'Tulip Inn Al-Khobar Hotel' , 0138825588 , 'Tulip@gmail.com' ,null,
		 'King Fahd Road, Al Hizam Al Thahabi, Al Khobar 31952',null  );";

     //-----------------
	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Tabuk', 'Sahara Tabuk Makarim Hotel' , 0144221212 , 'Sahara@gmail.com' ,null,
		 'Prince Fahd Bin Sultan Street, Tabuk',null  );";
		 
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Tabuk', 'Maysaloon Hotel' , 0144252222 , 'Maysaloon@gmail.com' ,null,
		 'King Fahd Branch Rd, Tabuk 47913',null  );";
		 
     //-----------------
	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'AL Madienah', 'Madinah Hilton Hotel' , 0148201000 , 'Hilton@gmail.com' ,null,
		 'King Fahd Rd, Medina 03936',null  );";	

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'AL Madienah', 'Mövenpick Hotel Anwar Al Madinah' , 0148181000 , 'Movenpick@gmail.com' ,null,
		 ' Medina ',null  );";
		 
     //-----------------
	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Taif', 'InterContinental  Hotel' , 0127505050 , 'InterContinental@gmail.com' ,null,
		 'Airport Rd, Taif 21944',null  );";

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Taif', 'Casablanca Hotel' , 0127370081 , 'Casablanca@gmail.com' ,null,
		 'Asharqiyyah, Taif 26513',null  );";

     //-----------------
	
   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Abha', 'Abha Crown Hotel' , 0172322224 , 'Crown@gmail.com' ,null,
		 'Al Arin, Abha 62528',null  );";

   $sql .= "INSERT INTO HOTELS (	CITY ,NAME,PHONE,EMAIL,NOTES,ADDRESS ,IMG_NAME )
         VALUES  ( 'Abha', 'Narcissus Hotel' , 0172299979 , 'Narcissus@gmail.com' ,null,
		 ' Al Bahrain, As Sadd, Abha 62521',null  );";

			
	
      
if ($conn->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>