<?php 
ob_start();

session_start();

    

if( isset($_COOKIE["username"]) ){

    $logged = $_COOKIE["username"];

} else {

    $logged = $_SESSION["username"];

}


    if(empty($logged)){

        print '<script type="text/javascript">alert("Please join us and login into website to add a real estate");</script>';
print '<script>window.close();</script>';
        

    }



        ?>
<?php 

$servername = "localhost";
$username = "root";// حطي بيناتك
$password = "19951995";// حطي بيناتك
$dbname = "housefinder_db";//حطي اسم الداتا بيس حقتك
@$city=$_POST['city'];
@$name=$_POST['Name'];
@$phone=$_POST['phone'];
@$email=$_POST['e-mail'];
@$Notes=$_POST['Notes'];
@$Address=$_POST['Address'];
@$selected_radio=$_POST['radioButton']; 
@$area=$_POST['area'];
@$numOfRoom=$_POST['numOfRoom'];
@$prices=$_POST['prices'];
@$thefile="{$_FILES['thefile']['name']}";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
   
if (isset ($_POST['submit'])) {
	
	
if ($selected_radio == "Hotel"){
$sql = "INSERT INTO housefinder_db.HOTELS (CITY ,NAME,PHONE,EMAIL,NOTES,DESCRIPTION ,IMG_NAME )VALUES  ( '$city', '$name' , '$phone' , '$email' ,'$Notes','$Address', '$thefile' )";
		
                                 $conn->query($sql);
		 
		
}

///////////

	if ($selected_radio == "Hoses"){
			
  $sql2 = "INSERT INTO housefinder_db.HOUSES (CITY,NAME, PHONE,EMAIL,NOTES,DESCRIPTION,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)VALUES  ( '$city', '$name' , '$phone' , '$email' ,'$Notes','$Address','$thefile','$area','$numOfRoom','$prices'  )";
	 
               $conn->query($sql2);
    
		
}
///////////////
if ($selected_radio == "Apartments"){
			$sql3 = "INSERT INTO housefinder_db.APARTMENTS  (CITY,NAME, PHONE,EMAIL,NOTES,DESCRIPTION,IMG_NAME,AREA,PRICE,NUM_OF_ROOMS)VALUES  ( '$city', '$name' , '$phone' , '$email' ,'$Notes','$Address','$thefile','$area','$numOfRoom','$prices'  )";
		 $conn->query($sql3);
		 
		 
		 
}
if (move_uploaded_file ($_FILES['thefile']['tmp_name'], "{$_FILES['thefile']['name']}")) {
	
  echo "<script> alert('Your information has been uploaded. Thank you');</script>" ;
   echo "<script>window.close();</script>";
 	
	}
	else {
		echo "<script> alert('Your information could not be uploaded. Try again'); </script>" ;
		echo "<script>window.close();</script>";
	}
	
 



// inserting in apartments
 

  

}
$conn->close();

?>
<html>
	<head>
		<title>Advertising</title>
		<link href="Css/style13.css" type="text/css" rel="stylesheet"	/>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />

	</head>
	<body>
		<?php
            
            ini_set ('display_errors', 1);
            error_reporting (E_ALL & ~E_NOTICE);
            
            $city = array('Makkah', 'Jeddah', 'Riyadh', 'Jubail', 'khubar', 'Tabuk', 'Madienah', 'Taif', 'Abha');
            
            
		print '
		<div class="header">
		<img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br>
		<table>
		<tr><td>
		<br	/>
		<table style="width:40%;margin-left:155px;" cellspacing="5">
		<form action="Advertising.php" enctype="multipart/form-data"  method="post">
				<tr>
				<th align="left"> Name :</th>
				<td align="left"><input required type="text" name="Name"/></td>
				<th align="left">The city :</th>
                                            <td align="left"><select id="city" name="city">';
            
                foreach($city as $key => $value){
                print "<option>$value</option>";
                }
            
            print'</td></tr>

				<tr>
				<th align="left">F\Phone number :</th>
				<td align="left"><input required type="text" name="phone" id="phone" onchange="checkNum(\'numError\',this.id)"	/></td>
				<th align="left">E-mail :</th>
				<td align="left"><input required type="text" name="e-mail" id="mail" onchange="checkE(\'e-Error\',this.id)" 	/></td>
				</tr>
			
				<tr>
				<td></td>
				<td><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="numError"></p></td>
				<td></td>
				<td><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="e-Error"></p></td>
				</tr>

				<tr>
				<td colspan="4" class="center"><b>Commercial about :</b>
						<input type="radio" name="radioButton" value="Lands" checked="checked"/>Hotel
						<input type="radio" name="radioButton" value="Hoses"	/>Hoses
						<input type="radio" name="radioButton" value="Apartments"	/>Apartments
				</td>
				</tr>

                                            <tr></tr>
				<tr>
				<th>Area</th>
				<th colspan="2">Numbers of rooms</th>
				<th>Prices</th>
				</tr>
						
				<tr>
				<td class="center"><input type="text" name="area" id="area" onchange="checkNum(\'aError\',this.id)" 	/></td>
				<td colspan="2" class="center"><input type="text" name="numOfRoom" id="numbers of rooms" onchange="checkNum(\'rError\',this.id)" 	/></td>
				<td class="center"><input type="text" name="prices" id="prices" onchange="checkNum(\'pError\',this.id)" 	/></td>
				</tr>

				<tr>
				<td class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="aError"></p></td>
				<td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="rError"></p></td>
				<td class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="pError"></p></td>
				</tr>

				<tr>
				<th colspan="2" align="left">Address :</th>
				<th colspan="2" align="left">Notes :</th>
				
				
				</tr>

				<tr>
				<td colspan="2"><textarea required name="Address" cols="30" rows="10"></textarea></td>
				<td colspan="2"><textarea name="Notes" cols="30" rows="10"> </textarea></td>
				
				</tr>
				<tr>
				<th colspan="2" align="left">Images :</th>
				
				</tr>
				<tr>
				
				<td colspan="2">
				<input type="hidden" name="MAX_FILE_SIZE" value="30000" /> <input type="file" required name="thefile"  />
				</td>
		
				</tr> 
<tr>
				<td colspan="4"><p id="warning"><b> The page will close immediately after The information has been uploaded </b></p>
				</tr>
							<tr>
				<td colspan="4" class="center"><input type="submit" name="submit" value="Send"	/>
				</td>
				</tr>
		</form></table>
		<br	/>
		</td></tr></table>
		<img align="right" src="Images/footer.png" title="footer"	/>
		';
		?>
	</body>
</html>
 <?php

    ob_end_flush();

    ?>


