<?php
ob_start();
session_start();

if( isset($_COOKIE["username"]) ){
    $logged = $_COOKIE["username"];
}else{
    $logged = $_SESSION["username"];
}
?>
<html>
<head>
<title> Profile </title>
<link href="Css/style13.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
   
    ini_set ('display_errors', 1);
    error_reporting (E_ALL & ~E_NOTICE);

    $con = mysqli_connect("localhost","root","19951995") or die("Error Connection");
    $db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");
    
    $getData = mysqli_query($con, "select * FROM register where FIRST_NAME = '$logged' ");

print '<div class="header"> <img src="images/randa.gif" id="panner">
                <img src="images/uqucourse.gif" style=" margin-left:910px;" id="panner">
                <img src="images/flyin2.gif"  id="panner2">
               
                
		</div>
                 <br><table><tr><td><h1>Hello('.$logged.')</h1><p> you can update your information from here. </p>';

while($rowData = mysqli_fetch_array($getData)){
print '<table style="width:30%; margin-left:430px;"><form action="profile.php" method="post">
				

				<tr>
				<th class="center">Password :</th>
				<td class="center"><input type="password" name="fpassword" value='.$rowData['PASSWORD'].' 	/></td>
				</tr>

				<tr>
				<th class="center">E-mail :</th>
				<td class="center"><input type="text" name="femail" value='.$rowData['EMAIL'].' id="mail" onchange="checkE(\'eError\',this.id)" 	/></td>
				</tr>

				<tr>
				<td></td>
				<td><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="eError"></p></td>
				</tr>
				<tr>
				<td colspan="2" class="center"><p align="center" style="color:red;font-size:10px;font-family:tahoma;font-weight:lighter;" id="e-Error"></p></td>
				</tr>

				<tr>
				<td colspan="2" class="center"><input type="submit" name="submit" value="Update" 	/>
				</tr></table>';
         
                 extract($_POST); 
                 
                   if( $femail&&$fpassword!="")
             {
                      if($femail!=$rowData['EMAIL']||$fpassword!=$rowData['PASSWORD']){
                             update();
}}
break;
          delete();   }
    
    function update(){
       
       /*  $con = mysqli_connect("localhost","root","") or die("Error Connection");
    $db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");
    global $femail,$fpassword ,$logged;
    $getData = mysqli_query($con, "UPDATE register SET EMAIL='$femail' ,PASSWORD='$fpassword' WHERE FIRST_NAME='$logged' ");
      print'<meta http-equiv="refresh" content="0; URL=Regester.php">';
     mysqli_close($con);*/
    }
  
function delete(){

 $con = mysqli_connect("localhost","root","19951995") or die("Error Connection");
    $db = mysqli_select_db($con, "housefinder_db") or die("Error Select DB");
    global $logged;
   $getData = mysqli_query($con, "DELETE  FROM apartments  WHERE NAME='$logged' ");
   print '<meta http-equiv="refresh" content="0; URL=profile.php">';
   mysqli_close($con);
   
}
     print '<tr><td><h1>Apartments :</h1>';

    $name = $rowData["NAME"];
    $getData = mysqli_query($con, "SELECT * FROM APARTMENTS WHERE NAME = '$logged'");
    
        while($rowData = mysqli_fetch_array($getData)){
            
            print '<tr><td><table id="innerBorder" border="1" style="margin-left:300px"><tr><td class="center" colspan="2"><br   /><img src="'.$rowData['IMG_NAME'].'" title="" width="200" height="100" /><br   /><br   /></td>';
            print '<td><b>Name :</b>'.$rowData['NAME'].'<br />';
            print '<b>Phone :</b>'.$rowData['PHONE'].'<br />';
            print '<b>E-mail:</b>'.$rowData['EMAIL'].'</td></tr>';
            print '<tr><td colspan="3"><b>Description :</b><br />'.$rowData['DESCRIPTION'].'</td></tr>';
            print '<tr><td><b>MAP:</b><br /><p class="center"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3709.5233010735706!2d39.106897314562616!3d21.604522985689314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbd751aa2b57%3A0xd32f14ab8ce46662!2s$city+'.$rowData["NAME"].'!5e0!3m2!1sen!2ssa!4v1459625552114" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></p></td>';
            print '<td colspan="2"><b>Notes :</b>'.$rowData['NOTES'].'<br /></td></tr>';
            print '<tr><td class="center"><b>Area:</b>'.$rowData['AREA'].'</td>';
            print '<td class="center"><b>Number of rooms:</b>'.$rowData['NUM_OF_ROOMS'].'</td>';
            print '<td class="center"><b>Price:</b>'.$rowData['PRICE'].'</td></tr>';
            print '<tr><td colspan="3" class="center">'
            . '<button type="submit" id="delete"  onclick="return confirm("Are you sure ?")">Delete</button></td></tr>';  
            
            print '</table></td></tr>';
        }

    print '</td></tr><tr><td><h1>Houses :</h1>';
    
    $getData = mysqli_query($con, "SELECT * FROM HOUSES WHERE NAME = '$logged'");
        while($rowData = mysqli_fetch_array($getData)){
            print '<tr><td><table id="innerBorder" border="1" style="margin-left:300px"><tr><td class="center" colspan="2"><br   /><img src="'.$rowData['IMG_NAME'].'" title="" width="200" height="100" /><br   /><br   /></td>';
            print '<td><b>Name :</b>'.$rowData['NAME'].'<br />';
            print '<b>Phone :</b>'.$rowData['PHONE'].'<br />';
            print '<b>E-mail:</b>'.$rowData['EMAIL'].'</td></tr>';
            print '<tr><td colspan="3"><b>Description :</b><br />'.$rowData['DESCRIPTION'].'</td></tr>';
            print '<tr><td><b>MAP:</b><br /><p class="center"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3709.5233010735706!2d39.106897314562616!3d21.604522985689314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbd751aa2b57%3A0xd32f14ab8ce46662!2s$city+'.$rowData["NAME"].'!5e0!3m2!1sen!2ssa!4v1459625552114" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></p></td>';
            print '<td colspan="2"><b>Notes :</b>'.$rowData['NOTES'].'<br /></td></tr>';
            print '<tr><td class="center"><b>Area:</b>'.$rowData['AREA'].'</td>';
            print '<td class="center"><b>Number of rooms:</b>'.$rowData['NUM_OF_ROOMS'].'</td>';
            print '<td class="center"><b>Price:</b>'.$rowData['PRICE'].'</td></tr>';
            print '<tr><td colspan="3" class="center">'
            . '<button value="Delete" name="delete" onclick="delete()">Delete</button></td></tr>';    
            print '</table></td></tr>';
        }
        
    print '</td></tr><tr><td><h1>Lands :</h1>';
    $getData = mysqli_query($con, "SELECT * FROM HOTELS WHERE NAME = '$logged'");
        while($rowData = mysqli_fetch_array($getData)){
            print '<tr><td><table id="innerBorder" border="1"><tr><td class="center" colspan="2"><br   /><img src="'.$rowData['IMG_NAME'].'" title="" width="200" height="100" /><br   /><br   /></td>';
            print '<td><b>Name :</b>'.$rowData['NAME'].'<br />';
            print '<b>Phone :</b>'.$rowData['PHONE'].'<br />';
            print '<b>E-mail:</b>'.$rowData['EMAIL'].'</td></tr>';
            print '<tr><td colspan="3"><b>Description :</b><br />'.$rowData['DESCRIPTION'].'</td></tr>';
            print '<tr><td><b>MAP:</b><br /><p class="center"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3709.5233010735706!2d39.106897314562616!3d21.604522985689314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbd751aa2b57%3A0xd32f14ab8ce46662!2s$city+'.$rowData["NAME"].'!5e0!3m2!1sen!2ssa!4v1459625552114" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></p></td>';
            print '<td colspan="2"><b>Notes :</b>'.$rowData['NOTES'].'<br /></td></tr>';
            print '<tr><td colspan="3" class="center">'
            . '<button value="Delete" name="delete" onclick="delete()">Delete</button></td></tr>';   
            print '</table></td></tr>';
        }
        
        
    mysqli_close($con);
    print '<tr><td class="center">
				<p>
				<a href="mailto:house_finder@hotmail.com"><img src="Images/email.png" title="email" /></a> |
				<a href="Advertising.php" target="_blank"><img src="Images/add.png" title="add" /></a> |
				<a href="home.php"><img src="Images/home.png" title="home" /></a> |
                <a href="AboutUs.php"><img src="Images/aboutUs.png" title="aboutUs" /></a> |
				<a href="Help.php" target="_blank"><img src="Images/help.png" title="help" /></a>
				</p>
			</td></tr>

			<tr><td class="center">
				<hr	/>
				<p id="warning">THIS SITE IS TO FACILITATE THE SEARCH FOR YOU. OWNERS ARE NOT RESPONSIBLE FOR WHAT HPPENS BETWEEN SELLER AND BUYER</p>
			</td></tr>';
   print '</th></tr></table>';
print '<img align="right" src="Images/footer.png" title="footer"  /><br />';

?>
</body>
</html>

<?php
ob_end_flush();
?>